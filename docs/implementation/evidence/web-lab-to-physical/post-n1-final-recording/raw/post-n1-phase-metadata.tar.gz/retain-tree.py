"""Metadata-only complete retention. Run only after all recording processes settle.
Large settled trees use independently bounded byte-identical chunks and exact reassembly.
No symlink traversal, SQLite opening, old archive rewrite or product execution.
"""
from pathlib import Path
import json,sys,os,hashlib,shutil,subprocess,datetime
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';meta=stage/'archive-receipts';meta.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inv(root):
 files=[];dirs=[];links=[]
 for directory,names,leaves in os.walk(root,followlinks=False):
  for name in list(names):
   p=Path(directory)/name;rel=p.relative_to(root).as_posix()
   if p.is_symlink():links.append({'path':rel,'target':os.readlink(p)});names.remove(name)
   else:dirs.append(rel)
  for name in leaves:
   p=Path(directory)/name;rel=p.relative_to(root).as_posix()
   if p.is_symlink():links.append({'path':rel,'target':os.readlink(p)})
   else:
    assert p.is_file(),p;st=p.stat();files.append({'path':rel,'bytes':st.st_size,'sha256':sha(p),'mode':oct(st.st_mode&0o777),'mtimeNs':st.st_mtime_ns})
 return {'files':sorted(files,key=lambda x:x['path']),'directories':sorted(dirs),'dependencyLinksDescriptorOnly':sorted(links,key=lambda x:x['path'])}
label=sys.argv[1];root=Path(sys.argv[2]).resolve(strict=True);assert root.is_dir() and not(root/'.git').exists() and label.replace('-','').replace('_','').isalnum()
before=inv(root);assert not any(Path(r['path']).name in ['settlement-processes.txt','.runtime-owner.sqlite'] for r in before['files']),'PRIVATE_ORIGINAL_REQUIRES_SAFE_COPY_FIRST'
assert not(meta/(label+'.tree-retention.json')).exists();limit=64*1024*1024;groups=[];current=[];size=0
for row in before['files']:
 if current and size+row['bytes']>limit:groups.append(current);current=[];size=0
 current.append(row);size+=row['bytes']
if current or not groups:groups.append(current)
records=[]
if len(groups)==1:
 code=subprocess.call([sys.executable,str(b/'archive-add-record.py'),label,str(root)]);assert code==0;records.append(json.loads((meta/(label+'.archive-record.json')).read_text()));assembly=Path(records[0]['extracted'])
else:
 for n,group in enumerate(groups,1):
  part=label+'-part'+str(n).zfill(3);copy=stage/'chunk-copies'/part;assert not copy.exists();copy.mkdir(parents=True)
  for directory in before['directories']:(copy/directory).mkdir(parents=True,exist_ok=True)
  for row in group:
   p=root/row['path'];q=copy/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(q)==row['sha256']
  code=subprocess.call([sys.executable,str(b/'archive-add-record.py'),part,str(copy)]);assert code==0;records.append(json.loads((meta/(part+'.archive-record.json')).read_text()))
 assembly=stage/'reassembled'/label;assert not assembly.exists();assembly.mkdir(parents=True)
 for directory in before['directories']:(assembly/directory).mkdir(parents=True,exist_ok=True)
 for record in records:
  src=Path(record['extracted'])
  for p in src.rglob('*'):
   if p.is_file():q=assembly/p.relative_to(src);assert not q.exists();shutil.copy2(p,q)
after=inv(assembly);key=lambda x:[(r['path'],r['bytes'],r['sha256'],r['mode']) for r in x['files']]
assert key(before)==key(after) and before['directories']==after['directories'] and not after['dependencyLinksDescriptorOnly'];assert inv(root)==before
result={'version':1,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'id':label,'original':str(root),'originalInventory':before,'records':records,'reassembled':str(assembly),'verifiedFiles':len(before['files']),'verifiedBytes':sum(x['bytes'] for x in before['files']),'scope':'Complete original regular-file bytes and modes reconstructed at exact relative paths. Original mtime indexed; tar has neutral time. Dependency symlinks are descriptors only, never followed/materialized. Original producer and failed/not_run status bytes unchanged. No public reader implied by byte verification.'}
(meta/(label+'.tree-retention.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['id','reassembled','verifiedFiles','verifiedBytes']}))
