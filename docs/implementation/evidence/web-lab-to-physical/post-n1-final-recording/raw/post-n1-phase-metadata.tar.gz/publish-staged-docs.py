"""Authorized feature-branch documentation/evidence commits after raw freeze.
No main/remote/runtime export/cleanup. Exact file allowlist, copy hashes and heads retained.
"""
from pathlib import Path
import json,subprocess,hashlib,shutil,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];paths=json.loads((b/'paths.json').read_text());stage=Path(paths['root'])/'publication-staging';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ops=[];copies=[];heads={}
assert (b/'publication-raw-freeze-completed.json').is_file(),'RAW_FREEZE_AND_PUBLIC_READBACKS_REQUIRED'
def git(repo,args):
 r=subprocess.run(['git',*args],cwd=repo,text=True,capture_output=True,timeout=3600);ops.append({'argv':['git',*args],'cwd':str(repo),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(b/'publication-git-operations.json').write_text(json.dumps(ops,indent=2)+'\n');assert r.returncode==0,r.stderr;return r.stdout.strip()
for name,repo,expected,message in [('source',active,paths['producerSource'],'docs: retain post-N1 recordings and current handoff'),('lab',Path(paths['lab']),paths['producerLab'],'docs: describe post-N1 shared-cell recording scope')]:
 assert git(repo,['rev-parse','HEAD'])==expected;assert not git(repo,['status','--porcelain','--untracked-files=all']);assert git(repo,['branch','--show-current'])=='codex/web-lab-to-physical';root=stage/name;files=[]
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if not p.is_file():continue
  rel=p.relative_to(root).as_posix();assert rel=='README.md' or name=='source' and rel.startswith('docs/'),rel
  q=repo/rel;q.parent.mkdir(parents=True,exist_ok=True);before={'bytes':q.stat().st_size,'sha256':sha(q)} if q.exists() else None;shutil.copy2(p,q);assert sha(p)==sha(q);files.append(rel);copies.append({'repository':name,'path':rel,'stagedBytes':p.stat().st_size,'stagedSha256':sha(p),'prior':before})
 assert files
 rawPrefix='docs/implementation/evidence/web-lab-to-physical/post-n1-final-recording/'
 ordinary=[p for p in files if not p.startswith(rawPrefix)];forced=[p for p in files if p.startswith(rawPrefix)]
 for group,force in [(ordinary,False),(forced,True)]:
  for i in range(0,len(group),100):git(repo,['add',*(['-f'] if force else []),'--',*group[i:i+100]])
 changed=git(repo,['diff','--cached','--name-only']).splitlines();assert set(changed)==set(files),(name,'UNEXPECTED_STAGED_PATHS',sorted(set(changed)^set(files)))
 if name=='source':
  git(repo,['diff','--cached','--check','--','README.md','docs/gtm/2026-11-14-web-simulation','docs/implementation/web-lab-to-physical/README.md','docs/implementation/web-lab-to-physical/design',':(glob)docs/implementation/web-lab-to-physical/post-n1-final-recording/*.md'])
 else:git(repo,['diff','--cached','--check','--','README.md'])
 git(repo,['commit','-m',message]);assert not git(repo,['status','--porcelain','--untracked-files=all']);heads[name]={'commit':git(repo,['rev-parse','HEAD']),'tree':git(repo,['rev-parse','HEAD^{tree}']),'files':len(files)}
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':{'source':paths['producerSource'],'lab':paths['producerLab'],'runtime':paths['runtimeArtifact'],'build':paths['buildSha256']},'firstPublicationHeads':heads,'copies':copies,'scope':'Only feature-branch current docs and new retained evidence. Immutable old121/report/maps unchanged. No runtime export/repin, product code, main/remote/push/deploy/provision/hardware or workspace cleanup. Whitespace check scoped to authored maintained prose, preserving original historical report/raw bytes.'};(b/'first-publication-heads.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(heads))
