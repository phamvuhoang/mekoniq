from pathlib import Path
import subprocess,json,sys,time,hashlib,shutil,datetime,os
b=Path(__file__).resolve().parent;source=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);deadline=time.monotonic()+21600
while not (b/'physical-mock-irsim-completed.json').is_file():
 assert time.monotonic()<deadline,'UPSTREAM_CHAIN_NOT_COMPLETE';time.sleep(5)
lab=Path(json.loads((b/'isolated-producer-boundary.json').read_text())['lab']).resolve();legacy=e/'publication-staging/current-legacy-readback/source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,bound=600,cwd='source',allowed=(0,)):
 (b/'chain-stage.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':os.getpid(),'stage':name,'scope':'Serialized required stage, no competing engine/browser/archive'},indent=2)+'\n');code=subprocess.call([sys.executable,str(b/'run.py'),name,str(cwd),'caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);print('POST_N1_REGRESSION',name,code,flush=True);assert code in allowed,(name,code);return code
def guard(name,record,cwd):return run(name,['env','LAB_SIMEXT_EVIDENCE_DIR='+str(e/record),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/(name+'.json'))],600,cwd,(0,1))
def preserve(owner):
 default=lab/'test-results'
 if not default.exists():return
 def inv(root):
  rows=[]
  for p in sorted(root.rglob('*')):
   assert not p.is_symlink(),p
   if p.is_file():rows.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777),'mtimeNs':p.stat().st_mtime_ns})
  return rows
 files=inv(default);copy=e/(owner+'-default-results-copy');original=e/(owner+'-default-results-original');assert not copy.exists() and not original.exists();shutil.copytree(default,copy,copy_function=shutil.copy2);assert inv(default)==files==inv(copy);default.rename(original);assert inv(original)==files and not default.exists();(b/(owner+'-default-output-map.json')).write_text(json.dumps({'originalPath':str(default),'copy':str(copy),'retainedOriginal':str(original),'files':files,'scope':'Only fresh owned isolated default output retained after its actual official recorder settles; active old defaults not moved/deleted; raw attachment paths preserved'},indent=2)+'\n')
(b/'regression-chain-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'waitedFor':'physical-mock-irsim-completed.json','scope':'Normal R1→R11→genuine partial with actual upstream candidates and complete public guards; six R3 prepared subjects independent; no fake candidate on prerequisite refusal'},indent=2)+'\n');preserve('irsim')
outcomes={}
outcomes['r1']=run('record-r1',['node','scripts/record-sim-extension.mjs','--release','r1','--out',e/'r1','--candidate-id','r1-post-n1-0d46403-7c97b20','--irsim-record',e/'irsim','--mock-regression',e/'mock-regression','--lab',lab,'--webots-home','/Applications/Webots.app','--webots-python',source/'.venv-webots/bin/python'],7200,allowed=(0,1,2));preserve('r1')
if (e/'r1/qualification.json').is_file():
 outcomes['r1ExternalGuard']=guard('acceptance-r1-external','r1','source');run('stage-current-legacy-r1',[sys.executable,b/'stage-current-legacy.py','r1']);outcomes['r1StagedGuard']=guard('acceptance-r1-staged','r1',legacy)
 outcomes['r11']=run('record-r11',['node','scripts/record-sim-extension.mjs','--release','r1.1','--out',e/'r11','--candidate-id','r11-post-n1-0d46403-7c97b20','--r1-record',e/'r1','--mock-regression',e/'mock-regression','--lab',lab,'--webots-home','/Applications/Webots.app','--webots-python',source/'.venv-webots/bin/python'],3600,allowed=(0,1,2));preserve('r11')
 if (e/'r11/qualification.json').is_file():
  outcomes['r11ExternalGuard']=guard('acceptance-r11-external','r11','source');run('stage-current-legacy-r11',[sys.executable,b/'stage-current-legacy.py','r11']);outcomes['r11StagedGuard']=guard('acceptance-r11-staged','r11',legacy)
  outcomes['r2aPartial']=run('record-r2a-partial',['node','scripts/record-sim-extension.mjs','--release','r2a','--skip-suites','--out',e/'r2a-partial','--candidate-id','r2a-partial-post-n1-0d46403-7c97b20','--r11-record',e/'r11','--mock-regression',e/'mock-regression','--lab',lab],600,allowed=(0,1,2))
  if (e/'r2a-partial/qualification.json').is_file():
   outcomes['partialExternalGuard']=guard('acceptance-r2a-partial-external','r2a-partial','source');run('stage-current-legacy-r2a',[sys.executable,b/'stage-current-legacy.py','r2a']);outcomes['partialStagedGuard']=guard('acceptance-r2a-partial-staged','r2a-partial',legacy)
outcomes['r2aPartialExists']=(e/'r2a-partial/qualification.json').is_file();outcomes['scope']='Actual returns/candidate existence; nonzero and absent-input branches are preserved, never spliced or fabricated. Missing GUI/upstream blocks dependent qualification and is reported to root; independent R3 still runs.';(b/'lineage-outcomes.json').write_text(json.dumps(outcomes,indent=2)+'\n')
run('r3-chain',[sys.executable,b/'r3-chain.py'],1800,allowed=(0,1))
(b/'regression-r3-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outcomes':outcomes,'scope':'These invocations settled; individual profile receipts/cases and failures/not_run remain authoritative.'},indent=2)+'\n')
