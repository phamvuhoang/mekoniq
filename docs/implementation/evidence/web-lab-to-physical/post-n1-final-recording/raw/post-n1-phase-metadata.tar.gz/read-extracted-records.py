"""Once-only public retained-data checks at exact recorded checker/producer commits.
No engine/campaign/browser execution. Shared detached reader clones are distinct from
later ordinary nonshared publication clone checks. Duplicate identical subjects reuse
one reader receipt with explicit path/hash attribution.
"""
from pathlib import Path
import json,sys,hashlib,subprocess,datetime,os
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';meta=stage/'archive-receipts';out=stage/'public-readbacks';out.mkdir();checkouts=stage/'exact-reader-checkouts';checkouts.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources={};preps=[];receipts=[];aliases=[];seen={}
def prep(args,cwd):
 r=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=240);preps.append({'argv':list(map(str,args)),'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr;return r.stdout.strip()
def source(commit):
 if commit in sources:return sources[commit]
 p=checkouts/commit;prep(['git','clone','--shared','--no-checkout',str(active),str(p)],checkouts);prep(['git','checkout','--detach',commit],p);(p/'node_modules').symlink_to(active/'node_modules',target_is_directory=True);assert not prep(['git','status','--porcelain','--untracked-files=all'],p);assert sha(p/'pnpm-lock.yaml')==sha(active/'pnpm-lock.yaml');sources[commit]=p;(out/'reader-preparation.json').write_text(json.dumps({'scope':'Exact clean detached code and equal-lock explicit installed Node dependency reuse; no installation/fresh-host proof; no engines run. Later publication clones use ordinary --no-local clones.','operations':preps},indent=2)+'\n');return p
def run(label,commit,args,subject=None):
 cwd=source(commit);env=os.environ.copy();env['PATH']='/Users/hoangpham/.nvm/versions/node/v24.22.2/bin:'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1';env['PYTEST_ADDOPTS']='-p no:cacheprovider'
 for k in ['MEKONIQ_TEST_SERVICE_RECEIPT','LAB_CONTAINER_IMAGE','LAB_TEST_PAIRING_TOKEN']:env.pop(k,None)
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();argv=['caffeinate','-dims','perl','-e','alarm 600; exec @ARGV',*map(str,args)];r=subprocess.run(argv,cwd=cwd,env=env,text=True,capture_output=True,timeout=660);log=out/(label+'.log');log.write_text(r.stdout+r.stderr);row={'id':label,'argv':argv,'cwd':str(cwd),'sourceCommit':commit,'sourceStatus':prep(['git','status','--porcelain','--untracked-files=all'],cwd),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode if r.returncode>=0 else None,'signal':-r.returncode if r.returncode<0 else None,'log':log.name,'logBytes':log.stat().st_size,'logSha256':sha(log),'subject':str(subject) if subject else None,'scope':'Actual public readback against safely extracted exact bytes; nonzero retained as actual failure, not qualification promotion.'};(out/(label+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n');receipts.append(row);(out/'index.json').write_text(json.dumps({'records':receipts,'duplicateSubjectAliases':aliases},indent=2)+'\n');print(label,r.returncode,flush=True);return label
maps=[json.loads(p.read_text()) for p in sorted(meta.glob('*.tree-retention.json'))];current=[m for m in maps if m['id'].startswith('post-n1-')];qualcode="import {readFileSync,existsSync} from 'node:fs';import {join} from 'node:path';import {checkQualification} from './scripts/sim-extension-qualification.mjs';const d=process.argv[1],p=checkQualification(JSON.parse(readFileSync(join(d,'qualification.json'))),f=>existsSync(join(d,f))?readFileSync(join(d,f)):null);console.log(JSON.stringify(p));process.exit(p.length?1:0);"
irsimcode=qualcode.replace('sim-extension-qualification','irsim-qualification')
for m in current:
 root=Path(m['reassembled'])
 for p in sorted(root.rglob('qualification.json')):
  j=json.loads(p.read_text());commit=j.get('checker',{}).get('sourceCommit') or j.get('identity',{}).get('before',{}).get('sourceCommit');assert commit and len(commit)==40,(p,'NO_EXACT_CHECKER');prefix=p.parent.relative_to(root).as_posix();prefix='' if prefix=='.' else prefix+'/'
  subtree={'files':[(r['path'][len(prefix):],r['bytes'],r['sha256'],r['mode']) for r in m['originalInventory']['files'] if r['path'].startswith(prefix)],'directories':[v[len(prefix):] for v in m['originalInventory']['directories'] if v.startswith(prefix)]};treehash=hashlib.sha256(json.dumps(subtree,sort_keys=True).encode()).hexdigest();key=('qualification',commit,sha(p),treehash);label=m['id']+'-q'+str(len(receipts)).zfill(3)
  if key in seen:aliases.append({'path':str(p),'sha256':sha(p),'artifactTreeSha256':treehash,'sourceCommit':commit,'sameReaderReceipt':seen[key]});continue
  args=['node','scripts/verify-r3.mjs',str(p.parent)] if j.get('release')=='r3' else ['node','--input-type=module','-e',irsimcode if j.get('documentType')=='linkforge-irsim-qualification' else qualcode,str(p.parent)];seen[key]=run(label,commit,args,p)
  if j.get('release')=='r2b':
   code="import {verifyR2bDirectory} from './scripts/r2b-readback.mjs';const issues=await verifyR2bDirectory(process.argv[1]);console.log(JSON.stringify(issues));process.exit(issues.length?1:0);";run(label+'-async',commit,['node','--input-type=module','-e',code,str(p.parent)],p)
   run(label+'-acceptance',commit,['env','LAB_SIMEXT_EVIDENCE_DIR='+str(p.parent),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(out/(label+'-acceptance.json'))],p)
# Exact current unique campaign verification, independent of repeated copied inputs.
commit=json.loads((b/'paths.json').read_text())['producerSource']
for m in current:
 root=Path(m['reassembled'])
 if m['id'] in ['post-n1-payload-campaign','post-n1-cell-campaign']:run(m['id']+'-verify',commit,['node','scripts/lab-mujoco.mjs','verify','--input',root],root)
 if m['id']=='post-n1-irsim':run(m['id']+'-campaign-verify',commit,['node','scripts/lab-irsim.mjs','verify','--input',root/'campaign'],root/'campaign')
 if m['id'].startswith('post-n1-handoff-'):
  run(m['id']+'-verify',commit,['node','scripts/native-handoff.mjs','verify','--input',root],root)
# Unique historical/current captures use the exact own producer's public assessor.
for m in [x for x in maps if x['id'] in ['post907-correction','post-n1-production-performance','post-n1-web-record']]:
 root=Path(m['reassembled'])
 for p in sorted(root.rglob('actual-cell-production.json')):
  j=json.loads(p.read_text());commit=j['sourceCommit'];key=('capture',commit,sha(p))
  if key in seen:aliases.append({'path':str(p),'sha256':sha(p),'sourceCommit':commit,'sameReaderReceipt':seen[key]});continue
  label=m['id']+'-capture'+str(len(receipts)).zfill(3);code="import {readFileSync} from 'node:fs';import {assessCapture} from './scripts/browser-capture-clock.mjs';const v=assessCapture(JSON.parse(readFileSync(process.argv[1])));console.log(JSON.stringify(v));process.exit(v.valid&&v.meetsTargets?0:1);";seen[key]=run(label,commit,['node','--input-type=module','-e',code,p],p)
# Reassembled current web directory binds both the failed capture and mandatory separate browser assets.
web=next(Path(m['reassembled']) for m in current if m['id']=='post-n1-web-record');commit=json.loads((b/'paths.json').read_text())['producerSource'];code="import {readFileSync} from 'node:fs';import {join} from 'node:path';import {assessCapture,checkCaptureClock} from './scripts/browser-capture-clock.mjs';import {verifyBrowserArtifacts} from './scripts/browser-evidence-readback.mjs';const root=process.argv[1],c=JSON.parse(readFileSync(join(root,'actual-cell-production.json'))),tuple={sourceCommit:c.sourceCommit,labCommit:c.buildIdentity.labHead,artifactSha256:c.runtimeArtifact,schemaHash:c.buildIdentity.schemaHash};const v={clock:checkCaptureClock(c),capture:assessCapture(c),browser:verifyBrowserArtifacts(p=>readFileSync(join(root,p)),c,tuple)};console.log(JSON.stringify(v));process.exit(v.capture.valid&&v.capture.meetsTargets&&!v.browser.length?0:1);";run('current-web-complete-readback',commit,['node','--input-type=module','-e',code,web],web)
(out/'index.json').write_text(json.dumps({'records':receipts,'duplicateSubjectAliases':aliases,'scope':'Every supported current qualification/handoff/campaign and each unique historical/current capture uses exact public reader; fullR2b async/complete acceptance separately retained. Byte-only code/static/raw process packages have no fabricated semantic reader.'},indent=2)+'\n');print('EXTRACTED_PUBLIC_READBACKS_COMPLETE',len(receipts),flush=True)
