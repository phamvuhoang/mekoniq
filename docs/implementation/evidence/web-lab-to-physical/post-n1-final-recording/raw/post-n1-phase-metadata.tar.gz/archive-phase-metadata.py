from pathlib import Path
import json,os,shutil,hashlib,subprocess,sys,datetime
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';dest=stage/'safe-post-n1-phase-metadata';assert (b/'all-recording-chains-completed.json').is_file() and (b/'phase-metadata-freeze-admitted.json').is_file();assert not dest.exists();dest.mkdir();rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for directory,dirs,files in os.walk(b,followlinks=False):
 out=dest/Path(directory).relative_to(b);out.mkdir(parents=True,exist_ok=True)
 for name in list(dirs):
  p=Path(directory)/name
  if p.is_symlink():(out/name).symlink_to(os.readlink(p),target_is_directory=True);dirs.remove(name)
 for name in files:
  p=Path(directory)/name;q=out/name;assert name not in ['settlement-processes.txt','.runtime-owner.sqlite','takeover-owned-state-and-path.json','r1-invocation-boundary.json','host-sleep-observation.log'],p
  if p.is_symlink():q.symlink_to(os.readlink(p));continue
  shutil.copy2(p,q);assert sha(p)==sha(q);rows.append({'original':str(p),'path':p.relative_to(b).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
(stage/'archive-receipts/post-n1-phase-metadata-copy-map.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original':str(b),'snapshot':str(dest),'files':rows,'scope':'Exact new-phase metadata snapshot at this boundary. Old private metadata is not copied. Later own archive/normal-clone/publication receipts remain separately indexed direct late files, not retroactively part of this frozen snapshot.'},indent=2)+'\n')
code=subprocess.call([sys.executable,str(b/'retain-tree.py'),'post-n1-phase-metadata',str(dest)]);assert code==0
