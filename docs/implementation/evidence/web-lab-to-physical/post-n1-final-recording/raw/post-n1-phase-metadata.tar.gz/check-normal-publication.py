from pathlib import Path
import json,sys,subprocess,hashlib,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];clone=json.loads((b/'normal-publication-clones.json').read_text());workspace=Path(clone['workspace']);paths=json.loads((b/'paths.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,cwd,args,bound=600):
 code=subprocess.call([sys.executable,str(b/'run.py'),name,str(cwd),'perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);print('PUBLICATION_CHECK',name,code,flush=True);assert code==0,(name,code)
run('normal-clone-link-scope',active,[sys.executable,b/'prepare-clone-link-scope.py'])
run('normal-clone-links',active,[sys.executable,b/'normal-clone-link-audit.py',workspace,b/'normal-clone-link-scope.json',b/'normal-clone-link-audit.json'])
run('normal-clone-exactrefs',active,[sys.executable,b/'exact-ref-reachability.py',workspace,b/'published-exact-ref-scope.json',b/'normal-clone-exact-ref-audit.json'])
run('normal-clone-retention',active,[sys.executable,b/'verify-normal-clone-retention.py'],1800)
run('normal-clone-import-pin',workspace/'lab',['node','scripts/import-runtime.mjs',paths['runtimeExport']])
assert sha(workspace/'lab/config/source-runtime.lock.json')==sha(Path(paths['lab'])/'config/source-runtime.lock.json')
run('normal-clone-check-source',workspace/'lab',['pnpm','check:source'])
run('normal-clone-generated-contracts',workspace/'lab',['node','scripts/sync-engineering-contracts.mjs','--check'])
run('normal-clone-portable-licenses',workspace/'source',['node','scripts/portable-licenses.mjs','--check'])
closure="import {nativeToolClosure,portableToolClosure} from './scripts/native-sim/tool-identity.mjs';const native=nativeToolClosure(process.cwd()),portable=portableToolClosure(process.cwd());console.log(JSON.stringify({native:native.digest,portable:portable.digest,nativeFiles:native.files.length,portableFiles:portable.files.length}));if(native.digest!=='79018e0a2601d8a27d3739751910bb392c86c2857cc39ad5fb451a977de78634'||portable.digest!=='30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b')process.exit(1);"
run('normal-clone-closure-identity',workspace/'source',['node','--input-type=module','-e',closure])
run('normal-clone-contracts',workspace/'source',['pnpm','contracts:check'])
for repo in ['source','lab','web','trial']:
 r=subprocess.run(['git','status','--porcelain','--untracked-files=all'],cwd=workspace/repo,text=True,capture_output=True);assert r.returncode==0 and not r.stdout,(repo,r.stdout,r.stderr)
(b/'normal-publication-checks-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':str(workspace),'observedHeads':clone['heads'],'scope':'Ordinary nonshared clone current maintained links/exact-case paths/all-owned exact Git refs+ancestry, new retention/current+prior maps/five privacy exclusions, actual installed pin/generated contracts/licenses/closure/contracts checks. Explicit equal-lock Node and five Python metadata reuses recorded. No fresh-host install, productionBuildIdentity at docs HEAD, runtime re-export, browser/engine/campaign/native qualification or circular rerun for later receipt-only commit.'},indent=2)+'\n')
