from pathlib import Path
import subprocess,json,hashlib,os,shutil,datetime,sys
b=Path(__file__).resolve().parent;active=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);pair=e/'publication-staging/current-legacy-readback';pair.mkdir(exist_ok=True,parents=True);ops=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();release=sys.argv[1];assert release in ['r1','r11','r2a'];source=pair/'source';lab=pair/'lab'
def run(args,cwd):
 r=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=240,env={**os.environ,'GIT_LFS_SKIP_SMUDGE':'1'});ops.append({'argv':args,'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,(args,r.stdout,r.stderr);return r.stdout.strip()
if not source.exists():
 for name,commit in [('source',paths['producerSource']),('lab',paths['producerLab'])]:
  target=pair/name;origin=active if name=='source' else active.parent/'lab';run(['git','clone','--shared','--no-checkout',str(origin),str(target)],pair);run(['git','checkout','--detach',commit],target);assert not run(['git','status','--porcelain','--untracked-files=all'],target)
 (source/'node_modules').symlink_to(active/'node_modules',target_is_directory=True);assert sha(source/'pnpm-lock.yaml')==sha(active/'pnpm-lock.yaml');checked=json.loads(run(['node','--input-type=module','-e',"const {checkedCheckerIdentity}=await import('./scripts/native-checker-bootstrap.mjs');console.log(JSON.stringify(await checkedCheckerIdentity()));"],source));assert checked=={'sourceCommit':paths['producerSource'],'toolSha256':'6f464a9b4968f9270435a393539a16c42dbbfa4c9890a45cea62a7d8894392c3'};(b/'current-legacy-checker-before-staging.json').write_text(json.dumps({'checker':checked,'ops':ops,'source':str(source),'lab':str(lab),'policy':'Exact clean paired code before data-only staging; equal-lock existing Node reuse, no install/download or new campaign'},indent=2)+'\n')
def inv(root):
 rows=[]
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():rows.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
 return rows
copies=[]
for name,rel in [('irsim','docs/implementation/evidence/linkforge-irsim/irsim'),('r1','docs/implementation/evidence/sim-extension/r1'),*([('r11','docs/implementation/evidence/sim-extension/r11')] if release in ['r11','r2a'] else [])]:
 origin=e/name;dest=source/rel;before=inv(origin);created=not dest.exists()
 if created:
  absent=subprocess.run(['git','cat-file','-e','HEAD:'+rel],cwd=source,text=True,capture_output=True);assert absent.returncode!=0;ops.append({'argv':['git','cat-file','-e','HEAD:'+rel],'cwd':str(source),'exitCode':absent.returncode,'expected':'Absent immutable Git path','stderr':absent.stderr});dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(origin,dest)
 assert inv(origin)==before==inv(dest);copies.append({'source':str(origin),'destination':str(dest),'createdNow':created,'files':before})
assert not run(['git','diff','HEAD','--name-only'],source)
for rel in run(['git','ls-files','--others','--exclude-standard'],source).splitlines():assert rel.startswith('docs/implementation/evidence/linkforge-irsim/irsim/') or rel.startswith('docs/implementation/evidence/sim-extension/r1/') or rel.startswith('docs/implementation/evidence/sim-extension/r11/'),rel
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'lab':str(lab),'sourceHead':run(['git','rev-parse','HEAD'],source),'labHead':run(['git','rev-parse','HEAD'],lab),'copies':copies,'trackedCodeUnchanged':True,'dependencyPolicy':'Source ignored node_modules explicitly reuses existing equal-lock install; Lab is pin/read-only data for public acceptance, no installed runtime or campaign used','scope':'Exact-code public acceptance with explicit data-only upstream staging. This is not clean producer execution or arbitrary-output portability repair.','ops':ops};(b/('current-legacy-stage-'+release+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'source':str(source),'lab':str(lab),'copiedFiles':sum(len(c['files']) for c in copies)}))
