"""Current readable SDD location map, preserving old audited map/copies unchanged.
Run once after explicit root metadata freeze, before late publication receipts.
"""
from pathlib import Path
import json,hashlib,shutil,datetime,re
b=Path(__file__).resolve().parent;active=b.parents[4];sdd=active/'.superpowers/sdd';d=sdd/'README';e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';dest=stage/'source/docs/implementation/web-lab-to-physical/post-n1-final-recording/retention';dest.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (b/'root-readable-freeze-admitted.json').exists(),'ROOT_METADATA_FREEZE_REQUIRED'
oldpath=active/'docs/implementation/web-lab-to-physical/retention/full-readable-copy-map.json';old=json.loads(oldpath.read_text());oldby={r['original']:r for r in old['files']};candidates=[]
for root in [sdd,*[sdd/n for n in ['README','01-r2b-mobility','02-r2b-cell-and-web','03-r3-linux-readiness']]]:
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink() and p.name!='.gitignore':candidates.append(p)
for name in ['review-final-prerequisites-4-root-package','review-final-prerequisites-4-root-package-verified','final-correction-907-bfde','final-n1-correction']:
 for p in sorted((d/name).rglob('*')):
  if p.is_symlink():raise AssertionError(('UNDECLARED_STATIC_SYMLINK',p))
  if p.is_file() and (p.suffix.lower() in ['.md','.json','.py','.diff','.txt','.log','.mjs'] or not p.suffix):candidates.append(p)
rows=[];large=[]
for p in sorted(set(candidates)):
 assert p.name not in ['settlement-processes.txt','.runtime-owner.sqlite'],p
 info={'original':str(p),'bytes':p.stat().st_size,'sha256':sha(p)};prior=oldby.get(str(p))
 if prior and (prior['bytes'],prior['sha256'])==(info['bytes'],info['sha256']):
  target=active/prior['destination'];assert target.is_file() and sha(target)==info['sha256'];rows.append({**info,'destination':prior['destination'],'retention':'unchanged exact prior-generation readable copy, referenced without rewriting audited bytes'});continue
 if info['bytes']>5*1024*1024:
  large.append({**info,'retention':'Exact external original plus previous giant-review Git/generator descriptors or separately complete post907 wholebranch-package archive. Not silently truncated into readable text.'});continue
 rel=p.relative_to(sdd);q=dest/'sdd'/rel;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copy2(p,q);assert sha(q)==info['sha256'];rows.append({**info,'destination':str(q.relative_to(stage/'source')),'retention':'exact current readable snapshot, complete report/review/brief/ruling/root metadata; raw bytes unchanged'})
reports=[r for r in rows if Path(r['original']).name.startswith('task-') and Path(r['original']).name.endswith('-report.md')];reviews=[r for r in rows if Path(r['original']).name.startswith('task-') and '-review' in Path(r['original']).name and Path(r['original']).suffix=='.md'];rulings=[]
for p in sorted(set(candidates)):
 if p.suffix.lower()!='.md':continue
 for n,line in enumerate(p.read_text().splitlines(),1):
  if 'Ruling:' in line or 'Sequencing ruling for final evidence:' in line:rulings.append({'source':str(p.relative_to(sdd)),'lineAtSnapshot':n,'text':line,'explicitClauses':line.count('Ruling:')+line.count('Sequencing ruling for final evidence:')})
priorrefs=[]
for path in [oldpath,active/'docs/implementation/web-lab-to-physical/retention/snapshots/initial-readable/location-map.json',active/'docs/implementation/evidence/web-lab-to-physical/final-recording/index.json']:
 priorrefs.append({'path':str(path.relative_to(active)),'bytes':path.stat().st_size,'sha256':sha(path),'retention':'unchanged prior audited publication; historical own boundaries remain explicit'})
result={'version':1,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Complete current static SDD readable location map, reusing byte-identical earlier copies and adding every changed/new complete file. Post907 correction/probe/raw/package archives are indexed separately. Initial/current prior maps remain immutable. Later own-publication receipts are a distinct checkpoint, not retroactively in this snapshot.','files':rows,'largeStaticDescriptors':large,'priorSnapshots':priorrefs,'reportCount':len(reports),'reportBytes':sum(r['bytes'] for r in reports),'reviewCount':len(reviews),'reviewBytes':sum(r['bytes'] for r in reviews),'legacyLimitation':'B00/B01 standalone reviews remain ledger-only; no report invented.'};(dest/'current-readable-location-map.json').write_text(json.dumps(result,indent=2)+'\n')
(dest/'review-index.json').write_text(json.dumps({'scope':'All complete actual current/old task review files, including wholebranch/scoped/N1 followup; no new engineering review requested. Byte locations in current-readable-location-map.','records':reviews},indent=2)+'\n')
(dest/'rulings-whole-lines.json').write_text(json.dumps({'scope':'All whole literal Ruling/Sequencing lines across selected current static Markdown, including cap exception and navigation scope outside four progress ledgers. Intentional duplicates, embedded quotes and all same-line clauses retained. Full original source text remains readable.','records':rulings,'physicalLines':len(rulings),'explicitClauses':sum(r['explicitClauses'] for r in rulings)},indent=2,ensure_ascii=False)+'\n')
text='# Complete literal ruling lines\n\nThe current readable location map resolves every original source. Intentional duplicates are preserved.\n'
for r in rulings:text+='\n## '+r['source']+':'+str(r['lineAtSnapshot'])+'\n\n```text\n'+r['text']+'\n```\n'
(dest/'rulings-whole-lines.md').write_text(text)
print(json.dumps({'files':len(rows),'newCopies':sum('current readable' in r['retention'] for r in rows),'reports':len(reports),'reviews':len(reviews),'rulingLines':len(rulings),'clauses':sum(r['explicitClauses'] for r in rulings)}))
