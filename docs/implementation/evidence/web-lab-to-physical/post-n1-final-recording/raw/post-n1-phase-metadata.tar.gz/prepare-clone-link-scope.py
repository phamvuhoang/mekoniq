from pathlib import Path
import json,re,hashlib,datetime
from urllib.parse import urlsplit,unquote
b=Path(__file__).resolve().parent;active=b.parents[4];clone=json.loads((b/'normal-publication-clones.json').read_text());workspace=Path(clone['workspace']);old=b.parent/'981e234-lab-d4c3032';scope=json.loads((old/'normal-clone-link-audit-2.json').read_text())['scope'];scope['scope']='Maintained current Source/Lab README, design/plans, dated GTM plus09 and postN1 handoff; exact-case Git paths and supported local/fragment syntax. Immutable historical reports/reviews preserve original provenance; all owned exact Git URLs there receive separate ancestry/object checks. Remote hosting not checked.'
for p in sorted((workspace/'source/docs/implementation/web-lab-to-physical/post-n1-final-recording').glob('*.md')):scope['documents'].append(str(p.relative_to(workspace)))
scope['documents'].append('source/docs/gtm/2026-11-14-web-simulation/09-post-n1-engineering-readiness.md');scope['documents']=sorted(set(scope['documents']));(b/'normal-clone-link-scope.json').write_text(json.dumps(scope,indent=2)+'\n')
refs={}
def add(repo,ref,origin):
 key=(repo,ref);refs.setdefault(key,{'repository':repo,'ref':ref,'origins':[]})['origins'].append(origin)
for row in json.loads((old/'published-exact-ref-scope.json').read_text())['refs']:
 for origin in row['origins']:add(row['repository'],row['ref'],origin)
for repo,ref,role in [('source','0d4640324d7fdb2f169ed9078db2208aae61b589','current recorded/checker producer'),('lab','7c97b202143dd156d8e7751dfa2bbf198d17f9b9','current recorded Lab/build producer'),('source','907087c4f2a4d6bc1348f50177c19143d956e9d9','unchanged prior wholebranch publication/package'),('lab','bfde031f552c4909941beae2df8a51e3af73c23d','unchanged prior wholebranch publication/package')]:add(repo,ref,{'descriptor':'new-generation raw index/reproduction','role':role})
owned=scope['gitRepositories'];pattern=re.compile(r'https://github\.com/(?:'+ '|'.join(re.escape(k) for k in owned)+r')/(?:blob|tree|commit)/[0-9a-f]{40}(?:/[^\s)\]<>`"\']*)?(?:#[^\s)\]<>`"\']*)?')
for repoName in ['source','lab']:
 for p in sorted((workspace/repoName).rglob('*.md')):
  if '.git' in p.parts or 'node_modules' in p.parts or any(v.startswith('.venv') for v in p.parts):continue
  for number,line in enumerate(p.read_text(errors='strict').splitlines(),1):
   for m in pattern.finditer(line):
    url=m.group(0).rstrip('.,;');parts=[unquote(v) for v in urlsplit(url).path.strip('/').split('/')];add(owned['/'.join(parts[:2])],parts[3],{'path':str(p.relative_to(workspace)),'line':number,'url':url})
# Historical correction captures are published exact-subject reproduction descriptors too.
correction=Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/r2b-final-correction-u3e2_ph3')
for p in sorted(correction.rglob('actual-cell-production.json')):
 j=json.loads(p.read_text());add('source',j['sourceCommit'],{'descriptor':'post907-correction complete tree / '+str(p.relative_to(correction)),'role':'historical capture exact producer/reader'});add('lab',j['buildIdentity']['labHead'],{'descriptor':'post907-correction complete tree / '+str(p.relative_to(correction)),'role':'historical capture exact Lab/build producer'})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All owned exact Git URLs across published current/immutable readable Markdown plus retained prior reproduction/envelope refs and every historical/current capture producer pair. Each must resolve from ordinary clone objects and be ancestor of the shipped feature head; local/shared object existence alone is insufficient. Remote permissions/advertisement not claimed.','refs':list(refs.values())};(b/'published-exact-ref-scope.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'maintainedDocuments':len(scope['documents']),'exactRefs':len(refs)}))
