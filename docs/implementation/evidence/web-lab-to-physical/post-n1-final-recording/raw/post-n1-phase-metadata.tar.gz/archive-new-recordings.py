"""Run once after explicit settled recording boundary, never during physics/browser.
Retains this generation and the post907 correction/probe/N1 roots; old121 set untouched.
Readable static SDD and live execution metadata freeze separately after root coordination.
"""
from pathlib import Path
import json,sys,hashlib,subprocess,shutil,os,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];d=active/'.superpowers/sdd/README';e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';meta=stage/'archive-receipts';meta.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (b/'all-recording-chains-completed.json').is_file(),'RECORDINGS_NOT_SETTLED'
assert (b/'archive-boundary-admitted.json').is_file(),'EXPLICIT_OWNED_SETTLED_BOUNDARY_REQUIRED'
def pack(label,root):
 r=subprocess.run([sys.executable,str(b/'retain-tree.py'),label,str(root)],cwd=active,text=True,capture_output=True,timeout=7200);(meta/(label+'.tree-invocation.json')).write_text(json.dumps({'argv':[sys.executable,str(b/'retain-tree.py'),label,str(root)],'cwd':str(active),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');print(label,r.returncode,flush=True);assert r.returncode==0,r.stderr
# Safe exact N1 copy: fifth private original is external, its original inventory/receipt hashes stay unchanged.
n1=Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/r2b-final-n1-7cw84h_r');safe=stage/'safe-n1-original';assert not safe.exists();safe.mkdir();rows=[];excluded=[]
for directory,names,files in os.walk(n1,followlinks=False):
 out=safe/Path(directory).relative_to(n1);out.mkdir(parents=True,exist_ok=True)
 for name in list(names):
  p=Path(directory)/name
  if p.is_symlink():(out/name).symlink_to(os.readlink(p),target_is_directory=True);names.remove(name)
 for name in files:
  p=Path(directory)/name;rel=p.relative_to(n1).as_posix();q=out/name
  if rel=='settlement-processes.txt':
   assert p.stat().st_size==171347 and sha(p)=='0d6a4906c04b7242a484fd0de0ea277143542f974ec2458a2bd8b201302a5b41';excluded.append({'original':str(p),'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'reason':'Fifth cumulative private original: unrelated full-host process snapshot. Original remains external; never read for publication, engine-opened or archived. Original inventory/receipt hashes still attribute this exact excluded original.'});continue
  if p.is_symlink():q.symlink_to(os.readlink(p));continue
  shutil.copy2(p,q);assert sha(p)==sha(q);rows.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(excluded)==1
(meta/'n1-safe-copy-map.json').write_text(json.dumps({'original':str(n1),'safe':str(safe),'byteIdenticalFiles':rows,'excludedPrivate':excluded,'exactRootDisposition':{'path':str(d/'root-n1-private-settlement-disposition.json'),'bytes':(d/'root-n1-private-settlement-disposition.json').stat().st_size,'sha256':sha(d/'root-n1-private-settlement-disposition.json')},'scope':'Original settlement.json safe reference and artifact-index/receipt bindings are unchanged. No private file bytes included in any new archive.'},indent=2)+'\n')
plans=[('post907-correction',Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/r2b-final-correction-u3e2_ph3')),('post907-n1-probe',Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/r2b-scoped-replay-probe-wqb9d5vv')),('post907-n1-safe',safe),('post907-whole-branch-package',d/'final-whole-branch-package-907087c-bfde031'),('post907-correction-static-package',d/'final-correction-907-bfde'),('post907-n1-static-package',d/'final-n1-correction')]
# Exact pre-recording measured build/runtime copies, not ambient checkout/dependency roots.
boundary=json.loads((b/'isolated-producer-boundary.json').read_text());isolatedLab=Path(boundary['lab']);plans.extend([('post-n1-measured-lab-dist',isolatedLab/'dist'),('post-n1-installed-runtime',isolatedLab/'.runtime'/json.loads((b/'paths.json').read_text())['runtimeArtifact'])])
for copy in boundary['copies']:
 root=Path(copy['destination']);expected=copy['files'];actual=[]
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():actual.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
 assert actual==expected,('MEASURED_COPY_DRIFTED',root)
(meta/'measured-build-runtime-retention-boundary.json').write_text(json.dumps({'copies':boundary['copies'],'scope':'Exact200-file measured Lab dist and60-file installed runtime copied before mock/IR/R1. Verified against original per-file boundary again after all recordings, with no rebuild/re-export and no dependency traversal. Source/Lab producer/build identity stays0d/7c/1f968cd6/73ca9b.'},indent=2)+'\n')
for p in sorted(e.iterdir()):
 if p.is_dir() and p.name not in ['publication-staging','retained-inputs']:plans.append(('post-n1-'+p.name,p))
loose=stage/'new-recording-loose';assert not loose.exists();loose.mkdir()
for p in sorted(e.iterdir()):
 if p.is_file():shutil.copy2(p,loose/p.name);assert sha(p)==sha(loose/p.name)
plans.append(('post-n1-loose',loose))
(meta/'new-recording-archive-plan.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plans':[{'id':n,'source':str(r)} for n,r in plans],'excludedCurrentPreparedCorpus':{'path':str(e/'retained-inputs'),'selectorSha256':'30351aae82c52171d3744d07446fc13341850da7eda155976de586493498a56f','reason':'Public tool prepared same historical corpus; prior121 historical-retained-inputs archive remains unchanged and is referenced with its member index. No duplicate archive or new-current campaign identity assigned.'},'scope':'Every current settled E child and loose file except publication machinery/prepared duplicate corpus; complete post907 correction/probe/safeN1/wholebranchpackage. Separate safe metadata/readable freeze retains all new owner receipts/scripts/root records.'},indent=2)+'\n')
for label,root in plans:pack(label,root)
(meta/'new-recording-archives-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plans':len(plans),'scope':'All planned bytes/modes safely extracted/reassembled. Exact public reader outcomes remain separate.'},indent=2)+'\n')
