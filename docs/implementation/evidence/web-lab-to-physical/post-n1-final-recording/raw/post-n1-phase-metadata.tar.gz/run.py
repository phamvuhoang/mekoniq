import os, subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parent
source=base.parents[4]
env=os.environ.copy()
env.update(PATH='/Users/hoangpham/.nvm/versions/node/v24.22.2/bin:'+str(source/'.venv-irsim/bin')+':'+env['PATH'],PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-p no:cacheprovider',MEKONIQ_COMMISSIONING_PYTHON=str(source/'.venv-commissioning/bin/python'),MEKONIQ_RETAINED_INPUTS='/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-post-n1-final-0d46403-7c97b20-f56acbhh/retained-inputs/inputs.json',MEKONIQ_RETAINED_INPUTS_SHA256='30351aae82c52171d3744d07446fc13341850da7eda155976de586493498a56f')
for key in ['MEKONIQ_TEST_SERVICE_RECEIPT','LAB_CONTAINER_IMAGE','LAB_WEB05_EVIDENCE_DIR','LAB_TEST_PAIRING_TOKEN']:
 env.pop(key,None)
name,repo,*argv=sys.argv[1:]
cwd=source if repo=='source' else source.parent/repo
sys.exit(subprocess.call(['node',str(base/'check.mjs'),name,str(cwd),*argv],env=env))
