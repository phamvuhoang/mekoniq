from pathlib import Path
import json,hashlib,collections,datetime
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);assert (b/'all-recording-chains-completed.json').is_file();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'paths':json.loads((b/'paths.json').read_text()),'checks':{},'qualifications':{},'testResults':{}}
for p in sorted((b/'checks').glob('*.receipt.json')):
 j=json.loads(p.read_text());log=p.with_name(p.name.replace('.receipt.json','.log'));assert log.is_file() and sha(log)==j['logSha256'];data['checks'][p.name.replace('.receipt.json','')]={k:j.get(k) for k in ['startedAt','finishedAt','exitCode','signal','before','after','logSha256']}
profiles=['mujoco-linux-amd64','mujoco-linux-arm64','engineering-amd64','engineering-arm64','xarm6-jazzy-sim','puma560-linuxcnc-sim'];r3names=[prefix+profile for profile in profiles for prefix in ['prepare-','export-handoff-','handoff-','record-r3-','readback-r3-','acceptance-r3-']];data['r3Preparation']={'profiles':profiles,'expectedInvocations':36,'actualOwn0':sum(data['checks'].get(n,{}).get('exitCode')==0 and data['checks'].get(n,{}).get('signal') is None for n in r3names),'missingInvocations':[n for n in r3names if n not in data['checks']],'nonzeroInvocations':{n:data['checks'][n] for n in r3names if n in data['checks'] and (data['checks'][n].get('exitCode')!=0 or data['checks'][n].get('signal') is not None)},'actualCandidates':sum((e/('r3-'+profile+'-prepared/qualification.json')).is_file() for profile in profiles)}
for name in ['irsim','r1','r11','r2a-partial','r2b',*[p.name for p in sorted(e.glob('r3-*-prepared'))]]:
 p=e/name/'qualification.json'
 if not p.is_file():data['qualifications'][name]={'exists':False,'status':'not_run','reason':'No real candidate from actual recorded admission; no fabricated lineage'};continue
 j=json.loads(p.read_text());cases=j.get('cases',{});suites=j.get('suites',[]);data['qualifications'][name]={'exists':True,'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'release':j.get('release'),'accepted':j.get('accepted'),'cases':cases,'caseStatusCounts':dict(collections.Counter(v['status'] for v in cases.values())),'gates':j.get('gates',{}),'suites':[{k:v for k,v in s.items() if k in ['id','repo','kind','exitCode','result','notRun','reason']} for s in suites],'identity':j.get('identity'),'checker':j.get('checker'),'notRun':j.get('notRun')}
for p in sorted(e.glob('*.json')):
 try:j=json.loads(p.read_text())
 except Exception:continue
 if isinstance(j,dict) and 'numPassedTests' in j:data['testResults'][p.name]={k:j.get(k) for k in ['numPassedTests','numFailedTests','numPendingTests','numTotalTests','numPassedTestSuites','numFailedTestSuites','numPendingTestSuites','success']}
mock=e/'mock-regression/manifest.json'
if mock.is_file():
 j=json.loads(mock.read_text());data['mockRegression']={k:j.get(k) for k in ['schema','schemaVersion','ci','suite','commands','runs','notRun','identity','identityCheckpoints']}
data['mockRawTestFailures']=[]
for name in ['source-unit.json','source-engineering.json']:
 file=e/'mock-regression'/name
 if not file.exists():continue
 j=json.loads(file.read_text())
 for suite in j.get('testResults',[]):
  for a in suite.get('assertionResults',[]):
   if a.get('status')=='failed':data['mockRawTestFailures'].append({'report':name,'file':suite.get('name'),'test':a.get('fullName'),'failureMessages':a.get('failureMessages'),'durationMs':a.get('duration')})
data['supplemental']={}
for kind in ['r2a']:
 root=e/(kind+'-supplemental-current-gui');index=root/'execution-index.json'
 if index.is_file():data['supplemental'][kind]={'rows':json.loads(index.read_text()),'completeCoverage':json.loads((root/'row-coverage.json').read_text()) if (root/'row-coverage.json').exists() else None,'tableSha256':sha(root/'table.json')}
capture=json.loads((e/'production-performance/actual-cell-production.json').read_text());assessment=json.loads((e/'production-performance/assessment.json').read_text());data['capture']={'sourceCommit':capture['sourceCommit'],'runId':capture['runId'],'buildIdentity':capture['buildIdentity'],'achievedRate':capture['achievedRate'],'selectedRate':capture['selectedRate'],'simSeconds':capture['simSeconds'],'actualRenderIntervals':capture['actualRenderIntervals'],'workerIPC':capture['workerIPC'],'pause':capture['pause'],'assessment':assessment};(b/'observed-results.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps({'checks':len(data['checks']),'qualifications':len(data['qualifications']),'testReports':len(data['testResults']),'cases':{k:v.get('caseStatusCounts',v.get('status')) for k,v in data['qualifications'].items()}}))
