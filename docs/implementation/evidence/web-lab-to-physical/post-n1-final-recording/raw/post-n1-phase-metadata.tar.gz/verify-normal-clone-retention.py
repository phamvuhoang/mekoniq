from pathlib import Path
import json,hashlib,subprocess,sys,datetime
b=Path(__file__).resolve().parent;clone=json.loads((b/'normal-publication-clones.json').read_text());root=Path(clone['workspace'])/'source';raw=root/'docs/implementation/evidence/web-lab-to-physical/post-n1-final-recording';docs=root/'docs/implementation/web-lab-to-physical/post-n1-final-recording';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();failures=[];verified=[]
def check(p,expectedBytes,expectedSha,kind):
 ok=p.is_file() and p.stat().st_size==expectedBytes and sha(p)==expectedSha;row={'path':str(p.relative_to(root)),'kind':kind,'bytes':expectedBytes,'sha256':expectedSha,'verified':ok};verified.append(row)
 if not ok:failures.append(row)
indices=sorted((raw/'raw').glob('*.members.json'));assert indices
for p in indices:
 j=json.loads(p.read_text());archive=raw/'raw'/Path(j['archive']).name;check(archive,j['archiveBytes'],j['archiveSha256'],'new archive exact compressed bytes')
 for row in j['files']:
  if row['sha256'] in {r['originalSha256'] for r in json.loads((raw/'privacy-exclusions.json').read_text())['exclusions']}:failures.append({'index':str(p.relative_to(root)),'privateOriginalIncluded':row['path']})
for p in [root/'docs/implementation/web-lab-to-physical/retention/full-readable-copy-map.json',docs/'retention/current-readable-location-map.json']:
 j=json.loads(p.read_text())
 for row in j['files']:check(root/row['destination'],row['bytes'],row['sha256'],'complete readable snapshot location')
for row in json.loads((raw/'index.json').read_text()).get('priorGeneration',{}).get('files',[]):check(root/row['path'],row['bytes'],row['sha256'],'unchanged prior boundary descriptor')
private=json.loads((raw/'privacy-exclusions.json').read_text());assert len(private['exclusions'])==5
# Check exact excluded original hashes only. Marked public derivatives may legitimately mention the same leaf names.
for p in raw.rglob('*'):
 if p.is_file() and p.suffix not in ['.gz'] and p.stat().st_size in {r['originalBytes'] for r in private['exclusions']}:
  h=sha(p)
  if h in {r['originalSha256'] for r in private['exclusions']}:failures.append({'privateOriginalDirectFile':str(p.relative_to(root)),'sha256':h})
oldpaths=['docs/implementation/evidence/web-lab-to-physical/final-recording','docs/implementation/web-lab-to-physical/retention'];r=subprocess.run(['git','diff','--name-only','907087c4f2a4d6bc1348f50177c19143d956e9d9','HEAD','--',*oldpaths],cwd=root,text=True,capture_output=True);assert r.returncode==0
if r.stdout.strip():failures.append({'priorAuditedRetentionChanged':r.stdout.splitlines()})
oldreport=root/'docs/implementation/web-lab-to-physical/retention/sdd/README/task-final-recording-report.md';check(oldreport,190669,'2ade80f00a46d04f29a8f55d8f3007f0fbfba13695dd8cbe618635c1e0d56984','immutable old complete report')
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':clone['workspace'],'publicationHeads':clone['heads'],'newArchiveCount':len(indices),'readableAndBoundaryChecks':len(verified),'verified':verified,'privateOriginalExclusions':5,'old907RetentionPathsUnchanged':not r.stdout.strip(),'failures':failures,'scope':'New archive compressed hashes and exact current/prior readable locations checked in ordinary nonshared clones; all five exact private-original hashes excluded. Earlier121 archive payloads are unchanged Git-history references, not gratuitously decompressed or rerun. Safe extraction/member/mode/public-reader receipts are retained separately.'};(b/'normal-clone-retention-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'archives':len(indices),'checks':len(verified),'failures':len(failures)}));raise SystemExit(bool(failures))
