// Independent unchanged table invocations; never spliced into a qualification.
import {SUITES_R2A,SUITES_R2B} from '../../../../../scripts/sim-extension-qualification.mjs';
import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync,lstatSync,cpSync,renameSync} from 'node:fs';
import {join,resolve} from 'node:path';
import {realpathSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const kind=process.argv[2];if(!['r2a','r2b'].includes(kind))throw Error('TABLE_REQUIRED');
const b=import.meta.dirname,source=resolve(b,'../../../../..'),lab=resolve(source,'../lab'),paths=JSON.parse(readFileSync(join(b,'paths.json'))),boundary=JSON.parse(readFileSync(join(b,'isolated-producer-boundary.json'))),table=kind==='r2a'?SUITES_R2A:SUITES_R2B,out=join(paths.root,kind+'-supplemental-current-gui');if(existsSync(out))throw Error('OUT_EXISTS');
mkdirSync(out);for(const d of ['suites','screens','pycache','default-copies','default-originals'])mkdirSync(join(out,d));
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const inv=(root,prefix='')=>readdirSync(join(root,prefix)).sort().flatMap(name=>{const rel=prefix?prefix+'/'+name:name,p=join(root,rel),s=lstatSync(p);if(s.isSymbolicLink())throw Error('DEFAULT_SYMLINK');return s.isDirectory()?inv(root,rel):[{path:rel,bytes:s.size,sha256:hash(p)}];});
writeFileSync(join(out,'table.json'),JSON.stringify({source:'scripts/sim-extension-qualification.mjs',sourceSha256:hash(join(source,'scripts/sim-extension-qualification.mjs')),suites:table,scope:'Independent supplemental observations, never qualification status splicing'},null,2));const results=[];
const save=()=>writeFileSync(join(out,'execution-index.json'),JSON.stringify(results,null,2));
for(const s of table){
 if(s.image||s.id==='web-container'){results.push({id:s.id,status:'not_run',reason:'Latest actual Docker admission unavailable; no repeated probe/build or borrowed image/service receipt absent state change'});save();continue;}
 const isolated=s.kind==='playwright'&&s.command?.[0]==='scripts/test-irsim-e2e.mjs',cwd=s.repo==='lab'?(isolated?realpathSync(boundary.lab):lab):source,abs=join(out,'suites',s.id+(s.kind==='pytest'?'.xml':'.json')),shots=join(out,'screens',s.id);mkdirSync(shots);
 const env=s.kind==='vitest'?{LAB_V2_CLEAN_EXPORT:'1',MEKONIQ_WEBOTS_HOME:'/Applications/Webots.app'}:s.kind==='pytest'?{PYTHONPATH:(s.pythonPath??[]).map(p=>join(source,p)).join(':'),PYTHONDONTWRITEBYTECODE:'1',PYTHONPYCACHEPREFIX:join(out,'pycache'),PYTHONNOUSERSITE:'1',MEKONIQ_WEBOTS_HOME:'/Applications/Webots.app'}:{LAB_PW_JSON:abs,LAB_IRSIM_SCREENSHOTS:shots,LAB_EVIDENCE_DIR:shots,...!isolated?{LAB_PW_OUTPUT_DIR:join(out,'playwright',s.id)}:{},MEKONIQ_WEBOTS_HOME:'/Applications/Webots.app'};
 const command=s.kind==='vitest'?[process.execPath,join(cwd,'node_modules/vitest/vitest.mjs'),'run',...s.files,'--reporter=json','--outputFile='+abs,'--reporter=default']:s.kind==='pytest'?[join(source,s.python),'-m','pytest','-p','no:cacheprovider',...s.files,'-q','--junitxml='+abs]:[process.execPath,...s.command.map(a=>a.endsWith('.mjs')?join(cwd,a):a)];
 const defaultDir=join(cwd,'test-results');if(isolated&&existsSync(defaultDir))throw Error('ISOLATED_DEFAULT_NOT_PRISTINE:'+s.id);
 const argv=['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT',...Object.entries(env).map(([k,v])=>k+'='+v),'caffeinate','-dims','perl','-e','alarm 3600; exec @ARGV',...command],r=spawnSync('python3',[join(b,'run.py'),kind+'-supplement-'+s.id,cwd,...argv],{stdio:'inherit'});let defaultPreservation=null;
 if(isolated&&existsSync(defaultDir)){const before=inv(defaultDir),copy=join(out,'default-copies',s.id),retainedOriginal=join(out,'default-originals',s.id);cpSync(defaultDir,copy,{recursive:true,force:false,errorOnExist:true,preserveTimestamps:true});if(JSON.stringify(inv(defaultDir))!==JSON.stringify(before)||JSON.stringify(inv(copy))!==JSON.stringify(before))throw Error('DEFAULT_COPY_CHANGED');renameSync(defaultDir,retainedOriginal);if(existsSync(defaultDir)||JSON.stringify(inv(retainedOriginal))!==JSON.stringify(before))throw Error('DEFAULT_RETAIN_FAILED');defaultPreservation={original:defaultDir,copy,retainedOriginal,files:before,originalPathAbsentBeforeOwner:true,policy:'Only fresh owned isolated output moved after complete byte verification; raw JSON original paths preserved, active failure untouched'};writeFileSync(join(out,s.id+'-default-map.json'),JSON.stringify(defaultPreservation,null,2));}
 const actualResults=[abs,...s.kind==='playwright'&&s.command?.[0]==='scripts/test-mock-e2e.mjs'?[abs.replace(/\.json$/,`-${s.command.at(-1).replace(/\.spec\.ts$/,'')}.json`)]:[]].filter(p=>existsSync(p));results.push({id:s.id,repo:s.repo,kind:s.kind,files:s.files??null,command,cwd,env,exitCode:r.status,signal:r.signal,declaredResult:abs,actualResults,defaultPreservation,isolatedBoundary:isolated?join(b,'isolated-producer-boundary.json'):null});save();console.log('SUPPLEMENT',kind,s.id,r.status);
 if(r.status){writeFileSync(join(out,s.id+'-needs-inspection.json'),JSON.stringify(results.at(-1),null,2));}
}
const ids=results.map(s=>s.id);if(new Set(ids).size!==table.length||ids.length!==table.length||table.some(s=>!ids.includes(s.id)))throw Error('TABLE_NOT_EXACT_ONCE');writeFileSync(join(out,'row-coverage.json'),JSON.stringify({ids,exactlyOnce:true,scope:'Observation index only; skipped prerequisites remain not_run and all failed exits remain failed; no qualification output'},null,2));

process.exitCode=results.some(row=>row.exitCode!==undefined&&row.exitCode!==0)?1:0;
