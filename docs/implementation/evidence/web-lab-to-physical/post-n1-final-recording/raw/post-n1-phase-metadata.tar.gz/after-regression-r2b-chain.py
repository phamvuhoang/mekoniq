from pathlib import Path
import subprocess,json,sys,time,datetime,os
b=Path(__file__).resolve().parent;source=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);deadline=time.monotonic()+25200
while not (b/'regression-r3-completed.json').is_file():
 assert time.monotonic()<deadline,'REGRESSION_NOT_SETTLED';time.sleep(5)
outcomes=json.loads((b/'lineage-outcomes.json').read_text())
if not outcomes['r2aPartialExists']:
 (b/'dependent-r2b-not-run.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'invoked':False,'reason':'No real current partial R2a after actual upstream admission failure; no fabricated mandatory lineage. Root must receive actual blocker while independent available scope continues.','actualUpstream':outcomes},indent=2)+'\n');raise SystemExit(2)
lab=Path(json.loads((b/'isolated-producer-boundary.json').read_text())['lab']).resolve()
def run(name,args,bound=3600,allowed=(0,)):
 (b/'chain-stage.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':os.getpid(),'stage':name,'scope':'Serialized required stage; no competing engine/browser/archive'},indent=2)+'\n');r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);print('POST_N1_R2B',name,r,flush=True);assert r in allowed,(name,r);return r
(b/'dependent-r2b-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Required unchanged available R2a rows, real3engine study, exact web assembly and normal fullR2b using all real current inputs; no independent R2b reassurance-table rerun'},indent=2)+'\n')
run('r2a-supplemental',['node',b/'supplement-tables-current-gui.mjs','r2a'],7200,(0,1))
run('semantic-study',['node',b/'owned-command.mjs',e/'semantic-study-process','1300000','env','MEKONIQ_WEBOTS_HOME=/Applications/Webots.app','SIMULATION_STUDY_OUT='+str(e/'semantic-study'),'pnpm','exec','vitest','run','tests/integration/cross-engine-fd01.test.ts','--reporter=default','--reporter=json','--outputFile='+str(e/'semantic-study-tests.json')],1420,(0,1))
run('assemble-web-record',[sys.executable,b/'assemble-web-record.py'],300)
run('web-readback',['node',b/'read-web.mjs'],300,(1,))
if not (e/'semantic-study/study-input.json').is_file():
 (b/'full-r2b-not-run.json').write_text(json.dumps({'invoked':False,'reason':'Actual3engine study produced no required input; full qualification cannot be fabricated.'},indent=2)+'\n');raise SystemExit(2)
run('record-r2b-full',['env','PAYLOAD_CAMPAIGN_EVIDENCE='+str(e/'payload-campaign'),'node','scripts/record-sim-extension.mjs','--release','r2b','--scope','full','--out',e/'r2b','--candidate-id','r2b-post-n1-0d46403-7c97b20','--r2a-record',e/'r2a-partial','--physics-campaign',e/'payload-campaign','--cell-campaign',e/'cell-campaign','--semantic-study',e/'semantic-study/study-input.json','--web-record',e/'web-record','--lab',lab],7200,(1,2))
if not (e/'r2b/qualification.json').is_file():raise RuntimeError('R2B_NO_RECORD: actual prerequisite refusal retained; no manufactured candidate')
code="import {verifyR2bDirectory} from './scripts/r2b-readback.mjs';const issues=await verifyR2bDirectory(process.argv[1]);console.log(JSON.stringify(issues));process.exit(issues.length?1:0);"
run('readback-r2b-full',['node','--input-type=module','-e',code,e/'r2b'],600,(1,))
run('acceptance-r2b-full',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(e/'r2b'),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/'acceptance-r2b-full.json')],600,(1,))
(b/'all-recording-chains-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'These required invocations settled. Failed capture/partial/fullR2b, unavailable prerequisites, skipped tests and native/physical gates remain their actual failed/not_run states; no accepted promotion.'},indent=2)+'\n')
