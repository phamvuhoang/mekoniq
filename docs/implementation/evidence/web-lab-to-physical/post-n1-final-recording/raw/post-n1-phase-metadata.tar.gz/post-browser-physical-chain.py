from pathlib import Path
import subprocess,json,sys,time,datetime,os
b=Path(__file__).resolve().parent;source=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);deadline=time.monotonic()+1200
while not (b/'checks/stock-launcher-browser.receipt.json').is_file():
 assert time.monotonic()<deadline,'STOCK_RECEIPT_WAIT_BOUND';time.sleep(2)
for name in ['production-closed-browser','production-replay-browser']:
 r=json.loads((b/'checks'/(name+'.receipt.json')).read_text());assert r['exitCode']==0 and r['signal'] is None,(name,r['exitCode'])
cleanup=json.loads((e/'stock-launcher-web-active/cleanup.json').read_text());assert cleanup['launcher']['code']==0
for port in [4175,4176]:
 r=subprocess.run(['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN'],capture_output=True,text=True);assert r.returncode==1 and not r.stdout,('PORT_NOT_SETTLED',port)
def run(name,args,bound=3600,allowed=(0,)):
 (b/'chain-stage.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':os.getpid(),'stage':name,'scope':'Serialized required stage; no other engine/browser/archive'},indent=2)+'\n');r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);print('POST_N1_STAGE',name,r,flush=True);assert r in allowed,(name,r);return r
(b/'post-browser-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Serial isolated preparation, fresh payload+cell campaigns and physical row, complete mock and IR; no retry or oldtuple evidence promotion'},indent=2)+'\n')
run('prepare-isolated-producer',[sys.executable,b/'prepare-isolated-producer.py'],1200)
run('prepare-retained-inputs',['node','scripts/prepare-retained-inputs.mjs','/tmp/b10-fix1-inputs/inputs.json','30351aae82c52171d3744d07446fc13341850da7eda155976de586493498a56f',e/'retained-inputs'],300)
run('payload-campaign',['node','scripts/lab-mujoco.mjs','run','--campaign','payload-v1','--out',e/'payload-campaign'],2400)
run('verify-payload-campaign',['node','scripts/lab-mujoco.mjs','verify','--input',e/'payload-campaign'],300)
run('mj-evidence-row',['env','PAYLOAD_CAMPAIGN_EVIDENCE='+str(e/'payload-campaign'),'pnpm','exec','vitest','run','tests/integration/mujoco-payload-campaign.test.ts','tests/integration/physics-evidence.test.ts','--reporter=default','--reporter=json','--outputFile='+str(e/'mj-evidence-result.json')],600)
run('mj-evidence-row-readback',['node',b/'row-readback.mjs',e/'mj-evidence-result.json',e/'mj-row-assessment.json'],300)
run('cell-campaign',['node','scripts/lab-mujoco.mjs','run','--campaign','mj-cell-bv01-v1','--out',e/'cell-campaign'],3600)
run('verify-cell-campaign',['node','scripts/lab-mujoco.mjs','verify','--input',e/'cell-campaign'],300)
run('mock-regression',['env','LAB_PYTHON='+str(source/'.venv-commissioning/bin/python'),'node','../lab/scripts/record-regression.mjs','--suite','physical-robot-lab','--out',e/'mock-regression'],7200)
run('mock-acceptance',['env','LAB_V2_REGRESSION_DIR='+str(e/'mock-regression'),'LAB_V2_REQUIRE_LAB_FIXTURES=1','LAB_V2_MOCK_EVIDENCE='+str(e/'mock-acceptance-evidence.json'),'pnpm','exec','vitest','run','tests/acceptance/lab-v2-mock.acceptance.test.ts','--reporter=default','--reporter=json','--outputFile='+str(e/'mock-acceptance-tests.json')],600)
lab=Path(json.loads((b/'isolated-producer-boundary.json').read_text())['lab']).resolve()
run('record-irsim',['node','scripts/record-irsim.mjs','--campaign','c02-qualification','--out',e/'irsim','--candidate-id','irsim-post-n1-0d46403-7c97b20','--irsim-python',source/'.venv-irsim/bin/python','--lab',lab],7200)
run('verify-irsim-campaign',['node','scripts/lab-irsim.mjs','verify','--input',e/'irsim/campaign'],300)
run('acceptance-irsim',['env','LAB_IRSIM_EVIDENCE_DIR='+str(e/'irsim'),'pnpm','test:acceptance','--','linkforge-irsim','--reporter=default','--reporter=json','--outputFile='+str(e/'acceptance-irsim.json')],300)
(b/'physical-mock-irsim-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Required fresh physical row/campaigns, complete mock and IR commands settled; individual scope/skips/readback and actual outcomes remain authoritative; no acceptance promotion.'},indent=2)+'\n')
