"""Audit declared final docs in an actual normal four-repository clone layout.
Checks local file/heading/explicit-ID links, inline/reference/HTML syntax and owned exact Git objects.
External hosting permissions/availability and renderer-specific anchor behavior are not asserted.
"""
from pathlib import Path
from urllib.parse import urlsplit,unquote
import json,re,subprocess,sys,hashlib,datetime,html
workspace=Path(sys.argv[1]).resolve(strict=True);scope=json.loads(Path(sys.argv[2]).read_text());out=Path(sys.argv[3]);assert not out.exists()
def run(repo,args):
 r=subprocess.run(['git',*args],cwd=repo,text=True,capture_output=True,timeout=60);return r

def visible_lines(text,keep_inline=False):
 result=[];fence=None
 for line in text.splitlines():
  m=re.match(r'^\s*(`{3,}|~{3,})',line)
  if m:
   marker=m.group(1)[0]
   if fence==marker:fence=None
   elif fence is None:fence=marker
   result.append('');continue
  result.append('' if fence else line if keep_inline else re.sub(r'(`+).*?\1','',line))
 return result

def anchors(text):
 ids=set(re.findall(r'(?:id|name)\s*=\s*["\']([^"\']+)',text));counts={}
 for line in visible_lines(text,keep_inline=True):
  m=re.match(r'^ {0,3}#{1,6}\s+(.+?)\s*#*$',line)
  if not m:continue
  heading=html.unescape(re.sub(r'<[^>]*>','',m.group(1)))
  heading=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',heading)
  slug=re.sub(r'[^\w\-\s]','',heading.lower(),flags=re.UNICODE).replace(' ','-');n=counts.get(slug,0);counts[slug]=n+1;ids.add(slug+('-'+str(n) if n else ''))
 return ids

def links(text):
 lines=visible_lines(text);refs={};items=[]
 for number,line in enumerate(lines,1):
  m=re.match(r'^ {0,3}\[([^\]]+)\]:\s*(<[^>]*>|\S+)',line)
  if m:refs[m.group(1).strip().lower()]=m.group(2).strip('<>');items.append((number,'reference-definition',m.group(2).strip('<>')))
 for number,line in enumerate(lines,1):
  if re.match(r'^ {0,3}\[[^\]]+\]:',line):continue
  for m in re.finditer(r'!?\[[^\]\n]*\]\(\s*(<[^>]*>|[^\s)]+)(?:\s+["\'][^\n]*?["\'])?\s*\)',line):items.append((number,'inline',m.group(1).strip('<>')))
  for m in re.finditer(r'!?\[([^\]\n]+)\](?:\[([^\]\n]*)\])?',line):
   key=(m.group(2) or m.group(1)).strip().lower()
   if key in refs and (m.end()==len(line) or line[m.end()]!='('):items.append((number,'reference-use',refs[key]))
  for m in re.finditer(r'(?:href|src)\s*=\s*["\']([^"\']+)["\']',line):items.append((number,'html',html.unescape(m.group(1))))
 return items

repos={k:workspace/v for k,v in scope.get('gitRepositories',{}).items()};identities={}
for name in ['source','lab','web','trial']:
 p=workspace/name;assert p.is_dir(),name;r=run(p,['rev-parse','HEAD']);assert r.returncode==0;identities[name]=r.stdout.strip()
rows=[]
for name in scope['documents']:
 p=workspace/name;assert p.resolve().is_relative_to(workspace) and p.is_file(),name
 for number,syntax,href in links(p.read_text()):
  row={'file':name,'line':number,'syntax':syntax,'href':href};url=urlsplit(href)
  if url.scheme or url.netloc:
   parts=[unquote(x) for x in url.path.strip('/').split('/')];key='/'.join(parts[:2]);owned=repos.get(key)
   if url.hostname=='github.com' and owned and len(parts)>=4 and parts[2] in ['blob','tree','commit'] and re.fullmatch(r'[0-9a-f]{40}',parts[3]):
    ref=parts[3];path='/'.join(parts[4:]);obj=ref+(':'+path if path else '');r=run(owned,['cat-file','-e',obj]);row.update({'scope':'owned-exact-Git-object','repository':str(owned.relative_to(workspace)),'commit':ref,'path':path,'resolved':r.returncode==0})
    ancestry=run(owned,['merge-base','--is-ancestor',ref,'HEAD']);row.update({'reachableFromShippedHead':ancestry.returncode==0,'reachabilityArgv':['git','merge-base','--is-ancestor',ref,'HEAD'],'reachabilityExit':ancestry.returncode,'shippedHead':run(owned,['rev-parse','HEAD']).stdout.strip()});row['resolved']=row['resolved'] and ancestry.returncode==0
    if row['resolved'] and url.fragment and parts[2]=='blob':
     data=run(owned,['show',obj]);frag=unquote(url.fragment);m=re.fullmatch(r'L(\d+)(?:-L(\d+))?',frag)
     row['fragmentResolved']=bool(m and 1<=int(m.group(1))<=int(m.group(2) or m.group(1))<=len(data.stdout.splitlines())) if m else frag in anchors(data.stdout)
   else:row.update({'scope':'external-reference','checked':False,'reason':'Remote hosting/permissions/availability outside this local clone audit'})
  else:
   target=(p.parent/unquote(url.path)).resolve() if url.path else p.resolve();inside=target.is_relative_to(workspace);row.update({'scope':'local-clone','target':str(target.relative_to(workspace)) if inside else str(target),'withinDocumentedWorkspace':inside,'resolved':inside and target.exists()})
   if row['resolved'] and url.fragment:
    fragment=unquote(url.fragment);content=target/'README.md' if target.is_dir() else target
    if content.is_file() and content.suffix.lower() in ['.md','.html','.htm']:
     text=content.read_text();m=re.fullmatch(r'L(\d+)(?:-L(\d+))?',fragment);row['fragmentResolved']=bool(m and 1<=int(m.group(1))<=int(m.group(2) or m.group(1))<=len(text.splitlines())) if m else fragment in anchors(text)
    else:row['fragmentResolved']=False;row['fragmentReason']='No supported heading/explicit-ID target for fragment'
  if row.get('scope')=='local-clone' and row.get('resolved'):
   rel=target.relative_to(workspace);repoName=rel.parts[0] if rel.parts else '';repo=workspace/repoName
   if repoName in identities:
    tracked=run(repo,['ls-files','-z']);assert tracked.returncode==0
    files=set(tracked.stdout.split('\0'))-{''};directories={''}
    for name in files:
     parts=name.split('/')
     for n in range(1,len(parts)):directories.add('/'.join(parts[:n]))
    local=Path(*rel.parts[1:]).as_posix() if len(rel.parts)>1 else '';local='' if local=='.' else local
    row['exactCaseGitTracked']=local in (directories if target.is_dir() else files);row['resolved']=row['resolved'] and row['exactCaseGitTracked']
  rows.append(row)
failures=[r for r in rows if r.get('resolved') is False or r.get('fragmentResolved') is False]
result={'version':1,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace':str(workspace),'repositoryHeads':identities,'scope':scope,'syntax':'Declared inline/reference/HTML links outside fenced and inline code; Unicode GitHub-style heading plus explicit-ID heuristic; renderer-specific nuances and external server access not claimed','documents':[{'path':n,'sha256':hashlib.sha256((workspace/n).read_bytes()).hexdigest()} for n in scope['documents']],'links':rows,'failures':failures,'counts':{'links':len(rows),'local':sum(r['scope']=='local-clone' for r in rows),'exactGit':sum(r['scope']=='owned-exact-Git-object' for r in rows),'externalUnverified':sum(r['scope']=='external-reference' for r in rows),'failed':len(failures)}}
out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps(result['counts']));raise SystemExit(bool(failures))
