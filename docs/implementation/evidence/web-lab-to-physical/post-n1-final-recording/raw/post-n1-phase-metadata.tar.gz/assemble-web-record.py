from pathlib import Path
import json,hashlib,shutil,datetime
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);out=e/'web-record';assert not out.exists();maps=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copytree(original,target):
 shutil.copytree(original,target)
 for p in sorted(original.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():q=target/p.relative_to(original);assert sha(p)==sha(q);maps.append({'source':str(p),'destination':str(q),'bytes':p.stat().st_size,'sha256':sha(p)})
copytree(e/'production-performance',out);copytree(e/'production-browser',out/'browser-run')
for name in ['browser-runtime-identity.json','browser-result.json','browser-case.json','report-replay-fetched-cursor0-390-dom.json','report-replay-fetched-cursor0-390-image.json','report-replay-fetched-cursor0-390.png']:
 p=e/'production-browser'/name;q=out/name;assert p.is_file() and not q.exists();shutil.copy2(p,q);assert sha(p)==sha(q);maps.append({'source':str(p),'destination':str(q),'bytes':p.stat().st_size,'sha256':sha(p)})
(b/'web-assembly.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Complete byte-identical current failed production capture plus namespaced complete current successful same-build browser output and six required public browser artifacts. No outcome/path/hash editing; standalone strict replay remains separately retained.','output':str(out),'files':maps},indent=2)+'\n');print(json.dumps({'copiedFiles':len(maps),'output':str(out)}))
