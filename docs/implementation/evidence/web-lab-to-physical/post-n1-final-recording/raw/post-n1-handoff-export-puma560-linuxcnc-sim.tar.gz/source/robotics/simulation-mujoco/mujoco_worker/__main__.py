"""python -m mujoco_worker --run-id ID --bundle-root DIR --schema-dir DIR --lock-digest HEX [--scene-digest HEX]
NDJSON: one request per stdin line, one response per stdout line; every log goes to stderr. Fatal protocol or engine faults answer once and exit non-zero."""
import argparse
import contextlib
import json
import sys

from .protocol import MAX_LINE_BYTES, PROTOCOL, WorkerError, load_validators, parse_line
from .session import WorkerSession


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--bundle-root", required=True)
    ap.add_argument("--schema-dir", required=True)
    ap.add_argument("--lock-digest", required=True)
    ap.add_argument("--scene-digest")
    ap.add_argument("--payload-perturbation", choices=["payload-cup-forward-impulse-v1"])
    args = ap.parse_args(argv)
    out = sys.stdout
    validator, _ = load_validators(args.schema_dir)
    session = WorkerSession(run_id=args.run_id, bundle_root=args.bundle_root, lock_digest=args.lock_digest, expected_scene_digest=args.scene_digest, schema_dir=args.schema_dir, payload_perturbation=args.payload_perturbation)

    def send(response):
        out.write(json.dumps(response, separators=(",", ":"), allow_nan=False) + "\n")
        out.flush()

    code = 0
    with contextlib.redirect_stdout(sys.stderr):  # an engine or library print must never corrupt the response stream
        while True:
            raw = sys.stdin.buffer.readline(MAX_LINE_BYTES + 2)
            if not raw:
                break
            try:
                request = parse_line(raw, validator)
            except WorkerError as e:
                send({"protocol": PROTOCOL, "requestId": "invalid", "runId": args.run_id, "bootId": session.boot_id, "tick": session.tick, "ok": False, "error": {"code": e.code, "detail": e.detail}})
                session._fail()
                code = 1
                break
            response = session.handle(request)
            send(response)
            if session.state == "failed":
                code = 1
                break
    session.end()
    return code


if __name__ == "__main__":
    sys.exit(main())
