from pathlib import Path
import zipfile,hashlib,subprocess,json
for p in Path('/Users/hoangpham/Library/Caches/pip/http-v2').rglob('*.body'):
 if not zipfile.is_zipfile(p): continue
 with zipfile.ZipFile(p) as z:
  matches=[n for n in z.namelist() if n.startswith('six-') and n.endswith('.dist-info/METADATA')]
  if not matches: continue
  version=matches[0].split('.dist-info')[0].split('-',1)[1]
  wheel=Path(__file__).parent/f'six-{version}-py2.py3-none-any.whl'
  if wheel.exists(): raise SystemExit('REFUSE_OVERWRITE')
  wheel.write_bytes(p.read_bytes())
  subprocess.run([str(Path('.venv-commissioning/bin/python').absolute()),'-m','pip','install','--no-index','--no-deps',str(wheel)],check=True)
  print(json.dumps({'wheel':str(wheel),'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()}));break
else: raise SystemExit('SIX_OFFLINE_WHEEL_MISSING')
