from pathlib import Path
import subprocess,sys,json,hashlib,shutil
root=Path.cwd();evidence=root/'.superpowers/sdd/03-r3-linux-readiness/evidence-L05'
cache=Path('/Users/hoangpham/Library/Caches/pip/http-v2/b/4/e/9/6/b4e9620d34c4c3af841265cf8b90b558623e1faf947bbd60def37523.body')
wheel=evidence/'rfc3339_validator-0.1.4-py2.py3-none-any.whl'
if wheel.exists() or (root/'.venv-commissioning').exists(): raise SystemExit('REFUSE_OVERWRITE')
shutil.copyfile(cache,wheel)
subprocess.run(['/opt/homebrew/bin/python3.11','-m','venv',str(root/'.venv-commissioning')],check=True)
site=root/'.venv-commissioning/lib/python3.11/site-packages'
(site/'existing-irsim-deps.pth').write_text(str(root/'.venv-irsim/lib/python3.11/site-packages')+'\n')
subprocess.run([str(root/'.venv-commissioning/bin/python'),'-m','pip','install','--no-index','--no-deps',str(wheel)],check=True)
print(json.dumps({'python':str(root/'.venv-commissioning/bin/python'),'existingDependencyRoot':str(root/'.venv-irsim/lib/python3.11/site-packages'),'offlineWheel':str(wheel),'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()}))
