import subprocess,sys,os,json,time,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[4]
evidence=Path(__file__).resolve().parent
name,cwd,*argv=sys.argv[1:]
log=evidence/(name+'.log');receipt=evidence/(name+'.receipt.json')
if log.exists() or receipt.exists(): raise SystemExit('REFUSE_OVERWRITE')
def git(*args): return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
paths=subprocess.check_output(['git','-C',str(root),'ls-files','--modified','--others','--exclude-standard'],text=True).splitlines()
meta={'sourceCommit':git('rev-parse','HEAD'),'sourceTree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain'),'changedBytes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if (root/p).is_file()},'cwd':cwd,'argv':argv,'env':{'PATH':os.environ.get('PATH'),'PYTHONDONTWRITEBYTECODE':os.environ.get('PYTHONDONTWRITEBYTECODE'),'PYTEST_ADDOPTS':os.environ.get('PYTEST_ADDOPTS'),'PYTHONPATH':os.environ.get('PYTHONPATH')}}
t=time.time()
with log.open('xb') as out: result=subprocess.run(argv,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
b=log.read_bytes();meta.update(exit=result.returncode,elapsedSeconds=time.time()-t,outputSha256=hashlib.sha256(b).hexdigest(),outputBytes=len(b))
receipt.write_text(json.dumps(meta,indent=2)+'\n');print(b.decode(errors='replace'));print(json.dumps({'receipt':str(receipt),'exit':result.returncode,'bytes':len(b)}));sys.exit(result.returncode)
