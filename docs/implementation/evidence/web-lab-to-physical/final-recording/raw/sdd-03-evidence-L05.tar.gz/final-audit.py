import json,hashlib,subprocess,sys,importlib.metadata
from pathlib import Path
root=Path.cwd();lab=root.parent/'lab';evidence=root/'.superpowers/sdd/03-r3-linux-readiness/evidence-L05'
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=git(root,'rev-parse','HEAD');labHead=git(lab,'rev-parse','HEAD')
assert not git(root,'status','--porcelain') and not git(lab,'status','--porcelain')
assert git(root,'rev-parse','HEAD^')=='7d8bededd7b0ca57984d6f0d000eaa74ddea839d'
assert git(lab,'rev-parse','HEAD^')=='2ccfbddb86282a9547368302f6121c7ee09acb71'
out=Path(json.loads((evidence/'export-location.json').read_text())['path']);manifest=json.loads((out/'manifest.json').read_text());lock=json.loads((lab/'config/source-runtime.lock.json').read_text());cache=lab/'.runtime'/lock['artifactSha256'];installed=json.loads((cache/'manifest.json').read_text())
assert manifest==installed and manifest['dirty'] is False
for k in ['sourceCommit','schemaHash','artifactSha256']:assert manifest[k]==lock[k]
assert lock['sourceCommit']==source and sha(out/'runtime.mjs')==lock['artifactSha256']==sha(cache/'runtime.mjs')
schemas=sorted((root/'packages/contracts/schemas').glob('*.json'));h=hashlib.sha256()
for p in schemas:
 assert p.read_bytes()==(out/'schemas'/p.name).read_bytes()==(cache/'schemas'/p.name).read_bytes()
 h.update((p.name+'\n').encode());h.update(p.read_bytes())
assert h.hexdigest()==lock['schemaHash']
closure={}
oldArtifact='a3a54f2664a60724344f7b05bf7265ed280fc036498a5e77e87b30102c138737'
old=json.loads((lab/'.runtime'/oldArtifact/'manifest.json').read_text())
for name,c in [('native',manifest['nativeTools']),('portable',manifest['portableSimulationTools']['closure'])]:
 for f in c['files']:
  assert sha(root/f['path'])==f['sha256'] and (root/f['path']).stat().st_size==f['bytes']
 oldc=old['nativeTools'] if name=='native' else old['portableSimulationTools']['closure'];oldmap={f['path']:f for f in oldc['files']};newmap={f['path']:f for f in c['files']}
 changed=[p for p in oldmap if p not in newmap or oldmap[p]!=newmap[p]];added=sorted(set(newmap)-set(oldmap));assert not changed and added==['packages/contracts/schemas/physical-target-dossier-v1.schema.json']
 closure[name]={'files':len(c['files']),'digest':c['digest'],'changedExisting':changed,'added':added}
prior=json.loads((evidence/'prior-evidence-index.json').read_text())
for p,v in prior.items():assert (root/p).stat().st_size==v['bytes'] and sha(root/p)==v['sha256']
files={}
for label,repo in [('source',root),('lab',lab)]:
 paths=git(repo,'diff','--name-only','HEAD^','HEAD').splitlines()
 files[label]={}
 for p in paths:
  committed=subprocess.check_output(['git','-C',str(repo),'show',f'HEAD:{p}']);assert committed==(repo/p).read_bytes()
  files[label][p]={'bytes':len(committed),'sha256':hashlib.sha256(committed).hexdigest()}
checks={}
for p in evidence.glob('*.receipt.json'):
 r=json.loads(p.read_text());log=evidence/(p.name.removesuffix('.receipt.json')+'.log');assert sha(log)==r['outputSha256'] and log.stat().st_size==r['outputBytes'];checks[p.name]={'exit':r['exit'],'outputBytes':r['outputBytes'],'sourceCommit':r['sourceCommit'],'finalByteMatches':[f for f,d in r['changedBytes'].items() if (root/f).exists() and sha(root/f)==d]}
result={'sourceCommit':source,'sourceTree':git(root,'rev-parse','HEAD^{tree}'),'labCommit':labHead,'labTree':git(lab,'rev-parse','HEAD^{tree}'),'sourceClean':True,'labClean':True,'subjectSourceCommit':source,'assessmentChecker':'in-process read-only assessor on recorded Source revision; no native checker/host authentication run','nativeSubject':None,'exportDir':str(out),'exportManifest':{'bytes':(out/'manifest.json').stat().st_size,'sha256':sha(out/'manifest.json')},'installedManifest':{'bytes':(cache/'manifest.json').stat().st_size,'sha256':sha(cache/'manifest.json')},'pin':lock,'schemaCount':len(schemas),'closures':closure,'priorEvidenceFilesUnchanged':len(prior),'files':files,'checks':checks,'python':{'executable':sys.executable,'version':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['jsonschema','rfc8785','rfc3339-validator','six','pytest']}}}
(evidence/'final-identities.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
