// L00 preparation evidence only: copies current committed subject files; does not execute the subject.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {join,dirname,basename,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {tsImport} from 'tsx/esm/api';
const root=process.cwd(),base=(await readFile(join(root,'.superpowers/sdd/03-r3-linux-readiness/evidence-L00/static-export-dir.txt'),'utf8')).trim(),out=join(base,'handoff-input'),runtime=JSON.parse(await readFile(join(base,'runtime/manifest.json'),'utf8'));
const git=(cwd,...args)=>execFileSync('git',args,{cwd,encoding:'utf8',timeout:5000}).trim();
if(git(root,'status','--porcelain')||git(resolve(root,'../lab'),'status','--porcelain'))throw new Error('CLEAN_TREES_REQUIRED');
const sourceCommit=git(root,'rev-parse','HEAD'),labCommit=git(resolve(root,'../lab'),'rev-parse','HEAD'),digest=b=>createHash('sha256').update(b).digest('hex');
if(sourceCommit!==runtime.sourceCommit||runtime.dirty!==false)throw new Error('CLEAN_EXPORT_REQUIRED');
await mkdir(out,{mode:0o700});const refs={};
async function put(role,path,sourcePath,bytes,producer=sourceCommit){await mkdir(dirname(join(out,path)),{recursive:true,mode:0o700});await writeFile(join(out,path),bytes,{flag:'wx',mode:0o600});(refs[role]??=[]).push({path,sourcePath,sha256:digest(bytes),bytes:bytes.length,sourceCommit:producer});}
const worldRoot='robotics/simulation-mujoco/fixtures/coffee-delivery-cell-v1',roleFor=new Map([[worldRoot+'/project.json','project'],[worldRoot+'/lab-world-scene.json','world'],[worldRoot+'/arm-component.json','model'],['robotics/simulation-mujoco/requirements.lock','engine']]);
for(const file of runtime.portableSimulationTools.closure.files){const bytes=await readFile(join(root,file.path));if(digest(bytes)!==file.sha256||bytes.length!==file.bytes)throw new Error('SOURCE_CLOSURE_MISMATCH');const schema=file.path.startsWith('packages/contracts/schemas/');await put(schema?'schema':roleFor.get(file.path)??'tool',schema?'schemas/'+basename(file.path):'source/'+file.path,schema?basename(file.path):file.path,bytes);}
await put('runtimeManifest','runtime/manifest.json','runtime-export/manifest.json',await readFile(join(base,'runtime/manifest.json')));
await put('runtime','runtime/runtime.mjs','runtime-export/runtime.mjs',await readFile(join(base,'runtime/runtime.mjs')));
await put('labLock','lab/source-runtime.lock.json','config/source-runtime.lock.json',await readFile(resolve(root,'../lab/config/source-runtime.lock.json')),labCommit);
const {nativeDocumentBinding}=await tsImport(join(root,'packages/lab-runtime/src/v2/sil/native-handoff-documents.ts'),import.meta.url);
const profile={documents:nativeDocumentBinding('mujoco_cell_v1'),id:'r2b-mujoco-linux-amd64-prepared',modelId:'xarm6-g2-v1',modelSha256:refs.model[0].sha256,architecture:'amd64',os:{id:'debian',version:'12'},installation:{kind:'oci'},requiredPackages:[{name:'mujoco',version:'3.17.0',sha256:null},{name:'cpython',version:'3.11.2',sha256:null},{name:'node',version:'24.22.2',sha256:null}],forbiddenPackages:['ros-noetic'],clockDomains:['mujoco_simulation','source_monotonic']};
await put('profile','profiles/r2b-mujoco-linux-amd64-prepared.json','prepared-profiles/r2b-mujoco-linux-amd64-prepared.json',Buffer.from(JSON.stringify(profile,null,2)+'\n'));
const checkerHash=createHash('sha256');for(const file of ['scripts/native-handoff.mjs','packages/lab-runtime/src/v2/sil/native-handoff.ts','packages/lab-runtime/src/v2/sil/native-handoff-documents.ts','scripts/native-sim/native-inventory.mjs','packages/contracts/schemas/native-handoff-v1.schema.json','pnpm-lock.yaml'])checkerHash.update(file+'\n').update(await readFile(join(root,file)));
const campaign=JSON.parse(await readFile(join(root,'robotics/simulation-mujoco/campaigns/mj-cell-bv01-v1.json')));
const manifest={schemaVersion:1,subject:{nativeClosureHash:null,id:'r2b-l00-prepared',executionKind:'mujoco_image',sourceCommit,labCommit,schemaHash:runtime.schemaHash,portableClosureHash:runtime.portableSimulationTools.closure.digest,runtimeArtifactSha256:runtime.artifactSha256,profileSha256:refs.profile[0].sha256,image:null},checker:{sourceCommit,toolSha256:checkerHash.digest('hex')},refs,profile,frames:{world:'map',robotBase:'base',tool:'tcp',handedness:'right'},units:{length:'m',angle:'rad',mass:'kg',time:'s'},seeds:campaign.nominalSeeds,casePolicy:{required:[campaign.scenarioId,...campaign.faults.map(x=>x.id)],lostAck:'unknown_no_resend',authority:'source'},accepted:false,dynamics:'not_calibrated'};
await writeFile(join(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({output:out,subject:manifest.subject,checker:manifest.checker,manifestSha256:digest(await readFile(join(out,'manifest.json'))),refs:Object.values(refs).flat().length,artifactBytes:Object.values(refs).flat().reduce((n,f)=>n+f.bytes,0),execution:'not_run',status:'blocked_external',accepted:false},null,2));
