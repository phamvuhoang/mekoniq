from pathlib import Path
import hashlib,json,re,os,unicodedata
workspace=Path('/Users/hoangpham/source/prv/robot');root=workspace/'.worktrees/web-lab-to-physical/source';sdd=root/'.superpowers/sdd'
design=workspace/'docs/2026-11-13-web-lab-to-physical';gtm=workspace/'docs/2026-11-14-web-simulation-gtm';dest=root/'docs/implementation/web-lab-to-physical';retention=dest/'retention'
maps=[(design,dest/'design'),(gtm,root/'docs/gtm/2026-11-14-web-simulation'),(workspace/'source',root),(workspace/'lab',root.parent/'lab')]
def mapped(p):
 p=p.resolve()
 for a,b in maps:
  if p.is_relative_to(a):return b/p.relative_to(a)
 return p
sha=lambda b:hashlib.sha256(b).hexdigest();index=[];rewritten=[]
for start,target in maps[:2]:
 for p in sorted(start.rglob('*')):
  if not p.is_file():continue
  q=target/p.relative_to(start);q.parent.mkdir(parents=True,exist_ok=True);original=p.read_bytes();data=original
  if p.suffix=='.md':
   def link(m):
    href=m[1];parts=href.split('#',1)
    if re.match(r'^[a-z]+:',href) or not parts[0]:return m[0]
    old=(p.parent/parts[0]).resolve();new=mapped(old);return ']('+os.path.relpath(new,q.parent)+(('#'+parts[1]) if len(parts)>1 else '')+')'
   data=re.sub(r'\]\(([^\s)]+)\)',link,original.decode()).encode();rewritten.append(q)
  q.write_bytes(data);index.append({'role':'rebased_design_or_gtm' if data!=original else 'exact_design_or_gtm','original':str(p),'destination':str(q.relative_to(root)),'originalBytes':len(original),'originalSha256':sha(original),'destinationBytes':len(data),'destinationSha256':sha(data)})
# Exact historical task/review/ruling navigation records only. Huge reproducible patches and ignored runtime state are excluded.
selected=[]
for p in sdd.rglob('*'):
 if not p.is_file() or p.stat().st_size>2*1024*1024:continue
 if re.match(r'task-.*-(?:report|review-\d+)\.md$',p.name) or p.name in ['progress.md','deferred-findings.md'] or (p.suffix in ['.json','.py','.md'] and p.name.startswith('root-') and any(w in p.name for w in ['handoff','audit','retention','review','ancestry'])):selected.append(p)
for p in sorted(selected):
 q=retention/'sdd'/p.relative_to(sdd);q.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes();q.write_bytes(data);index.append({'role':'exact_historical_review_or_ledger','original':str(p),'destination':str(q.relative_to(root)),'originalBytes':len(data),'originalSha256':sha(data),'destinationBytes':len(data),'destinationSha256':sha(data)})
links=[]
def fragments(text):
 ids=set(re.findall(r'(?:id|name)=[\"\']([^\"\']+)',text));counts={}
 for heading in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
  h=re.sub(r'[^\w\-\s]','',heading.lower(),flags=re.UNICODE).replace(' ','-');n=counts.get(h,0);counts[h]=n+1;ids.add(h+('-'+str(n) if n else ''))
 return ids
for p in rewritten:
 for m in re.finditer(r'\]\(([^\s)]+)\)',p.read_text()):
  href=m[1]
  if re.match(r'^[a-z]+:',href):continue
  parts=href.split('#',1);q=(p.parent/parts[0]).resolve() if parts[0] else p;entry={'file':str(p.relative_to(root)),'href':href,'exists':q.exists()}
  if len(parts)>1 and q.is_file() and q.suffix=='.md':entry['fragmentResolved']=parts[1] in fragments(q.read_text())
  links.append(entry)
(retention/'preparation-copy-map.json').write_text(json.dumps({'scope':'B10 tooling preparation; final tuple/status/reviews and final destination audit still pending','files':index},indent=2)+'\n')
(retention/'preparation-link-audit.json').write_text(json.dumps({'scope':'Rebased design/GTM local inline Markdown links and Unicode heading/explicit-id fragments; reference-style/renderer nuances remain final audit scope','links':links},indent=2)+'\n')
bad=[l for l in links if not l['exists'] or l.get('fragmentResolved') is False]
print(json.dumps({'copiedFiles':len(index),'checkedLinks':len(links),'unresolved':bad},indent=2));raise SystemExit(bool(bad))
