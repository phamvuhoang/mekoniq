from pathlib import Path
import json,subprocess,hashlib,shutil
root=Path.cwd();ev=root/'.superpowers/sdd/02-r2b-cell-and-web/evidence-B10';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for name,repo,base in [('source',root,'9fdf4f382c19d6dbbc3cf64c231561ced71e786d'),('lab',root.parent/'lab','b4a9d34f0881b05a76078a5d2b3ce2c189b654a6')]:
 def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
 head=git('rev-parse','HEAD').decode().strip();assert not git('status','--porcelain');patch=git('diff','--no-renames','--binary',base,head,'--');(ev/(name+'-original-base.patch')).write_bytes(patch)
 paths=git('diff','--name-only','--no-renames',base,head).decode().splitlines();files=[]
 for path in paths:
  p=repo/path;files.append({'path':path,'bytes':p.stat().st_size if p.exists() else None,'sha256':sha(p.read_bytes()) if p.is_file() else None})
 rows.append({'repository':str(repo),'base':base,'head':head,'clean':True,'patch':name+'-original-base.patch','patchBytes':len(patch),'patchSha256':sha(patch),'files':files})
index={'scope':'Original dispatch bases to final tooling tuple; exact copied historical documentation is covered by versioned copy map; no final campaign claim','repositories':rows,'labPin':json.loads((root.parent/'lab/config/source-runtime.lock.json').read_text()),'checker':json.loads(Path('/tmp/b10-tooling-checks/checker-handoff.log').read_text())};(ev/'final-byte-attribution.json').write_text(json.dumps(index,indent=2)+'\n')
m=json.loads((ev/'retention-map.json').read_text())
for ext in ['log','receipt.json']:
 src=Path('/tmp/b10-tooling-checks/checker-handoff.'+ext);dst=ev/'checks'/src.name;shutil.copyfile(src,dst);b=src.read_bytes();m['files'].append({'original':str(src),'destination':str(dst),'bytes':len(b),'sha256':sha(b),'role':'exact tooling evidence copy; original producer identity preserved'})
d=json.loads((ev/'checks/checker-handoff.receipt.json').read_text());m['checks'].append({'id':d['id'],'exitCode':d['exitCode'],'beforeHead':d['before']['head'],'afterHead':d['after']['head'],'command':d['command'],'args':d['args'],'receipt':str(ev/'checks/checker-handoff.receipt.json'),'receiptSha256':sha((ev/'checks/checker-handoff.receipt.json').read_bytes()),'outputSha256':d['outputSha256']});(ev/'retention-map.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'sourceFiles':len(rows[0]['files']),'labFiles':len(rows[1]['files']),'bothClean':True,'checker':index['checker'],'retainedChecks':len(m['checks'])}))
