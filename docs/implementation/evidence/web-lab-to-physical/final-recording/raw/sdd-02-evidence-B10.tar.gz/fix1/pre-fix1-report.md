# B10 tooling report — DONE_WITH_CONCERNS; independent review pending

B10 **TOOLING** is implemented, committed and paired with a clean Lab pin. This does not complete final recording, L06, release acceptance, current Linux native qualification, WEB05 execution, HTTPS deployment or physical commissioning. All generated evidence remains accepted:false. There was one authorized actual local Mac nominal cell execution; its other seven registered cases remain missing. No installed Docker client/daemon operation, image build, registry push, host provision, device action or original-main mutation was performed. Historical recorder-plan tests use an isolated argv-recording Docker stub. OCI tests use synthetic local files; the explicit remote-selector RED attempted an unavailable Docker executable in a deliberately empty PATH and did not call the installed Docker.

## Identities and ownership

Worktrees are `/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/{source,lab}`, branch `codex/web-lab-to-physical`. One implementer; no helpers/reviewers spawned.

| Role | Identity |
|---|---|
| Original Source dispatch base | `9fdf4f382c19d6dbbc3cf64c231561ced71e786d` |
| Original Lab dispatch base | `b4a9d34f0881b05a76078a5d2b3ce2c189b654a6` |
| Actual nominal producer, clean throughout | `27d6be972eaf16c348d408339c4db66673d62f31` |
| R92/disposition/package readback revision | `af3388c9fe83a9009194df2312a03fea6fe2c1bd` |
| Documentation correction | `9dd2481` |
| Final tooling Source | `09b06bee0559c31087d478e5a4c4f28e4832a3cd` |
| Final tooling Lab | `d12c04a467ef084a991cfb17ff280d55f0c49dc2` |
| Final clean runtime SHA256 | `fadec9cb78a9b7cef90ed89867905fe98a8524d0b97f78bbbc9d45168c3c5035` |
| Schema hash | `c2bdaca0b5ce9b03ee52a8c497719f4ea83b2cbb0e23c4e18365099fd163fa12` |
| Portable tools digest | `778c336cd3bcffa975cbea2967915f27fd5f94124ec986e75f2dac031d55df93` |
| Final exact checker graph | `b0cdca99cfd0066de7c0a8bff029b2c9c9822fe9c793fa75886bce106afa6d29` |
| af3388c Mac-refusal checker graph | `fa6547396a0093694c61c398c5f79f05ae0dcb120d6b6a36c1b88a24fdaafd29` |
| Final package-manifest SHA256 | `bd111a8411a3a893c7d5287c82428f23927cfce4a39f91b43f3545e27dd80795` |
| Packaged campaign bundle SHA256 | `56a8e6723dc1258f27449e67f1b0766b075774f2d54732c6c7353f671bcfa048` |

Source commits are `27d6be9 feat: prepare strict R2b qualification and current campaign tooling`, `af3388c fix: bind local OCI exports and preserve per-case qualification results`, `9dd2481 docs: refresh B10 preparation and warning disposition`, `09b06be fix: refuse remote OCI selectors before Docker lookup`. Lab commit pins 09b06be and adds capture/import preparation. Both trees were clean in the final byte audit. The final package has351 consumed input entries and144 image-file entries. The af3388c package manifest is `8271d2adc89948a67d11d55f55411f7b8826b37986e0c5c79515adca9e908167`; its bundle bytes equal the final bundle, but its package/runtime/source identities remain distinct.

## Qualification APIs and behavior

- `scripts/sim-extension-r2b.mjs`: closed full table MJ01–07, CELL01–06, WEB01–06, X01, REG04, and explicit mobility subset G-MJ1/G-REG4. Strict accepted:false/null reviewer fields, exact case/gate/suite sets, Lab identity and unsupported override rejection. Historical `irsim-qualification.mjs` was not changed.
- Public historical dispatcher `checkQualification(m,read)` returns `R2B_ARTIFACT_READBACK_REQUIRED` for every R2b call. Historical R1/R1.1/R2a semantics are retained. Synchronous structural success is provisional and cannot establish R2b acceptance.
- `scripts/r2b-readback.mjs`: `verifyR2bDirectory(root)` reads qualification.json from disk; `assessR2bDirectory(root,m)` is the recorder construction checker. `collectR2bArtifactDispositions(root,m)` derives per-case statuses from actual input groups. Every public recorder/acceptance success uses the async verifier. Per-case metadata is recomputed and caller mismatches fail. Missing cases/prerequisites remain not_run; corrupt/invalid identities or observed failures remain failed; suite assertion failures are not hidden by missing artifacts. WEB05 absence preserves independently supported local cases. Gates require their full registered case sets; WEB06 remains blocked_external.
- Actual readback includes bounded inventory/file/path/symlink checks; same-tuple R2a + prior shared guard; reviewed19-case payload reader; new8-case cell reader; byte-bound semantic producer inputs; version2 browser clock/raw performance checks; 390 live-report DOM/screenshot correlation; and WEB05 reports, committed chunks and full replay assets. No caller `artifactsVerified` or performance-target boolean replaces those readers.
- `record-sim-extension.mjs --release r2b` dispatches to `record-sim-extension-r2b.mjs`. Options: `--scope full|mobility --out NEW_OUT --candidate-id ID --r2a-record DIR --physics-campaign DIR [--cell-campaign DIR --semantic-study FILE --web-record DIR --container-record DIR] [--lab DIR]`. Full scope requires cell/study/web; missing container is recorded separately. Output must be fresh and outside both repos, Source/Lab clean and pinned. R2b `--plan` prints fixed tables without prerequisites; historical plan behavior is unchanged. Recorder retains raw process streams, suite output and construction problems and invokes mandatory final async readback.
- Acceptance `tests/acceptance/sim-extension.acceptance.test.ts` routes R2b through the async directory verifier and requires every local gate tested, host external and accepted:false. No candidate was generated or accepted in this tooling phase.

## Production cell and current native path

`packages/lab-runtime/src/v2/simulation3d/cell-campaign.ts` extracts a production runner/reader from the reviewed Source world behavior, without test imports. `runCellCampaign({root,out,sourceCommit,python?,caseId?,signal?})` runs the fixed3 nominal seeds +5 faults; clean40-hex source identity is required. `verifyCellCampaign(root)` requires all8 cases and ignores summary claims. The reader verifies exact case inventories, retained world admission and H+1 horizon, actual worker PID/one shared world, request/response digest correlation, SQLite/journal/report agreement, physics substeps, nominal served/confirmation/custody/continuity and fault-specific unknown/cancel/disturbance evidence. SQLite is opened only on a verified temporary copy. Lost actual ACK is retained before delivery is suppressed; no uncertain-case retry or respawn is introduced.

`scripts/lab-mujoco.mjs run --campaign payload-v1|mj-cell-bv01-v1 --out NEW_DIR [--case REGISTERED_ID]` exposes both production campaigns. `verify --input DIR` dispatches by registered campaign. Per-case execution returns an individual verdict; the retained summary and full reader still require all19 payload or8 cell cases. Existing payload defaults and full repeat checks remain intact.

Current native public CLI is `node scripts/native-sim/r2b-campaign.mjs --handoff DIR --out NEW_DIR` or `--verify DIR`. It uses the fresh audited bootstrap/worker and a separately bound current subject. Historical L01 R2a profile/checker semantics remain separate. No test checkout or ambient HEAD is mounted into a subject. Actual current native admission requires L00 native-ready handoff, registered local Linux/amd64 host, no emulation/nested host, immutable current image/config identity, actual engine inventory, package/observer/input graph, full payload+cell artifacts and exact checker identity. Without host/image it remains not_run, never native qualified.

R90: `runR2bCaseCommand` has a positive-integer6100000ms maximum; historical `runProbeCommand` retains1800000ms. Shared `owned-process.mjs` owns its detached group, streams output incrementally, retains the bounded prefix on output overflow and records its own exit on timeout/abort. Cleanup addresses only the named owned container and checks its owner label. Current worker does not inherit the historical1500000ms outer AbortSignal. Portable timeout/abort/sibling-ownership/output-limit tests used short delays; no100-minute wait was run.

R91: `build-r2b-campaign.mjs CONTEXT EXPORT_DIR` requires clean matching source/export and uses the same installed Vite/esbuild dependency resolution as the runtime exporter. It packages production code, embedded SQLite migration, observer and consumed input hashes. Build labels bind package/bundle bytes; companion is generated metadata, not immutable engine/tool closure filler. Config admission still comes from L00 raw platform/config digest verification. Actual inspect and in-container file hashes must agree, including observer and campaign registries. Labels are not independent build or host authentication.

R92: `deploy/lab-runtime/build.sh TAG --platform linux/amd64 --oci-out NEW_DIR` adds an explicit no-push OCI directory export plus local Docker exporter load, using an existing running local docker-container builder with Buildx/BuildKit>=0.13. It does not create builders or load arbitrary OCI tarballs. Explicit remote selectors fail before Docker lookup. `local-oci.mjs` verifies bounded paths, symlinks, descriptor/blob size/hash/platform and config; actual loaded config ID, RootFS diff IDs, architecture/OS and labels must match. Missing RepoDigests is admitted only as a verified local export association; present conflicts fail. Native readback repeats this and retains the layout/association. The runbook names the recipient handoff layout/provenance recipe. This path has portable synthetic tests and packaging checks, **no actual Docker export/load proof**.

## Browser, portability, services and deferred work

Lab's production capture version2 records Node/browser clock origins and exact active-window epoch boundaries. Each observed HTTP response carries stable actionId/runId/tick correlation; receipts remain observer upper bounds, not internal Source commit timestamps. `browser-capture-clock.mjs` validates ambiguity/missing clocks and recomputes duration/render/worker/last-step-receipt targets from raw streams. New390 live-report replay capture writes simultaneous DOM/header count/geometry and screenshot. No new browser measurement or stripe-cause conclusion is claimed.

Retained replay tests require `MEKONIQ_RETAINED_INPUTS` + `MEKONIQ_RETAINED_INPUTS_SHA256`. `prepare-retained-inputs.mjs CATALOG EXPECTED_SHA NEW_DIR` verifies source inventory, copies to a fresh directory, verifies again and emits new selectors. Missing corpus fails; there is no workstation default or silent skip. Catalog SHA is `d46dfb3e521af516b4b31269f8a3bf755de1301935a6cc0bee9369ef679f9a51`; prepared manifest SHA is `5c9f5aec92c8c365f33895f7099b94e16bb6f48155141c2423fac9e4baf358fe`. Historical B06 compound producer identity is preserved and deliberately refused by the new clean-current campaign reader.

`owned-source-ci.mjs -- COMMAND ...` prepares a fresh owned Supabase namespace, checks fixed ports and ownership, passes consistent local credentials/receipt and stops only that project. `wave02-db.ts` requires that receipt plus actual named container ID/port and local target/credential checks; it cannot fall back to the developer project's status. This preparation has portable tests only; actual services/full CI remain deferred to final prerequisites. Secrets are not printed in the normal status path; private local service logs remain outside versioned evidence.

Scoped ESLint overrides fix the27 historical Node/CommonJS diagnostics in exactly5 unchanged historical files. Original bytes are untouched. Test runner normalizes child color policy. Lab build uses pnpm for its nested brand check; four observed JSON import-attribute warnings were removed by matching the existing browser import convention in the two owning modules. Old warning logs remain retained.

B08 coherent goal/frame negatives now pass upstream integrity and reach semantic equivalence rejection; stale-seal corruption tests retain honest names. Wider coherent-world/adjacent-physics negatives remain deferred. L01 M00 now uses the frozen0.14m acceptance rather than0.15m commanded lift, with a genuine threshold RED/GREEN and historical44-test coverage. Other minor dispositions remain explicitly listed in versioned `retention/B10-disposition.md` and the preserved central deferred index; independent review decides closure.

## Verification and failures retained

All76 persisted receipt-backed commands are indexed in `evidence-B10/retention-map.json` with exact argv, cwd/HEAD, output hash and own exit. Each copied receipt also contains before/after status/diff/changed-file hashes and relevant non-secret environment selectors. The unchanged-checker identity at a clean commit binds unchanged files; the final byte audit maps the original-base net files. No trailing shell command is used to manufacture an earlier check's success.

- Initial closed-table qualification RED:2 failed/25 passed; GREEN27 passed. Clock/retained/cell/process/readback creation-stage REDs are missing-module/0-test failures, not observed validator bypasses. These are explicitly distinct from true regression REDs. Some straightforward scaffolding and scratch implementations preceded executable coverage; no universal strict test-first claim is made retrospectively.
- Genuine regression RED/GREEN includes missing assessCapture export,0.14m historical threshold refusal, lost output prefix at maxBytes, per-case disposition missing export, registry hash mismatch surviving a coherent reseal, owned target missing export, and remote-selector lookup occurring before refusal. OCI initial RED is missing-module creation-stage, not a demonstrated OCI bypass.
- `focused-final`:15 files173 tests passed at its recorded earlier bytes. Later `process-prefix-green`:4 files8 tests passed after the process fix. Do not add overlapping scopes into a new test total or claim173 covered later OCI changes.
- `semantic-precision`:2 files34 tests passed. `labels-focused`:5 files7 tests passed. Full historical probe suite44 passed within173; earlier focused threshold invocation had43 filtered tests, which are not_run for that invocation.
- `oci-disposition-green`:5 files33 tests passed. `focused-post-oci`:9 files42 tests passed. Later `registry-binding-green`:3 tests passed; `owned-target-green`:2 tests passed; `remote-selector-green`:4 tests passed. These are portable synthetic/refusal scopes.
- `retained-reader1`:18 tests,17 existing actual replay/export/gateway/capture checks passed and1 new cell-envelope test failed `CELL_CASE_IDENTITY`. Cause: original B06 producer is a compound dirty development identity, not a clean SHA. Original evidence was not rewritten. Corrected `retained-identity-refusal` passed the explicit negative expectation;17 positives remain the prior scope. Initial retained-green failed the Mac `/var` versus `/private/var` expected-path comparison; retained-green2 passed after canonical-path correction.
- `typecheck-all-current` failed on an unused ts-expect-error and missing process out argument; corrected type checks passed. `lint-all-current` failed on an unused import; corrected full lint passed. `lint-before-smoke` failed on the new CLI AbortController declaration; corrected scoped declaration made `lint-before-smoke2` pass. `package-first` failed because root esbuild is not a direct dependency; corrected exporter-aligned resolution made package-second/final/handoff pass. `package-wrong-export` intentionally exits1 with `CAMPAIGN_EXPORT_TUPLE_MISMATCH`.
- Source contracts check, multiple appropriately scoped type/lint checks and clean exports passed; latest broad source type receipt is `source-type-final-cover` at9dd2481. The later4-line selector change is covered by `remote-selector-green` and `scoped-final-selector-lint` at final09b06be. Final Source build/full pnpm test/acceptance/candidate chain were not run, per sequencing.
- Lab production build passed before pin; first build retained four import warnings, corrected build passed without them. Lab focused5 files35 tests passed. Final09b06be import/sync/check:source/typecheck all passed with own receipts; Lab commitd12c04a is clean. No browser campaign was run.

The first7 log-only checks (`qualification-{red,green}`, `clock-{red,green}`, `retained-{red,green,green2}`) precede the persisted own-receipt wrapper. Their terminal tool exits were observed during implementation, but there is no contemporaneous serialized byte receipt; this limitation is retained rather than retroactively inventing one. All later failed attempts and corrective logs are retained separately.

## Authorized actual smoke, readback and limits

At clean27d6be9, exact child command was:

```sh
node scripts/lab-mujoco.mjs run --campaign mj-cell-bv01-v1 --case nominal-7 --out /tmp/b10-cell-smoke-27d6be9
```

It ran under `runR2bCaseCommand`6100000ms and outer Perl alarm6200s, Node24.22.2, `PYTHONDONTWRITEBYTECODE=1`. Process started2026-11-15T08:42:26.761Z and finished08:48:56.985Z, ownexit0. Before/after Source status is clean27d6be9. Actual Source authority, MuJoCo worker, physical world trace and individual readback completed H10850,1/1, noissues. Full stored summary is1/8 with missing nominal42/99,dock-drift,cup-fall,cancel-held,worker-loss,lost-ack, accepted:false.

`node scripts/lab-mujoco.mjs verify --input /tmp/b10-cell-smoke-27d6be9` separately exited1 with precisely that partial scope. The later af3388c packaged bundle verified unchanged27d6be9 evidence: child exit1 as expected for1/8, wrapper exit0 for that asserted readback result. It was not another simulation run and does not reattribute the producer. Final bundle has the same bytes, while final package/runtime identity differs.

The public native CLI at clean af3388c `--handoff /tmp/no-assigned-b10-host --out /tmp/b10-native-notrun-af3388c` exited2, subject:null, all27 cases not_run, `CURRENT_NATIVE_HOST_UNASSIGNED`. It refused before Docker, and cannot establish nativeReady or Linux execution. Preserve its exact checker revision when replaying that record; final checker has a different identity.

## Retention and original-base self-review

Full original-base self-review covered Source207 net paths and Lab8 paths. Runtime/CLI/guard/test changes were read as code; exact historical report copies were verified through the original→destination byte map rather than reinterpreting their old verdicts. Shared qualification core and L00 schema/immutable closure guards remain unchanged. Review found and corrected output-prefix loss, package dependency resolution, OCI local-image association, conservative all-case demotion, label/registry graph gaps, owned-service fallback and early remote-selector refusal. Prepared native/container/capture paths still need actual environment execution in final sequencing.

`evidence-B10/final-byte-attribution.json` records original bases, final commits, both clean statuses, every net file's size/SHA, exact full binary/no-renames patches and final checker/pin. Full patches are retained beside it for review; no upstream500MB historical patch duplication was made.

Versioned preparation retains149 design/GTM/review/ledger files with original→destination SHA/bytes/role mapping,153 rebased local inline links/fragments and zero unresolved targets. The snapshot is throughR92 (92human/96raw) and pending B10 review/final tuple; copied full reviews are historical exact bytes. This is not a final retention audit, and reference-style/renderer-specific links remain outside that parser. B00/B01 ledger-only review limitations remain explicit.

Ignored `evidence-B10/retention-map.json` preserves463 exact tooling-copy files (plus authored audit/patch outputs), including the83-file smoke, both package scopes, final clean export, original process streams and76 check receipts. The initial copied byte total was61,391,486 before the final checker receipt additions. Root's independent83-file/41,576,349-byte smoke index still matches every original file after both readbacks; no active/original SQLite was opened for write. Original `/tmp` evidence remains unchanged. Do not remove ignored SDD/corpus locations until final handoff refresh retains B10/L06 reports/reviews and actual final candidates.

## Remaining concerns and next phase

1. Independent B10 review is required before L06. Actual OCI/Docker build/load/native Linux path, all8 cell/19 payload current campaigns, WEB05, new180s browser/390 DOM capture, owned-service full CI and the final R-MOCK→IR-SIM→R1→R1.1→R2a→R2b chain remain not_run here. Missing environments never become passes.
2. Prepared readers are substantially stricter than summary-only checks, but portable OCI fixtures do not prove driver-specific exporter/load behavior, an authenticated build, host provenance or native physics. R91/R92 cost and constraints remain in the runbook/rulings.
3. Exact current native checker revision is separate from subject, smoke producer, package readback and later publication commits. Final recording must use the reviewed final tuple after L06 and must not relabel these intermediate artifacts.
4. Existing deferred minors remain listed; B10 makes targeted improvements and leaves final whole-branch disposition explicit. Original histories/evidence are preserved. No actual final candidate/status record was published.
