from pathlib import Path
import json,hashlib,shutil,subprocess,datetime
root=Path.cwd();dest=root/'.superpowers/sdd/02-r2b-cell-and-web/evidence-B10';dest.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=json.loads((root/'.superpowers/sdd/02-r2b-cell-and-web/root-B10-smoke-27d6be9-file-index.json').read_text())
for f in prior['files']:
 b=(Path(prior['root'])/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
items=[('/tmp/b10-tooling-checks','checks'),('/tmp/b10-cell-smoke-27d6be9','smoke-27d6be9'),('/tmp/b10-cell-smoke-process-27d6be9','smoke-process-27d6be9'),('/tmp/b10-native-notrun-af3388c','native-notrun-af3388c'),('/tmp/b10-context-af3388c','package-readback-af3388c'),('/tmp/b10-context-09b06be','package-09b06be'),('/tmp/b10-export-09b06be','export-09b06be'),('/tmp/b10-retained-inputs/inputs.json','retained-inputs-manifest.json'),('/tmp/b10-retained-catalog.json','retained-input-catalog.json'),('/tmp/b10-check.mjs','check-wrapper.mjs'),('/tmp/b10-smoke.mjs','smoke-wrapper.mjs'),('/tmp/b10-package-readback.mjs','package-readback-wrapper.mjs'),('/tmp/b10-copy-docs.py','copy-docs.py')]
rows=[]
for original,name in items:
 src=Path(original);target=dest/name
 if src.is_dir():shutil.copytree(src,target)
 else:shutil.copyfile(src,target)
 for p in sorted(src.rglob('*')) if src.is_dir() else [src]:
  if p.is_dir():continue
  assert not p.is_symlink();q=target/p.relative_to(src) if src.is_dir() else target;b=p.read_bytes();assert q.read_bytes()==b;rows.append({'original':str(p),'destination':str(q),'bytes':len(b),'sha256':sha(b),'role':'exact tooling evidence copy; original producer identity preserved'})
checks=[]
for p in sorted((dest/'checks').glob('*.receipt.json')):
 d=json.loads(p.read_text());log=p.with_name(p.name.replace('.receipt.json','.log'));assert sha(log.read_bytes())==d['outputSha256'];checks.append({'id':d['id'],'exitCode':d['exitCode'],'beforeHead':d['before']['head'],'afterHead':d['after']['head'],'command':d['command'],'args':d['args'],'receipt':str(p),'receiptSha256':sha(p.read_bytes()),'outputSha256':d['outputSha256']})
manifest={'version':1,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'originalSmokeIndexMatched':True,'files':rows,'checks':checks,'exitCode':0,'scope':'Exact tooling retention only; no final campaign or final publication acceptance'}
(dest/'retention-map.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'files':len(rows),'bytes':sum(x['bytes'] for x in rows),'checks':len(checks),'smokeOriginalIndexMatched':True,'map':str(dest/'retention-map.json')}))
