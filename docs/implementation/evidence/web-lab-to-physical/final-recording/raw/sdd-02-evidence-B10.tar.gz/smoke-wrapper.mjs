import {mkdir} from 'node:fs/promises';
import {runR2bCaseCommand} from '/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/source/scripts/native-sim/r2b-process.mjs';
const out='/tmp/b10-cell-smoke-process-27d6be9';await mkdir(out);const r=await runR2bCaseCommand(process.execPath,['scripts/lab-mujoco.mjs','run','--campaign','mj-cell-bv01-v1','--case','nominal-7','--out','/tmp/b10-cell-smoke-27d6be9'],{out,cwd:process.cwd(),timeoutMs:6100000});console.log(JSON.stringify(r));process.exitCode=r.exitCode??1;
