import subprocess,json,pathlib,collections
ROOT=pathlib.Path('/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical')
OUT=ROOT/'source/.superpowers/sdd/01-r2b-mobility/evidence-B00R2'
SPECS={'source':('4f893ac6fb75dff414a3ee42a726defb7935c734','11d25b47a18adafb88ac21adc249499109996bc5','3c917ceee6a92c6b087f0bd37baaa4e0740d44a8'),'lab':('a6ec316fb3ac2f71afff25e6fa77e931f4439e00','a7449541e118d01f65af0ad1466e0c963a173f3c','538ba452c81005010a479f337aab0edbad6e5159')}
def git(repo,*args):return subprocess.check_output(['git','-C',str(ROOT/repo),*args])
def tree(repo,ref):
 out={}
 for row in git(repo,'ls-tree','-rz','--full-tree',ref).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();out[path.decode()]={'mode':mode,'kind':kind,'object':oid}
 return out
for repo,(prior,frozen,base) in SPECS.items():
 trees={label:tree(repo,ref) for label,ref in [('prior',prior),('frozen',frozen),('featureBase',base),('result','HEAD')]}
 statuses=git(repo,'diff','--no-renames','--name-status','-z',prior,frozen).split(b'\0');changed=[]
 for i in range(0,len(statuses)-1,2):
  status,path=statuses[i].decode(),statuses[i+1].decode();entry={'path':path,'status':status,**{label:items.get(path) for label,items in trees.items()}}
  entry['featureEdited']=entry['prior']!=entry['featureBase'];entry['resultMatchesFrozen']=entry['result']==entry['frozen'];changed.append(entry)
 featureChanges=git(repo,'diff','--no-renames','--name-only','-z',prior,base).split(b'\0');featurePaths=[p.decode() for p in featureChanges if p]
 resultHead=git(repo,'rev-parse','HEAD').decode().strip()
 data={'schema':'b00r2-frozen-git-tree-inventory/1','repository':repo,'priorUpstream':prior,'frozenUpstream':frozen,'featureBase':base,'resultHead':resultHead,'gitTreeIds':{label:git(repo,'rev-parse',ref+'^{tree}').decode().strip() for label,ref in [('prior',prior),('frozen',frozen),('featureBase',base),('result','HEAD')]},'noRenames':True,'changes':changed,'featureOnlyPaths':[{'path':p,'base':trees['featureBase'].get(p),'result':trees['result'].get(p)} for p in featurePaths if p not in {e['path'] for e in changed}]}
 filename=OUT/(repo+'-inventory-'+('before' if resultHead==base else 'after')+'.json');filename.write_text(json.dumps(data,indent=2)+'\n')
 print(json.dumps({'repo':repo,'output':str(filename),'changed':len(changed),'statusCounts':dict(collections.Counter(e['status'] for e in changed)),'featureOverlaps':[e['path'] for e in changed if e['featureEdited']],'frozenMismatches':[e['path'] for e in changed if not e['resultMatchesFrozen']],'featureOnlyChanged':[e['path'] for e in data['featureOnlyPaths'] if e['base']!=e['result']]}))
