import subprocess,sys,os,json,pathlib,datetime
out=pathlib.Path(__file__).resolve().parent
label,cwd,*args=sys.argv[1:]
env=os.environ.copy();env['PATH']='/Users/hoangpham/.nvm/versions/node/v24.22.2/bin:'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1';env['PYTEST_ADDOPTS']='-p no:cacheprovider'
start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(out/(label+'.log')).write_text(p.stdout);(out/(label+'.command.json')).write_text(json.dumps({'cwd':cwd,'argv':args,'environment':{k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','PYTEST_ADDOPTS']},'nodePath':'/Users/hoangpham/.nvm/versions/node/v24.22.2/bin','startedAt':start,'exitCode':p.returncode},indent=2)+'\n')
print(p.stdout);print('EVIDENCE_EXIT_CODE='+str(p.returncode));sys.exit(p.returncode)
