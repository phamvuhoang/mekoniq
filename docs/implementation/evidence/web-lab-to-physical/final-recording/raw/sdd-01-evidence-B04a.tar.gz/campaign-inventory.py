"""Read-only complete file/directory inventory for the final retained archive."""
import hashlib
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
entries = []
for path in sorted(root.rglob('*')):
    assert not path.is_symlink(), path
    relative = str(path.relative_to(root))
    if path.is_dir():
        entries.append({'path': relative, 'kind': 'directory'})
    else:
        data = path.read_bytes()
        entries.append({'path': relative, 'kind': 'file', 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
result = {'root': str(root), 'entries': entries}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'paths': len(entries), 'files': sum(e['kind'] == 'file' for e in entries), 'bytes': sum(e.get('bytes', 0) for e in entries)}))
