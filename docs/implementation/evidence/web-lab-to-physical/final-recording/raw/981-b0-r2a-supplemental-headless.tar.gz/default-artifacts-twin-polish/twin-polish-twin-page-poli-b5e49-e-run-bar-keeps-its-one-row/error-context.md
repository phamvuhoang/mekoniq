# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: twin-polish.spec.ts >> twin page polish >> 1024 × 700: no vertical scroll and the run bar keeps its one row
- Location: tests/e2e/twin-polish.spec.ts:173:2

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 48
Received: 98
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Đến vùng làm việc" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic [ref=e7]:
      - generic [ref=e8]: PREVIEW
      - generic "Language" [ref=e10]:
        - button "VI" [pressed] [ref=e11] [cursor=pointer]
        - button "JA" [ref=e12] [cursor=pointer]
        - button "EN" [ref=e13] [cursor=pointer]
      - link "Kế hoạch kinh doanh ↗" [ref=e14] [cursor=pointer]:
        - /url: /business-plan.html
  - generic [ref=e15]:
    - complementary [ref=e16]:
      - generic [ref=e17]: KHÔNG GIAN LÀM VIỆC
      - navigation "Điều hướng chính" [ref=e18]:
        - link "Thiết kế" [ref=e19] [cursor=pointer]:
          - /url: "#design"
        - link "Lắp ráp" [ref=e23] [cursor=pointer]:
          - /url: "#assembly"
        - link "Mặt bằng" [ref=e27] [cursor=pointer]:
          - /url: "#restaurant"
        - link "Kịch bản" [ref=e31] [cursor=pointer]:
          - /url: "#scenarios"
        - link "Bản sao số" [ref=e35] [cursor=pointer]:
          - /url: "#twin"
        - link "Kết quả" [ref=e39] [cursor=pointer]:
          - /url: "#results"
        - link "Triển khai" [ref=e44] [cursor=pointer]:
          - /url: "#deployment"
      - generic [ref=e48]:
        - generic [ref=e49]: MEKONIQ ENGINEERING LAB
        - paragraph [ref=e54]: Từ ý tưởng đến vận hành.
        - generic [ref=e55]:
          - text: LAB v0.1
          - generic [ref=e57]: R0
    - main [ref=e58]:
      - heading "Bản sao số" [level=1] [ref=e59]
      - generic [ref=e60]:
        - region "Lần chạy" [ref=e61]:
          - generic [ref=e62]:
            - button "Kịch bản" [ref=e63] [cursor=pointer]:
              - generic [ref=e64]:
                - generic [ref=e65]: Kịch bản
                - generic [ref=e66]: Cà phê sữa đá
            - 'button "Runtime: Đang kết nối" [ref=e69] [cursor=pointer]':
              - generic [ref=e71]: "Runtime:"
              - generic [ref=e72]: Đang kết nối
            - button "Mô phỏng · MOCK" [ref=e73] [cursor=pointer]
          - generic [ref=e78]:
            - generic [ref=e79]:
              - generic [ref=e80]: Trạng thái
              - generic [ref=e81]: Cần kiểm tra
            - generic [ref=e82]:
              - generic [ref=e83]: Thời gian mô phỏng
              - generic [ref=e84]: 5.0 s
            - generic [ref=e85]:
              - generic [ref=e86]: Đã giao
              - generic [ref=e87]: "0"
            - button "1 vấn đề" [ref=e88] [cursor=pointer]:
              - generic [ref=e92]:
                - text: "1"
                - generic [ref=e93]: vấn đề
            - button "Đối soát" [ref=e94] [cursor=pointer]
            - button "Chi tiết" [active] [ref=e95] [cursor=pointer]
        - region "Khung nhìn" [ref=e100]:
          - generic "Bản sao 3D. Chọn vật thể từ danh sách." [ref=e102]
          - generic [ref=e103]:
            - 'button "Về góc nhìn gốc (kịch bản tay máy: trạm tay máy)" [ref=e104] [cursor=pointer]'
            - 'button "Vừa khung đối tượng chọn (không chọn: cả mặt bằng)" [ref=e107] [cursor=pointer]'
            - button "Chế độ xem" [ref=e110] [cursor=pointer]
            - button "Phím tắt" [ref=e114] [cursor=pointer]
            - button "Hiển thị" [ref=e118] [cursor=pointer]
          - status [ref=e122]:
            - generic [ref=e123]: BƯỚC TIẾP THEO
            - generic [ref=e124]: Cần đối soát
            - code [ref=e125]: CUP_REMOVED
            - generic [ref=e126]: Kiểm tra tại trạm, đối soát (loại bỏ cốc), rồi chạy lại.
        - group "Điều khiển lần chạy" [ref=e127]:
          - button "Tự chạy" [disabled] [ref=e128]
          - button "+5 s" [disabled] [ref=e132]
          - button "Tạm dừng mô phỏng" [disabled] [ref=e136]
          - generic [ref=e140]:
            - generic [ref=e141]: Tốc độ chạy
            - combobox "Tốc độ chạy" [ref=e142]:
              - option "1×"
              - option "4×"
              - option "16×" [selected]
              - option "64×"
          - generic [ref=e144]: 5.0 s · tick 250
          - button "Hủy lần chạy" [ref=e145] [cursor=pointer]
```

# Test source

```ts
  80  |   await expect(page.getByTestId('run-status')).toContainText('Cần kiểm tra');
  81  |   await expect(page.getByTestId('problems-count')).toBeVisible();
  82  |   await expect(page.getByTestId('problems-panel')).toBeHidden();// not reopened by the new problem
  83  |   await page.locator('[data-action="twin-inspector-toggle"]').click();
  84  |   await expect(page.getByTestId('primary-action')).toBeVisible();
  85  |   await expect(page.locator('#twin-scenario-value')).toHaveText('Cà phê sữa đá');
  86  |   expect(await fits(page,'#twin-scenario-value')).toBe(true);
  87  |   await shot(page,'run-bar-problem-desktop-vi');
  88  |   await openProblems(page);
  89  |   const cards=page.getByTestId('problems-panel').locator('[data-testid="problem-row"][data-severity="attention"]');
  90  |   await expect(cards).toHaveCount(1);
  91  |   await expect(page.getByTestId('attention-reason')).toHaveCount(1);
  92  |   await expect(cards.getByTestId('attention-reason')).toHaveCount(1);
  93  |   await expect(cards.getByTestId('attention-reason')).toContainText('CUP_REMOVED');
  94  |   const buttons=cards.locator('[data-action="twin-select"]');
  95  |   expect(await buttons.count()).toBeGreaterThan(0);
  96  |   for(const b of await buttons.all()){const name=((await b.textContent())??'').trim();expect(name.length).toBeGreaterThan(0);expect(await b.getAttribute('aria-label')).toContain(name);}
  97  |   await expect(buttons).toHaveText(['coffee-job-1','cup-1']);
  98  |   await shot(page,'problems-desktop-vi');
  99  |   await page.getByTestId('problems-count').click();
  100 |   await expect(page.getByTestId('problems-panel')).toBeHidden();
  101 |  });
  102 | 
  103 |  test('the runtime box repeats the telemetry detail, repainted live',async()=>{
  104 |   await page.getByTestId('runtime-chip').click();
  105 |   const copy=page.getByTestId('runtime-popover').locator('#twin-telemetry-box');
  106 |   await expect(copy).toBeVisible();await expect(copy).toContainText('SSE');
  107 |   const was=await copy.textContent();
  108 |   await expect.poll(()=>copy.textContent(),{timeout:5000}).not.toBe(was);
  109 |   await page.getByTestId('runtime-chip').click();
  110 |   await expect(page.getByTestId('runtime-popover')).toBeHidden();
  111 |  });
  112 | 
  113 |  test('scenario picker: a preset that cannot run gives one reason per backend',async()=>{
  114 |   await openScenarioPicker(page);
  115 |   const lists=await page.locator('#twin-picker [data-action="twin-preset"]:disabled [data-testid="picker-reasons"]').evaluateAll(ls=>ls.map(l=>[...l.querySelectorAll('code')].map(c=>c.textContent??'')));
  116 |   expect(lists.length).toBeGreaterThan(0);
  117 |   for(const codes of lists){const backends=codes.filter(c=>c.startsWith('BACKEND_')).map(c=>c.split(':')[1]!.split(' ')[0]);expect(new Set(backends).size,codes.join()).toBe(backends.length);}
  118 |   await page.getByTestId('scenario-picker').click();
  119 |   await expect(page.locator('#twin-picker')).toBeHidden();
  120 |  });
  121 | 
  122 |  test('toolbar buttons expose their state; ? moves focus into the key list and back; one twin-help button; the label explains itself in watch mode',async()=>{
  123 |   const help=page.locator('[data-action="twin-help"]'),watch=page.locator('[data-action="twin-watch"]'),list=page.getByTestId('shortcuts');
  124 |   await expect(help).toHaveCount(1);
  125 |   await expect(help).toHaveAttribute('aria-expanded','false');await expect(watch).toHaveAttribute('aria-pressed','false');
  126 |   await watch.focus();await page.keyboard.press('?');
  127 |   await expect(list).toBeVisible();
  128 |   await expect(list.getByRole('button',{name:'Đóng'})).toBeFocused();
  129 |   await expect(help).toHaveAttribute('aria-expanded','true');
  130 |   await page.keyboard.press('Escape');
  131 |   await expect(list).toBeHidden();
  132 |   await expect(watch).toBeFocused();
  133 |   await help.click();
  134 |   await expect(list.getByRole('button',{name:'Đóng'})).toBeFocused();
  135 |   await list.getByRole('button',{name:'Đóng'}).click();
  136 |   await expect(list).toBeHidden();await expect(help).toBeFocused();
  137 |   await expect(help).toHaveCount(1);
  138 |   await blur(page);await page.keyboard.press('w');
  139 |   await expect(watch).toHaveAttribute('aria-pressed','true');
  140 |   await page.getByTestId('mode-badge').click();
  141 |   await expect(page.getByTestId('caveat-detail')).toBeVisible();
  142 |   await blur(page);await page.keyboard.press('Escape');await page.keyboard.press('Escape');
  143 |   await expect(page.getByTestId('caveat-detail')).toBeHidden();
  144 |   await expect(watch).toHaveAttribute('aria-pressed','false');
  145 |  });
  146 | 
  147 |  test('replay: no live action on the run bar, a recorded tag, no run speed; Space on the scrubber plays, a held Space toggles once',async()=>{
  148 |   await openInspector(page,'report');
  149 |   await page.getByRole('button',{name:'Xem lại (chỉ đọc)'}).click();
  150 |   await expect(page.getByTestId('primary-action')).toHaveCount(0);
  151 |   await expect(page.getByTestId('recorded-tag')).toBeVisible();
  152 |   await expect(page.getByTestId('run-status')).not.toContainText('Bản ghi');// the recorded status itself, the tag beside it
  153 |   expect(await page.evaluate(()=>document.querySelector('[data-testid="recorded-tag"]')!.parentElement===document.querySelector('[data-testid="run-status"]')!.parentElement)).toBe(true);
  154 |   await expect(page.locator('#twin-run-speed')).toHaveCount(0);
  155 |   expect(await chipWord(page)).toBe('Bản ghi');
  156 |   const transport=page.getByTestId('twin-transport'),cursor=page.locator('#twin-replay-cursor');
  157 |   await cursor.fill('0');
  158 |   await cursor.focus();await page.keyboard.press(' ');
  159 |   await expect(transport.getByRole('button',{name:'Dừng phát'})).toBeVisible();
  160 |   // playing: one press stops it; the auto-repeat of the held key does not start it again
  161 |   await page.keyboard.down(' ');await page.keyboard.down(' ');await page.keyboard.up(' ');
  162 |   await expect(transport.getByRole('button',{name:'Phát',exact:true})).toBeVisible();
  163 |   const at=await page.getByTestId('replay-time').textContent();
  164 |   await page.waitForTimeout(300);
  165 |   await expect(page.getByTestId('replay-time')).toHaveText(at!);
  166 |   expect(await sceneShare(page)).toBeGreaterThanOrEqual(0.45);
  167 |   await shot(page,'replay-desktop-vi');
  168 |   await transport.getByRole('button',{name:'Thoát xem lại'}).click();
  169 |   await expect(page.getByTestId('recorded-tag')).toHaveCount(0);
  170 |   await expect(page.getByTestId('primary-action')).toBeVisible();
  171 |  });
  172 | 
  173 |  test('1024 × 700: no vertical scroll and the run bar keeps its one row',async()=>{
  174 |   await page.locator('[data-action="twin-inspector-toggle"]').click();
  175 |   await expect(page.getByTestId('twin-inspector')).toBeHidden();
  176 |   const wide=await runBarHeight(page);
  177 |   expect(await sceneShare(page)).toBeGreaterThanOrEqual(0.6);
  178 |   await page.setViewportSize({width:1024,height:700});
  179 |   expect(await noVerticalScroll(page)).toBe(true);
> 180 |   expect(await runBarHeight(page)).toBe(wide);
      |                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  181 |   expect(await page.getByTestId('mode-badge').evaluate(el=>el.getBoundingClientRect().height)).toBeLessThanOrEqual(46);
  182 |   // the narrow-width tightening of the label is in effect (not overridden by the base rule)
  183 |   const [spacing,...padding]=await page.getByTestId('mode-badge').evaluate(el=>{const s=getComputedStyle(el);return [s.letterSpacing,s.paddingLeft,s.paddingRight];});
  184 |   expect(['normal','0px'],`letter-spacing ${spacing} (the base rule gives .06em = 0.72px)`).toContain(spacing);// Chrome reports 0 as "normal"
  185 |   expect(padding).toEqual(['8px','8px']);// the base rule gives 10px
  186 |   await shot(page,'1024x700-vi');
  187 |  });
  188 | });
  189 | 
```