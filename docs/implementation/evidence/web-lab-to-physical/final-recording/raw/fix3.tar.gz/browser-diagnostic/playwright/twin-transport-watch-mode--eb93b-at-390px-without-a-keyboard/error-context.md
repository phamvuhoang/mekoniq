# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: twin-transport.spec.ts >> watch mode can be exited by touch at 390px without a keyboard
- Location: ../../../../../../../../private/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/browser-diagnostic/tests/e2e/twin-transport.spec.ts:20:76

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Đến vùng làm việc" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic "Language" [ref=e8]:
      - button "VI" [pressed] [ref=e9] [cursor=pointer]
      - button "JA" [ref=e10] [cursor=pointer]
      - button "EN" [ref=e11] [cursor=pointer]
  - generic [ref=e12]:
    - complementary [ref=e13]:
      - navigation "Điều hướng chính" [ref=e14]:
        - link "Thiết kế" [ref=e15] [cursor=pointer]:
          - /url: "#design"
        - link "Lắp ráp" [ref=e19] [cursor=pointer]:
          - /url: "#assembly"
        - link "Mặt bằng" [ref=e23] [cursor=pointer]:
          - /url: "#restaurant"
        - link "Kịch bản" [ref=e27] [cursor=pointer]:
          - /url: "#scenarios"
        - link "Bản sao số" [ref=e31] [cursor=pointer]:
          - /url: "#twin"
        - link "Kết quả" [ref=e35] [cursor=pointer]:
          - /url: "#results"
        - link "Triển khai" [ref=e40] [cursor=pointer]:
          - /url: "#deployment"
    - main [ref=e44]:
      - heading "Bản sao số" [level=1] [ref=e45]
      - generic [ref=e46]:
        - region "Lần chạy" [ref=e47]:
          - generic [ref=e48]:
            - button "Kịch bản" [ref=e49] [cursor=pointer]:
              - generic [ref=e50]:
                - generic [ref=e51]: Kịch bản
                - generic [ref=e52]: Cà phê sữa đá
            - 'button "Runtime: Không kết nối được" [expanded] [ref=e55] [cursor=pointer]':
              - generic [ref=e57]: "Runtime:"
              - generic [ref=e58]: Không kết nối được
            - button "Mô phỏng · chưa chạy" [ref=e59] [cursor=pointer]
          - generic [ref=e64]:
            - generic [ref=e65]:
              - generic [ref=e66]: Trạng thái
              - generic [ref=e67]: —
            - generic [ref=e68]:
              - generic [ref=e69]: Thời gian mô phỏng
              - generic [ref=e70]: —
            - generic [ref=e71]:
              - generic [ref=e72]: Đã giao
              - generic [ref=e73]: —
            - button "1 vấn đề" [ref=e74] [cursor=pointer]:
              - generic [ref=e78]:
                - text: "1"
                - generic [ref=e79]: vấn đề
            - button "Chi tiết" [ref=e80] [cursor=pointer]
          - generic [ref=e84]:
            - heading "Runtime" [level=3] [ref=e85]
            - generic [ref=e86]:
              - group "Runtime chạy ở" [ref=e87]:
                - generic [ref=e89]:
                  - radio "Máy này" [checked] [ref=e90]
                  - text: Máy này
                - generic [ref=e91]:
                  - radio "Địa chỉ khác" [ref=e92]
                  - text: Địa chỉ khác
              - generic [ref=e93]: "Địa chỉ runtime (để trống: runtime của trang này)"
              - 'textbox "Địa chỉ runtime (để trống: runtime của trang này)" [ref=e94]':
                - /placeholder: http://127.0.0.1:4176
              - generic [ref=e95]: Mã ghép nối một lần từ terminal runtime
              - generic [ref=e96]:
                - textbox "Mã ghép nối một lần từ terminal runtime" [ref=e97]
                - button "Ghép nối runtime" [ref=e98] [cursor=pointer]
            - alert [ref=e101]: "RUNTIME_UNREACHABLE: Không thấy runtime /lab/v2. Chạy runtime trên máy phát triển; Lab không tự báo hoàn thành khi thiếu runner."
            - generic [ref=e102]:
              - generic [ref=e103]:
                - term [ref=e104]: Lab ghim
                - definition [ref=e105]:
                  - code [ref=e106]: 229efa7
              - generic [ref=e107]:
                - term [ref=e108]: Runtime chạy
                - definition [ref=e109]:
                  - code [ref=e110]: —
        - region "Khung nhìn" [ref=e112]:
          - group "Mặt bằng twin 6 × 4 m" [ref=e114]:
            - generic [ref=e116]: 0 m
            - generic [ref=e117]: 1 m
            - generic [ref=e118]: 2 m
            - generic [ref=e119]: 3 m
            - generic [ref=e120]: 4 m
            - generic [ref=e121]: 5 m
            - generic [ref=e122]: 6 m
            - generic "counter · mô hình" [ref=e123]
            - generic [ref=e124]: Điểm chờ
            - generic [ref=e127]: Coffee pickup
            - generic [ref=e130]: T01
            - generic "Footprint mô hình" [ref=e133]
            - button "AMR AMR-1 · Đã lên kế hoạch" [ref=e134] [cursor=pointer]:
              - generic [ref=e138]: AMR-1
            - button "Cánh tay Cánh tay 1" [ref=e139] [cursor=pointer]:
              - generic [ref=e142]: Cánh tay 1
            - button "Máy pha Trạm cà phê" [ref=e143] [cursor=pointer]:
              - generic [aria-hidden] [ref=e146]: CM
              - generic [ref=e147]: Trạm cà phê
            - button "Trạm cốc Trạm cốc" [ref=e148] [cursor=pointer]:
              - generic [ref=e151]: Trạm cốc
          - generic [ref=e152]:
            - button "Chế độ xem" [ref=e153] [cursor=pointer]
            - button "Phím tắt" [ref=e157] [cursor=pointer]
            - button "Hiển thị" [ref=e161] [cursor=pointer]
        - group "Điều khiển lần chạy" [ref=e164]:
          - button "Tự chạy" [disabled] [ref=e165]
          - button "+5 s" [disabled] [ref=e169]
          - button "Tạm dừng mô phỏng" [disabled] [ref=e173]
          - generic [ref=e177]:
            - generic [ref=e178]: Tốc độ chạy
            - combobox "Tốc độ chạy" [ref=e179]:
              - option "1×"
              - option "4×"
              - option "16×" [selected]
              - option "64×"
          - generic [ref=e181]: 0.0 s · tick 0
          - button "Hủy lần chạy" [disabled] [ref=e182]
```