# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: replay-offline.spec.ts >> offline first initialization sends no runtime transport; fixed aliases preserve stored package bytes
- Location: ../../../../../../../../private/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/browser-diagnostic/tests/e2e/replay-offline.spec.ts:9:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 4

- Array []
+ Array [
+   "WebSocket:ws://127.0.0.1:4175/?token=snbu3qJLK6y7",
+   "WebSocket:ws://127.0.0.1:4175/?token=snbu3qJLK6y7",
+ ]
```

# Page snapshot

```yaml
- main [ref=e3]:
  - generic [ref=e4]:
    - link "MEKONIQ Lab" [ref=e5] [cursor=pointer]:
      - /url: /#twin
    - link "Try a run" [ref=e6] [cursor=pointer]:
      - /url: /?story=external-impact#twin
    - heading "Explore recordings" [level=1] [ref=e7]
    - navigation "Language" [ref=e8]:
      - button "VI" [ref=e9] [cursor=pointer]
      - button "JA" [ref=e10] [cursor=pointer]
      - button "EN" [pressed] [ref=e11] [cursor=pointer]
  - generic [ref=e12]:
    - generic [ref=e13]: Choose a story
    - combobox "Choose a story" [ref=e14]:
      - option "Choose recording"
      - option "Coffee delivery"
      - option "Cup falls after an impact" [selected]
      - option "Impact on a mobile cup"
    - group [ref=e15]:
      - generic "Replay files" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - generic [ref=e18]: Import package folder
        - button "Import package folder" [ref=e19]
        - button "Cancel load" [disabled] [ref=e20] [cursor=pointer]
        - button "Export ZIP · extract to import" [ref=e21] [cursor=pointer]
        - generic [ref=e22]: Choose object
        - combobox "Choose object" [ref=e23]:
          - option "—" [selected]
          - option "amr-1"
          - option "xArm 6 · Gripper G2"
        - button "Follow phases" [ref=e24] [cursor=pointer]
        - button "Physics inspector" [ref=e25] [cursor=pointer]
  - status [ref=e26]: Simulation · read-only · not calibrated
  - generic [ref=e27]:
    - button "Play 1×" [ref=e28] [cursor=pointer]
    - button "2D" [ref=e29] [cursor=pointer]
    - generic [ref=e30]: Camera
    - combobox "Camera" [ref=e31]:
      - option "Custom view" [disabled]
      - option "Overview"
      - option "Cell closeup" [selected]
      - option "Follow AMR"
    - button "Overview" [ref=e32] [cursor=pointer]
  - generic [ref=e35]:
    - generic [ref=e36]:
      - generic [ref=e37]: Recorded cursor
      - status [ref=e38]: 0.00 s · tick 0/2375
    - slider "Recorded cursor" [ref=e39] [cursor=pointer]: "0"
  - generic [ref=e40]:
    - region "Simulation world" [ref=e41]:
      - generic "3D twin view. Use the entity list to select objects." [ref=e42]
    - complementary [ref=e43]:
      - generic [ref=e44]:
        - generic [ref=e45]:
          - generic [ref=e46]:
            - text: Served
            - generic [ref=e47]: "0"
          - generic [ref=e48]:
            - text: Current phase
            - generic [ref=e49]: Waiting
          - generic [ref=e50]:
            - text: Issues
            - generic [ref=e51]: "0"
        - group [ref=e52]:
          - generic "Evidence and scope" [ref=e53] [cursor=pointer]
      - heading "Recorded issues" [level=2] [ref=e54]
      - paragraph [ref=e56]: No issues recorded at this point.
      - group [ref=e57]:
        - generic "Stop and continue handling" [ref=e58] [cursor=pointer]
  - group "Recorded phases" [ref=e59]:
    - button "Waiting 0.0 s" [ref=e60] [cursor=pointer]:
      - text: Waiting
      - generic [ref=e61]: 0.0 s
    - button "Approaching cup 28.9 s" [ref=e62] [cursor=pointer]:
      - text: Approaching cup
      - generic [ref=e63]: 28.9 s
    - button "Gripping cup 30.7 s" [ref=e64] [cursor=pointer]:
      - text: Gripping cup
      - generic [ref=e65]: 30.7 s
    - button "Lifting cup 32.4 s" [ref=e66] [cursor=pointer]:
      - text: Lifting cup
      - generic [ref=e67]: 32.4 s
    - button "Moving cup to tray 33.6 s" [ref=e68] [cursor=pointer]:
      - text: Moving cup to tray
      - generic [ref=e69]: 33.6 s
    - button "Placing cup on tray 35.0 s" [ref=e70] [cursor=pointer]:
      - text: Placing cup on tray
      - generic [ref=e71]: 35.0 s
    - button "Placing cup on tray 36.4 s" [ref=e72] [cursor=pointer]:
      - text: Placing cup on tray
      - generic [ref=e73]: 36.4 s
    - button "Placing cup on tray 38.1 s" [ref=e74] [cursor=pointer]:
      - text: Placing cup on tray
      - generic [ref=e75]: 38.1 s
    - button "Moving cup to tray 39.1 s" [ref=e76] [cursor=pointer]:
      - text: Moving cup to tray
      - generic [ref=e77]: 39.1 s
    - button "Placing cup on tray 40.5 s" [ref=e78] [cursor=pointer]:
      - text: Placing cup on tray
      - generic [ref=e79]: 40.5 s
    - button "Delivering coffee 41.8 s" [ref=e80] [cursor=pointer]:
      - text: Delivering coffee
      - generic [ref=e81]: 41.8 s
    - button "Waiting 42.1 s" [ref=e82] [cursor=pointer]:
      - text: Waiting
      - generic [ref=e83]: 42.1 s
    - button "Delivering coffee 42.1 s" [ref=e84] [cursor=pointer]:
      - text: Delivering coffee
      - generic [ref=e85]: 42.1 s
    - button "Held for review 47.4 s" [ref=e86] [cursor=pointer]:
      - text: Held for review
      - generic [ref=e87]: 47.4 s
```

# Test source

```ts
  1  | import {installDiagnostics,saveDiagnostics} from './observer';
  2  | import {test,expect} from '@playwright/test';
  3  | import {readFileSync} from 'node:fs';
  4  | import {join} from 'node:path';
  5  | const out=process.env.LAB_B07B_EVIDENCE;
  6  | test.beforeEach(async({page})=>{await page.context().tracing.start({screenshots:true,snapshots:true,sources:true});await installDiagnostics(page);});
  7  | test.afterEach(async({page},info)=>{await saveDiagnostics(page,'replay-'+info.title.replace(/[^a-zA-Z0-9]+/g,'-'));});
  8  | const seek=async(page:import('@playwright/test').Page,tick:number)=>{await page.locator('#replay-cursor').evaluate((el:HTMLInputElement,t)=>{el.value=String(t);el.dispatchEvent(new Event('input',{bubbles:true}));},tick);await expect(page.locator('#replay-time')).toContainText(`tick ${tick}/`);};
  9  | test('offline first initialization sends no runtime transport; fixed aliases preserve stored package bytes',async({page})=>{
  10 |  test.setTimeout(120000);await page.addInitScript(()=>{const denied:string[]=[];(window as unknown as {__runtimeTransports:string[]}).__runtimeTransports=denied;for(const name of ['EventSource','WebSocket'])Object.defineProperty(window,name,{configurable:true,value:class{constructor(url:string,...rest:unknown[]){(window as any).__diagnosticEmit?.('blocked-constructor',{name,url,protocols:rest[0]??null,stack:new Error().stack});denied.push(name+':'+url);throw Error('OFFLINE_TRANSPORT_DENIED');}}});});const attempts:string[]=[],errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.route('**/lab/**',r=>{attempts.push(r.request().url());return r.abort();});await page.goto('/#replay/external-impact');await expect(page.locator('#replay-cursor')).toBeVisible({timeout:60000});await page.getByRole('button',{name:'EN',exact:true}).click();await expect(page.locator('#replay-cursor')).toHaveAttribute('step','1');const range=await page.locator('#replay-cursor').elementHandle();await page.locator('#replay-cursor').focus();await seek(page,2375);expect(await range!.evaluate(e=>e===document.activeElement)).toBe(true);await expect(page.locator('#replay-issues')).toContainText('LOAD_FELL');await expect(page.locator('#replay-facts')).toContainText('Applied worker disturbance receipt');await seek(page,0);await expect(page.locator('#replay-issues')).not.toContainText('LOAD_FELL');await expect(page.locator('#replay-facts')).toContainText('CAPTURE_HORIZON_ONLY');
  11 |  const checked=await page.evaluate(async()=>{const m=await(await fetch('/replays/external-impact/manifest.json')).json(),a=m.assets.find((a:{encoding:string})=>a.encoding==='gzip'),r=await fetch('/replays/external-impact/'+a.path+'.bin'),b=await r.arrayBuffer(),hash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(n=>n.toString(16).padStart(2,'0')).join('');return {actual:b.byteLength,expected:a.bytes,hash,expectedHash:a.sha256,encoding:r.headers.get('Content-Encoding')};});expect(checked.actual).toBe(checked.expected);expect(checked.hash).toBe(checked.expectedHash);expect(checked.encoding).not.toBe('gzip');
> 12 |  const download=page.waitForEvent('download');await page.locator('.replay-files>summary').click();await page.locator('[data-replay="export"]').click();const zip=await download;if(out)await zip.saveAs(join(out,'offline-roundtrip.zip'));expect(zip.suggestedFilename()).toMatch(/\.zip$/);expect(attempts).toEqual([]);expect(await page.evaluate(()=>(window as unknown as {__runtimeTransports:string[]}).__runtimeTransports)).toEqual([]);expect(errors).toEqual([]);
     |                                                                                                                                                                                                                                                                                                                                                                                                                                      ^ Error: expect(received).toEqual(expected) // deep equality
  13 | });
  14 | test('replace and cancel own loads; folder import works with runtime requests denied',async({page})=>{
  15 |  test.setTimeout(90000);const attempts:string[]=[];await page.route('**/lab/**',r=>{attempts.push(r.request().url());return r.abort();});await page.goto('/#replay');await expect(page.locator('#replay-story')).toBeVisible();await page.selectOption('#replay-story','coffee-delivery');await page.locator('.replay-files>summary').click();await page.locator('[data-replay="cancel"]').click();await expect(page.locator('#replay-cursor')).toHaveCount(0);await page.locator('.replay-files>summary').click();await page.locator('#replay-import').setInputFiles(join(process.cwd(),'public/replays/external-impact'));await expect(page.locator('#replay-cursor')).toBeVisible({timeout:60000});await seek(page,2375);expect(attempts).toEqual([]);
  16 |  if(out){const m=JSON.parse(readFileSync('public/replays/external-impact/manifest.json','utf8'));await page.screenshot({path:join(out,'offline-import-terminal.png')});expect(m.horizon.tick).toBe(2375);}
  17 | });
  18 | 
  19 | test('rapid cursor work coalesces and object focus has a single-action Overview reset',async({page})=>{
  20 |  test.setTimeout(90000);await page.goto('/#replay/external-impact');await expect(page.locator('#replay-cursor')).toBeVisible({timeout:60000});let reads=0;page.on('request',r=>{if(/\/world\/chunk-.*\.bin$/.test(r.url()))reads++;});
  21 |  await page.locator('#replay-cursor').evaluate((input:HTMLInputElement)=>{for(let i=0;i<200;i++){input.value=String(i);input.dispatchEvent(new Event('input',{bubbles:true}));}input.value='2375';input.dispatchEvent(new Event('input',{bubbles:true}));});await expect(page.locator('#replay-time')).toContainText('2375/2375');expect(reads).toBeLessThanOrEqual(3);
  22 |  await page.locator('.replay-files>summary').click();await page.selectOption('#replay-object','cup-1');await page.locator('.replay-files>summary').click();await expect(page.locator('#replay-camera')).toHaveValue('custom');await page.locator('[data-replay="camera-reset"]').click();await expect(page.locator('#replay-camera')).toHaveValue('overview');
  23 | });
  24 | 
```