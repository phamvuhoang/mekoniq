# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: brand-ui.spec.ts >> startup health rendering preserves skip keyboard position and native activation
- Location: tests/e2e/brand-ui.spec.ts:18:51

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.skip-link')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('.skip-link') with timeout 5000ms
  - waiting for locator('.skip-link')
    14 × locator resolved to <a class="skip-link" href="#workspace">Đến vùng làm việc</a>
       - unexpected value "inactive"

```

```yaml
- link "Đến vùng làm việc":
  - /url: "#workspace"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | const routes = ['design', 'restaurant', 'scenarios', 'twin', 'results', 'deployment'];
  4  | test('canonical theme, original artwork and keyboard focus', async ({ page }) => {
  5  |   await page.goto('/#design');
  6  |   await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(7, 29, 33)');
  7  |   const brand = page.getByRole('link', { name: 'MEKONIQ Robot Lab', exact: true });
  8  |   await expect(brand).toBeVisible();
  9  |   await expect(brand.locator('.brand-horizontal')).toHaveAttribute('src', '/brand/assets/MEKONIQ_Horizontal_White_Transparent_v2.png');
  10 |   await expect(brand.locator('.brand-horizontal')).toHaveCSS('width', '180px');
  11 |   await page.keyboard.press('Tab');
  12 |   await expect(page.locator('.skip-link')).toBeFocused();
  13 |   await page.keyboard.press('Tab');
  14 |   await expect(brand).toBeFocused();
  15 |   await expect(brand).toHaveCSS('outline-color', 'rgb(99, 220, 197)');
  16 | });
  17 | 
  18 | for (const control of ['skip', 'brand'] as const) test(`startup health rendering preserves ${control} keyboard position and native activation`, async ({page}, info) => {
  19 |   let release!:()=>void, captured!:()=>void, first=true;
  20 |   const gate=new Promise<void>(done=>release=done), responseReady=new Promise<void>(done=>captured=done);
  21 |   await page.route('**/lab/v1/health',async route=>{
  22 |     if(!first||route.request().method()!=='GET'){await route.continue();return;}
  23 |     first=false;const response=await route.fetch();
  24 |     info.annotations.push({type:'test-response-scheduling-input',description:`Actual loopback startup health HTTP ${response.status()}, held until ordinary keyboard focus; not qualification evidence.`});
  25 |     captured();await gate;await route.fulfill({response});
  26 |   });
  27 |   try {
  28 |     await page.goto(control==='skip'?'/#design':'/#restaurant');
  29 |     const skip=page.locator('.skip-link'),brand=page.getByRole('link',{name:'MEKONIQ Robot Lab',exact:true}),target=control==='skip'?skip:brand;
  30 |     await expect(brand).toBeVisible();await responseReady;
  31 |     await page.keyboard.press('Tab');await expect(skip).toBeFocused();
  32 |     if(control==='brand'){await page.keyboard.press('Tab');await expect(brand).toBeFocused();}
  33 |     const original=await target.elementHandle();expect(original).not.toBeNull();release();
  34 |     await expect.poll(()=>original!.evaluate(node=>node.isConnected)).toBe(false);
> 35 |     await expect(target).toBeFocused();
     |                          ^ Error: expect(locator).toBeFocused() failed
  36 |     await expect(target).toHaveAttribute('href',control==='skip'?'#workspace':'#design');
  37 |     await page.keyboard.press('Tab');await expect(control==='skip'?brand:page.getByRole('button',{name:'VI',exact:true})).toBeFocused();
  38 |     await page.keyboard.press('Shift+Tab');await expect(target).toBeFocused();
  39 |     if(control==='brand')await expect(brand).toHaveCSS('outline-color','rgb(99, 220, 197)');
  40 |     await page.keyboard.press('Enter');await expect(page).toHaveURL(control==='skip'?/#workspace$/:/#design$/);
  41 |     await expect(control==='skip'?page.locator('#workspace'):brand).toBeFocused();
  42 |   } finally {release();}
  43 | });
  44 | 
  45 | for (const width of [390, 1024, 1512]) test(`six workspaces and three locales at ${width}px`, async ({ page }, testInfo) => {
  46 |   await page.setViewportSize({ width, height: 1000 });
  47 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  48 |   const failures: string[] = [];
  49 |   page.on('pageerror', error => failures.push(error.message));
  50 |   page.on('response', response => { if (response.url().includes('/brand/') && !response.ok()) failures.push(response.url()); });
  51 |   await page.goto('/');
  52 |   for (const language of ['VI', 'JA', 'EN']) {
  53 |     await page.getByRole('button', { name: language, exact: true }).click();
  54 |     for (const route of routes) {
  55 |       await page.locator(`.nav-item[href="#${route}"]`).click();
  56 |       await expect(page.locator(`.nav-item[href="#${route}"]`)).toHaveAttribute('aria-current', 'page');
  57 |       await page.evaluate(() => document.fonts.ready);
  58 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  59 |       await expect(page.locator('main')).toBeVisible();
  60 |       await expect(page.locator(width < 768 ? '.brand-compact' : '.brand-horizontal')).toBeVisible();
  61 |       if (language === 'EN') await page.screenshot({ path: `${process.env.LAB_BRAND_EVIDENCE_DIR ?? testInfo.outputDir}/lab-${route}-${width}.png`, fullPage: true });
  62 |     }
  63 |   }
  64 |   expect(await page.evaluate(() => document.fonts.check('14px "Be Vietnam Pro"'))).toBe(true);
  65 |   expect(failures).toEqual([]);
  66 | });
  67 | 
  68 | test('primary, disabled and unknown states retain readable semantics', async ({ page }) => {
  69 |   await page.goto('/#design');
  70 |   await page.getByRole('button', { name: 'EN', exact: true }).click();
  71 |   await page.locator('#chassis').selectOption('valetudo');
  72 |   const disabled = page.locator('#battery');
  73 |   await expect(disabled).toBeDisabled();
  74 |   await expect(disabled).toHaveCSS('opacity', '1');
  75 |   await page.locator('.nav-item[href="#scenarios"]').click();
  76 |   const unavailable = page.getByRole('button', { name: 'Create run', exact: true });
  77 |   await expect(unavailable).toBeDisabled();
  78 |   await expect(unavailable).toHaveCSS('background-color', 'rgb(16, 47, 52)');
  79 |   await expect(unavailable).toHaveCSS('color', 'rgb(168, 194, 198)');
  80 |   await page.locator('.nav-item[href="#deployment"]').click();
  81 |   const primary = page.getByRole('button', { name: 'Export draft candidate', exact: true });
  82 |   await expect(primary).toHaveCSS('background-color', 'rgb(185, 251, 117)');
  83 |   await primary.hover();
  84 |   await expect(primary).toHaveCSS('background-color', 'rgb(185, 251, 117)');
  85 |   await expect(primary).toHaveCSS('color', 'rgb(7, 29, 33)');
  86 |   await page.locator('.nav-item[href="#twin"]').click();
  87 |   await expect(page.getByTestId('preflight')).toContainText('fail');
  88 |   await expect(page.locator('main')).toHaveAttribute('aria-busy', 'false');
  89 | });
  90 | 
```