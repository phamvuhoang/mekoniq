# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: brand-ui.spec.ts >> canonical theme, original artwork and keyboard focus
- Location: tests/e2e/brand-ui.spec.ts:4:1

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  locator('.skip-link')
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" locator('.skip-link') with timeout 5000ms
  - waiting for locator('.skip-link')
    13 × locator resolved to <a class="skip-link" href="#workspace">Đến vùng làm việc</a>
       - unexpected value "inactive"

```

```yaml
- link "Đến vùng làm việc":
  - /url: "#workspace"
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | 
  3  | const routes = ['design', 'restaurant', 'scenarios', 'twin', 'results', 'deployment'];
  4  | test('canonical theme, original artwork and keyboard focus', async ({ page }) => {
  5  |   await page.goto('/#design');
  6  |   await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(7, 29, 33)');
  7  |   const brand = page.getByRole('link', { name: 'MEKONIQ Robot Lab', exact: true });
  8  |   await expect(brand).toBeVisible();
  9  |   await expect(brand.locator('.brand-horizontal')).toHaveAttribute('src', '/brand/assets/MEKONIQ_Horizontal_White_Transparent_v2.png');
  10 |   await expect(brand.locator('.brand-horizontal')).toHaveCSS('width', '180px');
  11 |   await page.keyboard.press('Tab');
> 12 |   await expect(page.locator('.skip-link')).toBeFocused();
     |                                            ^ Error: expect(locator).toBeFocused() failed
  13 |   await page.keyboard.press('Tab');
  14 |   await expect(brand).toBeFocused();
  15 |   await expect(brand).toHaveCSS('outline-color', 'rgb(99, 220, 197)');
  16 | });
  17 | 
  18 | for (const width of [390, 1024, 1512]) test(`six workspaces and three locales at ${width}px`, async ({ page }, testInfo) => {
  19 |   await page.setViewportSize({ width, height: 1000 });
  20 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  21 |   const failures: string[] = [];
  22 |   page.on('pageerror', error => failures.push(error.message));
  23 |   page.on('response', response => { if (response.url().includes('/brand/') && !response.ok()) failures.push(response.url()); });
  24 |   await page.goto('/');
  25 |   for (const language of ['VI', 'JA', 'EN']) {
  26 |     await page.getByRole('button', { name: language, exact: true }).click();
  27 |     for (const route of routes) {
  28 |       await page.locator(`.nav-item[href="#${route}"]`).click();
  29 |       await expect(page.locator(`.nav-item[href="#${route}"]`)).toHaveAttribute('aria-current', 'page');
  30 |       await page.evaluate(() => document.fonts.ready);
  31 |       expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  32 |       await expect(page.locator('main')).toBeVisible();
  33 |       await expect(page.locator(width < 768 ? '.brand-compact' : '.brand-horizontal')).toBeVisible();
  34 |       if (language === 'EN') await page.screenshot({ path: `${process.env.LAB_BRAND_EVIDENCE_DIR ?? testInfo.outputDir}/lab-${route}-${width}.png`, fullPage: true });
  35 |     }
  36 |   }
  37 |   expect(await page.evaluate(() => document.fonts.check('14px "Be Vietnam Pro"'))).toBe(true);
  38 |   expect(failures).toEqual([]);
  39 | });
  40 | 
  41 | test('primary, disabled and unknown states retain readable semantics', async ({ page }) => {
  42 |   await page.goto('/#design');
  43 |   await page.getByRole('button', { name: 'EN', exact: true }).click();
  44 |   await page.locator('#chassis').selectOption('valetudo');
  45 |   const disabled = page.locator('#battery');
  46 |   await expect(disabled).toBeDisabled();
  47 |   await expect(disabled).toHaveCSS('opacity', '1');
  48 |   await page.locator('.nav-item[href="#scenarios"]').click();
  49 |   const unavailable = page.getByRole('button', { name: 'Create run', exact: true });
  50 |   await expect(unavailable).toBeDisabled();
  51 |   await expect(unavailable).toHaveCSS('background-color', 'rgb(16, 47, 52)');
  52 |   await expect(unavailable).toHaveCSS('color', 'rgb(168, 194, 198)');
  53 |   await page.locator('.nav-item[href="#deployment"]').click();
  54 |   const primary = page.getByRole('button', { name: 'Export draft candidate', exact: true });
  55 |   await expect(primary).toHaveCSS('background-color', 'rgb(185, 251, 117)');
  56 |   await primary.hover();
  57 |   await expect(primary).toHaveCSS('background-color', 'rgb(185, 251, 117)');
  58 |   await expect(primary).toHaveCSS('color', 'rgb(7, 29, 33)');
  59 |   await page.locator('.nav-item[href="#twin"]').click();
  60 |   await expect(page.getByTestId('preflight')).toContainText('fail');
  61 |   await expect(page.locator('main')).toHaveAttribute('aria-busy', 'false');
  62 | });
  63 | 
```