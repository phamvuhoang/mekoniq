# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: brand-focus.spec.ts >> controlled normal two Tabs then actual startup health
- Location: ../../../../../../../../private/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/brand-focus-diagnostic/tests/brand-focus.spec.ts:27:5

# Error details

```
Error: expect(locator).toBeFocused() failed

Locator:  getByRole('link', { name: 'MEKONIQ Robot Lab', exact: true })
Expected: focused
Received: inactive
Timeout:  5000ms

Call log:
  - Expect "toBeFocused" getByRole('link', { name: 'MEKONIQ Robot Lab', exact: true }) with timeout 5000ms
  - waiting for getByRole('link', { name: 'MEKONIQ Robot Lab', exact: true })
    14 × locator resolved to <a href="#design" class="brand mq-brand" aria-label="MEKONIQ Robot Lab">…</a>
       - unexpected value "inactive"

```

```yaml
- link "MEKONIQ Robot Lab":
  - /url: "#design"
  - text: ROBOT LAB
```

# Test source

```ts
  1  | import {test,expect,type Page} from '@playwright/test';
  2  | import {appendFileSync,writeFileSync} from 'node:fs';
  3  | import {join} from 'node:path';
  4  | import {createHash} from 'node:crypto';
  5  | const out=process.env.BRAND_FOCUS_DIAGNOSTIC_OUT!;
  6  | async function observer(page:Page,label:string){
  7  |  await page.exposeBinding('__focusEvent',(_source,event)=>{appendFileSync(join(out,label+'.ndjson'),JSON.stringify({receivedEpochMs:Date.now(),receivedMonotonicNs:process.hrtime.bigint().toString(),event})+'\n');});
  8  |  await page.addInitScript(()=>{const w=window as any,ids=new WeakMap<Node,number>();let next=1,oldSkip:Element|null=null,oldBrand:Element|null=null,last='';const id=(node:Node|null)=>{if(!node)return null;if(!ids.has(node))ids.set(node,next++);return ids.get(node);};const describe=(node:Element|null)=>node?{nodeId:id(node),tag:node.tagName,id:node.id,class:node.className,href:node.getAttribute('href'),text:node.textContent?.slice(0,100),connected:node.isConnected}:null;
  9  |   const state=()=>{const skip=document.querySelector('.skip-link'),brand=document.querySelector('a.brand');if(!oldSkip&&skip)oldSkip=skip;if(!oldBrand&&brand)oldBrand=brand;return {active:describe(document.activeElement),hasFocus:document.hasFocus(),skip:describe(skip),brand:describe(brand),oldSkip:describe(oldSkip),oldBrand:describe(oldBrand),sameSkip:skip===oldSkip,sameBrand:brand===oldBrand,ready:document.readyState};};
  10 |   const emit=(kind:string,extra:unknown={})=>{const event={kind,epochMs:Date.now(),atMs:performance.now(),timeOriginEpochMs:performance.timeOrigin,state:state(),extra};w.__focusEvents??=[];w.__focusEvents.push(event);void w.__focusEvent(event);};w.__focusState=state;w.__focusMark=emit;
  11 |   for(const kind of ['focusin','focusout','keydown'])document.addEventListener(kind,(e:any)=>emit(kind,{key:e.key??null,target:describe(e.target)}),true);
  12 |   new MutationObserver(()=>{const s=state(),key=JSON.stringify(s);if(key!==last){last=key;emit('node-state');}}).observe(document,{childList:true,subtree:true});emit('init');
  13 |  });
  14 | }
  15 | async function startupHealth(page:Page,label:string){let release!:()=>void,ready!:()=>void;const gate=new Promise<void>(resolve=>release=resolve),captured=new Promise<void>(resolve=>ready=resolve);let first=true;
  16 |  await page.route('**/lab/v1/health',async route=>{if(route.request().method()!=='GET'||!first){await route.continue();return;}first=false;const response=await route.fetch(),body=await response.body();writeFileSync(join(out,label+'-health-body.bin'),body);writeFileSync(join(out,label+'-health-response.json'),JSON.stringify({url:response.url(),status:response.status(),headers:response.headers(),bytes:body.length,sha256:createHash('sha256').update(body).digest('hex'),capturedAtEpochMs:Date.now()},null,2));ready();await gate;appendFileSync(join(out,label+'.ndjson'),JSON.stringify({event:{kind:'release-actual-health',epochMs:Date.now(),status:response.status()}})+'\n');await route.fulfill({response});});
  17 |  return {captured,release};
  18 | }
  19 | async function mark(page:Page,label:string,name:string){await page.evaluate(name=>(window as any).__focusMark(name),name);writeFileSync(join(out,label+'-'+name+'.json'),JSON.stringify(await page.evaluate(()=>(window as any).__focusState()),null,2));await page.screenshot({path:join(out,label+'-'+name+'.png')});}
  20 | async function setup(page:Page,label:string){await observer(page,label);const health=await startupHealth(page,label);await page.goto('/#design');await expect(page.locator('body')).toHaveCSS('background-color','rgb(7, 29, 33)');const brand=page.getByRole('link',{name:'MEKONIQ Robot Lab',exact:true});await expect(brand).toBeVisible();await expect(brand.locator('.brand-horizontal')).toHaveAttribute('src','/brand/assets/MEKONIQ_Horizontal_White_Transparent_v2.png');await expect(brand.locator('.brand-horizontal')).toHaveCSS('width','180px');await health.captured;return {health,brand};}
  21 | async function renderedAfterHealth(page:Page){await expect.poll(()=>page.evaluate(()=>(window as any).__focusState().oldSkip?.connected)).toBe(false);}
  22 | test.afterEach(async({page},info)=>{writeFileSync(join(out,info.title.replace(/[^a-zA-Z0-9]+/g,'-')+'-final.json'),JSON.stringify(await page.evaluate(()=>({events:(window as any).__focusEvents,state:(window as any).__focusState(),html:document.documentElement.outerHTML})).catch(e=>({error:String(e)})),null,2));});
  23 | test('controlled first Tab then actual startup health then second Tab',async({page})=>{const label='skip', {health,brand}=await setup(page,label);try{
  24 |  await page.keyboard.press('Tab');await expect(page.locator('.skip-link')).toBeFocused();await mark(page,label,'skip-focused-before-health');health.release();await renderedAfterHealth(page);await mark(page,label,'after-health-render');
  25 |  await page.keyboard.press('Tab');await expect(brand).toBeFocused();await expect(brand).toHaveCSS('outline-color','rgb(99, 220, 197)');
  26 |  }finally{health.release();}});
  27 | test('controlled normal two Tabs then actual startup health',async({page})=>{const label='brand', {health,brand}=await setup(page,label);try{
> 28 |  await page.keyboard.press('Tab');await expect(page.locator('.skip-link')).toBeFocused();await page.keyboard.press('Tab');await expect(brand).toBeFocused();await expect(brand).toHaveCSS('outline-color','rgb(99, 220, 197)');await mark(page,label,'brand-focused-before-health');health.release();await renderedAfterHealth(page);await mark(page,label,'after-health-render');await expect(brand).toBeFocused();
     |                                                                                                                                                                                                                                                                                                                                                                                                       ^ Error: expect(locator).toBeFocused() failed
  29 |  }finally{health.release();}});
  30 | 
```