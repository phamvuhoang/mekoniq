# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-bar-compact.spec.ts >> coffee attention controls and complete runtime words fit one row at 1024px
- Location: tests/e2e/run-bar-compact.spec.ts:3:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 48
Received: 98
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Đến vùng làm việc" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic [ref=e7]:
      - generic [ref=e8]: PREVIEW
      - generic "Language" [ref=e10]:
        - button "VI" [pressed] [ref=e11] [cursor=pointer]
        - button "JA" [ref=e12] [cursor=pointer]
        - button "EN" [ref=e13] [cursor=pointer]
      - link "Kế hoạch kinh doanh ↗" [ref=e14] [cursor=pointer]:
        - /url: /business-plan.html
  - generic [ref=e15]:
    - complementary [ref=e16]:
      - generic [ref=e17]: KHÔNG GIAN LÀM VIỆC
      - navigation "Điều hướng chính" [ref=e18]:
        - link "Thiết kế" [ref=e19] [cursor=pointer]:
          - /url: "#design"
        - link "Lắp ráp" [ref=e23] [cursor=pointer]:
          - /url: "#assembly"
        - link "Mặt bằng" [ref=e27] [cursor=pointer]:
          - /url: "#restaurant"
        - link "Kịch bản" [ref=e31] [cursor=pointer]:
          - /url: "#scenarios"
        - link "Bản sao số" [ref=e35] [cursor=pointer]:
          - /url: "#twin"
        - link "Kết quả" [ref=e39] [cursor=pointer]:
          - /url: "#results"
        - link "Triển khai" [ref=e44] [cursor=pointer]:
          - /url: "#deployment"
      - generic [ref=e48]:
        - generic [ref=e49]: MEKONIQ ENGINEERING LAB
        - paragraph [ref=e54]: Từ ý tưởng đến vận hành.
        - generic [ref=e55]:
          - text: LAB v0.1
          - generic [ref=e57]: R0
    - main [ref=e58]:
      - heading "Bản sao số" [level=1] [ref=e59]
      - generic [ref=e60]:
        - region "Lần chạy" [ref=e61]:
          - generic [ref=e62]:
            - button "Kịch bản" [ref=e63] [cursor=pointer]:
              - generic [ref=e64]:
                - generic [ref=e65]: Kịch bản
                - generic [ref=e66]: Cà phê sữa đá
            - 'button "Runtime: Đang kết nối" [ref=e69] [cursor=pointer]':
              - generic [ref=e71]: "Runtime:"
              - generic [ref=e72]: Đang kết nối
            - button "Mô phỏng · MOCK" [ref=e73] [cursor=pointer]
          - generic [ref=e78]:
            - generic [ref=e79]:
              - generic [ref=e80]: Trạng thái
              - generic [ref=e81]: Cần kiểm tra
            - generic [ref=e82]:
              - generic [ref=e83]: Thời gian mô phỏng
              - generic [ref=e84]: 4.2 s
            - generic [ref=e85]:
              - generic [ref=e86]: Đã giao
              - generic [ref=e87]: "0"
            - button "1 vấn đề" [ref=e88] [cursor=pointer]:
              - generic [ref=e92]:
                - text: "1"
                - generic [ref=e93]: vấn đề
            - button "Tiếp tục" [ref=e94] [cursor=pointer]
            - button "Chi tiết" [ref=e95] [cursor=pointer]
        - region "Khung nhìn" [ref=e100]:
          - generic "Bản sao 3D. Chọn vật thể từ danh sách." [ref=e102]
          - generic [ref=e103]:
            - 'button "Về góc nhìn gốc (kịch bản tay máy: trạm tay máy)" [ref=e104] [cursor=pointer]'
            - 'button "Vừa khung đối tượng chọn (không chọn: cả mặt bằng)" [ref=e107] [cursor=pointer]'
            - button "Chế độ xem" [ref=e110] [cursor=pointer]
            - button "Phím tắt" [ref=e114] [cursor=pointer]
            - button "Hiển thị" [ref=e118] [cursor=pointer]
        - group "Điều khiển lần chạy" [ref=e121]:
          - button "Tự chạy" [disabled] [ref=e122]
          - button "+5 s" [disabled] [ref=e126]
          - button "Tạm dừng mô phỏng" [disabled] [ref=e130]
          - generic [ref=e134]:
            - generic [ref=e135]: Tốc độ chạy
            - combobox "Tốc độ chạy" [ref=e136]:
              - option "1×"
              - option "4×"
              - option "16×" [selected]
              - option "64×"
          - generic [ref=e138]: 0.0 s · tick 0
          - button "Hủy lần chạy" [disabled] [ref=e139]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | // Component layout regression: production markup/CSS and real allowed connection words, no runtime/private-state changes.
  3  | test('coffee attention controls and complete runtime words fit one row at 1024px',async({page},testInfo)=>{
  4  |  await page.setViewportSize({width:1024,height:700});await page.goto('/#twin');await page.locator('#twin-run-bar').waitFor();
  5  |  await page.evaluate(async()=>{
  6  |   const module='/src/ui/run-bar.ts',i18n='/src/i18n/index.ts';
  7  |   const {runBar,simLabel}=await import(module),{setLocale}=await import(i18n);setLocale('vi');
  8  |   document.querySelector('#twin-run-bar')!.outerHTML=runBar({scenarioTitle:'Cà phê sữa đá',runtime:{state:'connecting',label:'Đang kết nối',detail:''},mode:simLabel('mock',false),status:'Cần kiểm tra',simTimeS:4.2,served:'0',problems:1,primary:{action:'twin-resume',label:'Tiếp tục',disabled:false},inspectorOpen:false});
  9  |  });
  10 |  const layout=await page.locator('#twin-run-bar').evaluate(bar=>({height:bar.getBoundingClientRect().height,width:bar.getBoundingClientRect().width,items:[...bar.querySelectorAll('.twin-runbar-left,.twin-runbar-right,.twin-runbar-left>*,.twin-runbar-right>*')].map(el=>({text:el.textContent,rect:el.getBoundingClientRect().toJSON(),minWidth:getComputedStyle(el).minWidth,gap:getComputedStyle(el).gap,flex:getComputedStyle(el).flex}))}));
  11 |  await testInfo.attach('layout',{body:JSON.stringify(layout,null,2),contentType:'application/json'});
> 12 |  expect(layout.height).toBe(48);
     |                        ^ Error: expect(received).toBe(expected) // Object.is equality
  13 | });
  14 | 
```