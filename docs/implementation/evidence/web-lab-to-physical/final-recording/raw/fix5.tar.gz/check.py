import os,sys,pathlib,json,subprocess,hashlib,datetime,signal
raw=pathlib.Path(__file__).parent
base=pathlib.Path('/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical');lab=base/'lab';meta=base/'source/.superpowers/sdd/README/evidence-final-recording/fix5'
name=sys.argv[1]; cmd=sys.argv[2:]; cwd=base/'source' if name.startswith('production-diagnostic') else lab
env=dict(os.environ,PATH=str(pathlib.Path.home()/'.nvm/versions/node/v24.22.2/bin')+':'+os.environ['PATH'],PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-p no:cacheprovider',LAB_PW_OUTPUT_DIR=str(raw/name/'artifacts'),LAB_PW_JSON=str(raw/name/'playwright.json'))
def snap():
 files=subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=lab,text=True).splitlines()
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=lab,text=True),'files':{p:{'sha256':hashlib.sha256((lab/p).read_bytes()).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str((lab/p).stat().st_size).encode()+b'\0'+(lab/p).read_bytes()).hexdigest()} for p in sorted(set(files)) if (lab/p).is_file()}}
r={'argv':cmd,'cwd':str(cwd),'env':{k:env[k] for k in ['PATH','PYTHONDONTWRITEBYTECODE','PYTEST_ADDOPTS','LAB_PW_OUTPUT_DIR','LAB_PW_JSON']},'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':snap()}
(raw/name).mkdir(); log=raw/name/'output.log'
with log.open('wb') as f:
 p=subprocess.Popen(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT); code=p.wait()
r.update(finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=code if code>=0 else None,signal=signal.Signals(-code).name if code<0 else None,after=snap(),log=str(log),logSha256=hashlib.sha256(log.read_bytes()).hexdigest())
(meta/(name+'.receipt.json')).write_text(json.dumps(r,indent=2)); print(log.read_text()); print(json.dumps({k:r[k] for k in ['exitCode','signal','log']}));sys.exit(code if code>=0 else 1)
