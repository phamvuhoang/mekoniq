import {createServer} from 'node:http';
import {createRequire} from 'node:module';
import {mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const require=createRequire('/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/lab/package.json'),{chromium}=require('@playwright/test');
const out=new URL('./delete-body-comparison/',import.meta.url);await mkdir(out);const body=JSON.stringify({deleted:true}),events=[],responses=[];let browser,server;
const log=(kind,data={})=>events.push({kind,atEpochMs:performance.timeOrigin+performance.now(),...data});
try{
 server=createServer((req,res)=>{log('server-request',{url:req.url,method:req.method});res.on('finish',()=>log('server-finish',{url:req.url}));res.on('close',()=>log('server-close',{url:req.url}));if(req.url.startsWith('/lab/v2/')){res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(body);}else res.end('<!doctype html><p>Owned delete response comparison</p>');});await new Promise(r=>server.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${server.address().port}`;
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH??'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});const page=await browser.newPage();
 for(const event of ['requestfinished','requestfailed'])page.on(event,r=>{if(r.url().includes('/lab/v2/'))log(event,{url:r.url(),timing:r.timing(),failure:r.failure()});});
 page.on('response',r=>{if(!r.url().includes('/lab/v2/'))return;const row={url:r.url(),status:r.status(),headers:r.headers(),state:'pending',request:r.request()};responses.push(row);log('response',{url:r.url(),status:r.status(),headers:r.headers()});void r.finished().then(()=>{row.state='finished';log('finished-promise',{url:r.url()});},e=>{row.state='rejected';log('finished-rejected',{url:r.url(),error:String(e)});});});
 await page.goto(url);
 const headerOnly=await page.evaluate(async()=>{const r=await fetch('/lab/v2/runs/run-1/replay/header-only',{method:'DELETE'});return {ok:r.ok,status:r.status};});
 const consumed=await page.evaluate(async()=>{const r=await fetch('/lab/v2/runs/run-1/replay/consumed',{method:'DELETE'});return {ok:r.ok,status:r.status,body:await r.json()};});
 await new Promise(r=>setTimeout(r,1500));const snapshot=()=>responses.map(({request,...row})=>({...row,timing:request.timing(),failure:request.failure()})),beforeClose=snapshot();
 await writeFile(new URL('before-close.json',out),JSON.stringify({headerOnly,consumed,responses:beforeClose,events},null,2));await page.close();
 const result={scope:'Owned synthetic HTTP/browser lifecycle comparison only; no Source/runtime/qualification',browser:browser.version(),playwright:require('@playwright/test/package.json').version,url,fixture:{body,sha256:createHash('sha256').update(body).digest('hex')},headerOnly,consumed,beforeClose,afterClose:snapshot(),events};await writeFile(new URL('result.json',out),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await browser?.close();server?.closeAllConnections();if(server)await new Promise(r=>server.close(r));await writeFile(new URL('cleanup.json',out),JSON.stringify({browserClosed:true,serverListening:server?.listening??false}));}
