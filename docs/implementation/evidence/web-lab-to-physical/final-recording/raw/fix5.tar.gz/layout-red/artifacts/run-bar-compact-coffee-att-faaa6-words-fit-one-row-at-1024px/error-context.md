# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-bar-compact.spec.ts >> coffee attention controls and complete runtime words fit one row at 1024px
- Location: tests/e2e/run-bar-compact.spec.ts:3:1

# Error details

```
Error: page.evaluate: TypeError: Cannot set properties of null (setting 'outerHTML')
    at eval (eval at evaluate (:370:30), <anonymous>:12:55)
    at async <anonymous>:396:30
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Đến vùng làm việc" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic [ref=e7]:
      - generic [ref=e8]: PREVIEW
      - generic "Language" [ref=e10]:
        - button "VI" [pressed] [ref=e11] [cursor=pointer]
        - button "JA" [ref=e12] [cursor=pointer]
        - button "EN" [ref=e13] [cursor=pointer]
      - link "Kế hoạch kinh doanh ↗" [ref=e14] [cursor=pointer]:
        - /url: /business-plan.html
  - generic [ref=e15]:
    - complementary [ref=e16]:
      - generic [ref=e17]: KHÔNG GIAN LÀM VIỆC
      - navigation "Điều hướng chính" [ref=e18]:
        - link "Thiết kế" [ref=e19] [cursor=pointer]:
          - /url: "#design"
        - link "Lắp ráp" [ref=e23] [cursor=pointer]:
          - /url: "#assembly"
        - link "Mặt bằng" [ref=e27] [cursor=pointer]:
          - /url: "#restaurant"
        - link "Kịch bản" [ref=e31] [cursor=pointer]:
          - /url: "#scenarios"
        - link "Bản sao số" [ref=e35] [cursor=pointer]:
          - /url: "#twin"
        - link "Kết quả" [ref=e39] [cursor=pointer]:
          - /url: "#results"
        - link "Triển khai" [ref=e44] [cursor=pointer]:
          - /url: "#deployment"
      - generic [ref=e48]:
        - generic [ref=e49]: MEKONIQ ENGINEERING LAB
        - paragraph [ref=e54]: Từ ý tưởng đến vận hành.
        - generic [ref=e55]:
          - text: LAB v0.1
          - generic [ref=e57]: R0
    - main [ref=e58]:
      - heading "Bản sao số" [level=1] [ref=e59]
      - generic [ref=e60]:
        - region "Lần chạy" [ref=e61]:
          - generic [ref=e62]:
            - button "Kịch bản" [ref=e63] [cursor=pointer]:
              - generic [ref=e64]:
                - generic [ref=e65]: Kịch bản
                - generic [ref=e66]: Cà phê sữa đá
            - 'button "Runtime: Không kết nối được" [expanded] [ref=e69] [cursor=pointer]':
              - generic [ref=e71]: "Runtime:"
              - generic [ref=e72]: Không kết nối được
            - button "Mô phỏng · chưa chạy" [ref=e73] [cursor=pointer]
          - generic [ref=e78]:
            - generic [ref=e79]:
              - generic [ref=e80]: Trạng thái
              - generic [ref=e81]: —
            - generic [ref=e82]:
              - generic [ref=e83]: Thời gian mô phỏng
              - generic [ref=e84]: —
            - generic [ref=e85]:
              - generic [ref=e86]: Đã giao
              - generic [ref=e87]: —
            - button "1 vấn đề" [ref=e88] [cursor=pointer]:
              - generic [ref=e92]:
                - text: "1"
                - generic [ref=e93]: vấn đề
            - button "Chi tiết" [ref=e94] [cursor=pointer]
          - generic [ref=e98]:
            - heading "Runtime" [level=3] [ref=e99]
            - generic [ref=e100]:
              - group "Runtime chạy ở" [ref=e101]:
                - generic [ref=e103]:
                  - radio "Máy này" [checked] [ref=e104]
                  - text: Máy này
                - generic [ref=e105]:
                  - radio "Địa chỉ khác" [ref=e106]
                  - text: Địa chỉ khác
              - generic [ref=e107]: "Địa chỉ runtime (để trống: runtime của trang này)"
              - 'textbox "Địa chỉ runtime (để trống: runtime của trang này)" [ref=e108]':
                - /placeholder: http://127.0.0.1:4176
              - generic [ref=e109]: Mã ghép nối một lần từ terminal runtime
              - generic [ref=e110]:
                - textbox "Mã ghép nối một lần từ terminal runtime" [ref=e111]
                - button "Ghép nối runtime" [ref=e112] [cursor=pointer]
            - alert [ref=e115]: "RUNTIME_UNREACHABLE: Không thấy runtime /lab/v2. Chạy runtime trên máy phát triển; Lab không tự báo hoàn thành khi thiếu runner."
            - generic [ref=e116]:
              - generic [ref=e117]:
                - term [ref=e118]: Lab ghim
                - definition [ref=e119]:
                  - code [ref=e120]: "981e234"
              - generic [ref=e121]:
                - term [ref=e122]: Runtime chạy
                - definition [ref=e123]:
                  - code [ref=e124]: —
        - region "Khung nhìn" [ref=e126]:
          - generic "Bản sao 3D. Chọn vật thể từ danh sách." [ref=e128]
          - generic [ref=e129]:
            - 'button "Về góc nhìn gốc (kịch bản tay máy: trạm tay máy)" [ref=e130] [cursor=pointer]'
            - 'button "Vừa khung đối tượng chọn (không chọn: cả mặt bằng)" [ref=e133] [cursor=pointer]'
            - button "Chế độ xem" [ref=e136] [cursor=pointer]
            - button "Phím tắt" [ref=e140] [cursor=pointer]
            - button "Hiển thị" [ref=e144] [cursor=pointer]
        - group "Điều khiển lần chạy" [ref=e147]:
          - button "Tự chạy" [disabled] [ref=e148]
          - button "+5 s" [disabled] [ref=e152]
          - button "Tạm dừng mô phỏng" [disabled] [ref=e156]
          - generic [ref=e160]:
            - generic [ref=e161]: Tốc độ chạy
            - combobox "Tốc độ chạy" [ref=e162]:
              - option "1×"
              - option "4×"
              - option "16×" [selected]
              - option "64×"
          - generic [ref=e164]: 0.0 s · tick 0
          - button "Hủy lần chạy" [disabled] [ref=e165]
```