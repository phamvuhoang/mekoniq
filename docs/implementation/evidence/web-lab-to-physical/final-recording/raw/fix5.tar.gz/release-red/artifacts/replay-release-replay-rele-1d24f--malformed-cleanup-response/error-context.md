# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: replay-release.spec.ts >> replay release consumes and validates malformed cleanup response
- Location: tests/e2e/replay-release.spec.ts:7:86

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "INVALID_RUNTIME_RESPONSE"
Received: null
```

# Page snapshot

```yaml
- generic [active] [ref=e1]: "{ \"dirty\": false, \"packageVersion\": \"0.1.0\", \"toolchain\": { \"node\": \"v24.22.2\" }, \"sourceCommit\": \"981e234b1a0da8c72d220445daaf780b3bf65ae4\", \"schemaHash\": \"0d4ae124258123d27a21b67a8441dee13d703fd5ab7596ad298bcab9233a31e5\", \"protocolMajor\": 2, \"protocolMajors\": [ 1, 2 ], \"nodeMajor\": 24, \"artifactSha256\": \"8eb11109765263e0b209ece7649bb511b8f67a0c0a035edba1d78b803d4ceec1\", \"entrypoint\": \"runtime.mjs\", \"portableToolsDigest\": \"30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b\" }"
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {createServer} from 'node:http';
  3  | import {createHash} from 'node:crypto';
  4  | import {gzipSync} from 'node:zlib';
  5  | import {observeProductionHTTP} from '../../scripts/production-http-observer';
  6  | // Public production httpTwinRuntime -> owned real HTTP -> browser terminal events. Synthetic bytes establish lifecycle, not qualification.
  7  | for(const mode of ['valid','malformed','incomplete','refused','unfinished'] as const)test(`replay release consumes and validates ${mode} cleanup response`,async({page},testInfo)=>{
  8  |  const plain=Buffer.from(JSON.stringify({manifest:{runId:'run-one'},outcome:{tick:7}})),bytes=gzipSync(plain),sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
  9  |  const manifest={schemaVersion:1,documentType:'web-replay-package',runId:'run-one',horizon:{tick:7,tickMs:20},provenance:{kind:'imported_integrity_only',accepted:false,calibration:'not_calibrated',scope:'display_only_not_requalification',reportTransform:'credential_redaction_v1',rawReportSha256:sha(plain)},coverage:{prefixCovered:false,streamFinalized:false,sampled:false,terminal:null,gaps:[],issues:['NO_STREAM']},assets:[{path:'report.json.gz',sha256:sha(bytes),decodedSha256:sha(plain),bytes:bytes.length,decodedBytes:plain.length,encoding:'gzip',role:'report',mediaType:'application/json'}],streams:[],licensing:[]};
  10 |  const deletes:string[]=[],server=createServer((req,res)=>{
  11 |   res.setHeader('Access-Control-Allow-Origin','http://127.0.0.1:4175');res.setHeader('Access-Control-Allow-Methods','GET,POST,DELETE,OPTIONS');res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization');
  12 |   if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
  13 |   if(req.method==='DELETE'){
  14 |    deletes.push(req.url!);res.writeHead(mode==='refused'?403:200,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  15 |    if(mode==='unfinished'){res.flushHeaders();res.write('{"deleted":');return;}
  16 |    res.end(mode==='valid'?'{"deleted":true}':mode==='incomplete'?'{}':mode==='refused'?'{"error":"CAPABILITY_DENIED"}':'{');return;
  17 |   }
  18 |   if(req.url?.endsWith('/assets/0')){res.writeHead(200,{'Content-Type':'application/octet-stream'});res.end(bytes);return;}
  19 |   res.writeHead(201,{'Content-Type':'application/json'});res.end(JSON.stringify({exportId:'owned-version',manifest}));
  20 |  });
  21 |  await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base=`http://127.0.0.1:${(server.address() as {port:number}).port}/lab/v2`,rows={responses:[] as Record<string,unknown>[],actions:[],exports:[],errors:[] as string[]};let observer:ReturnType<typeof observeProductionHTTP>|undefined;
  22 |  try{
  23 |   await page.goto('/source-runtime.lock.json');observer=observeProductionHTTP(page,rows,{timeoutMs:15000,drainTimeoutMs:1000});
  24 |   const result=await page.evaluate(async base=>{
  25 |    const module='/src/scenarios/controls.ts',{httpTwinRuntime}=await import(module),rt=httpTwinRuntime({base,kind:'remote'}),exportAbort=new AbortController(),capture=await rt.exportReplay('run-one',exportAbort.signal);
  26 |    capture.reader.close();exportAbort.abort();// cleanup must remain possible after the export's own cancellation
  27 |    const start=performance.now();let error:string|null=null;try{await capture.release();}catch(e){error=(e as Error).message;}await capture.release();return {error,elapsedMs:performance.now()-start};
  28 |   },base);
  29 |   await observer.finish();await testInfo.attach('observations',{body:JSON.stringify({result,rows,deletes},null,2),contentType:'application/json'});
  30 |   expect(deletes).toEqual(['/lab/v2/runs/run-one/replay/owned-version']);
  31 |   if(mode==='valid'){
  32 |    expect(result.error).toBeNull();expect(rows.errors).toEqual([]);expect(rows.responses.find(r=>r.method==='DELETE')).toMatchObject({status:200,outcome:'completed'});
> 33 |   }else expect(result.error).toBe(mode==='refused'?'REPLAY_DELETE_REFUSED':mode==='unfinished'?'REPLAY_DELETE_TIMEOUT':'INVALID_RUNTIME_RESPONSE');
     |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  34 |   if(mode==='unfinished'){expect(result.elapsedMs).toBeLessThan(12000);expect(rows.responses.find(r=>r.method==='DELETE')!.outcome).not.toBe('completed');}
  35 |  }finally{observer?.dispose();server.closeAllConnections();await new Promise<void>(r=>server.close(()=>r()));}
  36 | });
  37 | 
```