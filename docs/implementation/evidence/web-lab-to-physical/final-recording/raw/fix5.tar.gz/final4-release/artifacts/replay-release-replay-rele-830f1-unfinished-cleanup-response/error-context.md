# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: replay-release.spec.ts >> replay release consumes and validates unfinished cleanup response
- Location: tests/e2e/replay-release.spec.ts:7:86

# Error details

```
Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]: "{ \"dirty\": false, \"packageVersion\": \"0.1.0\", \"toolchain\": { \"node\": \"v24.22.2\" }, \"sourceCommit\": \"981e234b1a0da8c72d220445daaf780b3bf65ae4\", \"schemaHash\": \"0d4ae124258123d27a21b67a8441dee13d703fd5ab7596ad298bcab9233a31e5\", \"protocolMajor\": 2, \"protocolMajors\": [ 1, 2 ], \"nodeMajor\": 24, \"artifactSha256\": \"8eb11109765263e0b209ece7649bb511b8f67a0c0a035edba1d78b803d4ceec1\", \"entrypoint\": \"runtime.mjs\", \"portableToolsDigest\": \"30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b\" }"
```