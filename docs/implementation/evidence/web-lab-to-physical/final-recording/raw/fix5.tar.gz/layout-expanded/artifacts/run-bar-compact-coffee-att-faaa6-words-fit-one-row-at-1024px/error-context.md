# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-bar-compact.spec.ts >> coffee attention controls and complete runtime words fit one row at 1024px
- Location: tests/e2e/run-bar-compact.spec.ts:4:1

# Error details

```
Error: vi failed

expect(received).toBe(expected) // Object.is equality

Expected: 48
Received: 98
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Đến vùng làm việc" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic [ref=e7]:
      - generic [ref=e8]: PREVIEW
      - generic "Language" [ref=e10]:
        - button "VI" [pressed] [ref=e11] [cursor=pointer]
        - button "JA" [ref=e12] [cursor=pointer]
        - button "EN" [ref=e13] [cursor=pointer]
      - link "Kế hoạch kinh doanh ↗" [ref=e14] [cursor=pointer]:
        - /url: /business-plan.html
  - generic [ref=e15]:
    - complementary [ref=e16]:
      - generic [ref=e17]: KHÔNG GIAN LÀM VIỆC
      - navigation "Điều hướng chính" [ref=e18]:
        - link "Thiết kế" [ref=e19] [cursor=pointer]:
          - /url: "#design"
        - link "Lắp ráp" [ref=e23] [cursor=pointer]:
          - /url: "#assembly"
        - link "Mặt bằng" [ref=e27] [cursor=pointer]:
          - /url: "#restaurant"
        - link "Kịch bản" [ref=e31] [cursor=pointer]:
          - /url: "#scenarios"
        - link "Bản sao số" [ref=e35] [cursor=pointer]:
          - /url: "#twin"
        - link "Kết quả" [ref=e39] [cursor=pointer]:
          - /url: "#results"
        - link "Triển khai" [ref=e44] [cursor=pointer]:
          - /url: "#deployment"
      - generic [ref=e48]:
        - generic [ref=e49]: MEKONIQ ENGINEERING LAB
        - paragraph [ref=e54]: Từ ý tưởng đến vận hành.
        - generic [ref=e55]:
          - text: LAB v0.1
          - generic [ref=e57]: R0
    - main [ref=e58]:
      - heading "Bản sao số" [level=1] [ref=e59]
      - generic [ref=e60]:
        - region "Lần chạy" [ref=e61]:
          - generic [ref=e62]:
            - button "Kịch bản" [ref=e63] [cursor=pointer]:
              - generic [ref=e64]:
                - generic [ref=e65]: Kịch bản
                - generic [ref=e66]: Cà phê sữa đá
            - 'button "Runtime: Không kết nối được" [ref=e69] [cursor=pointer]':
              - generic [ref=e71]: "Runtime:"
              - generic [ref=e72]: Không kết nối được
            - button "Mô phỏng · MOCK" [ref=e73] [cursor=pointer]
          - generic [ref=e78]:
            - generic [ref=e79]:
              - generic [ref=e80]: Trạng thái
              - generic [ref=e81]: Cần kiểm tra
            - generic [ref=e82]:
              - generic [ref=e83]: Thời gian mô phỏng
              - generic [ref=e84]: 4.2 s
            - generic [ref=e85]:
              - generic [ref=e86]: Đã giao
              - generic [ref=e87]: "0"
            - button "1 vấn đề" [ref=e88] [cursor=pointer]:
              - generic [ref=e92]:
                - text: "1"
                - generic [ref=e93]: vấn đề
            - button "Tiếp tục" [ref=e94] [cursor=pointer]
            - button "Chi tiết" [ref=e95] [cursor=pointer]
        - region "Khung nhìn" [ref=e100]:
          - generic "Bản sao 3D. Chọn vật thể từ danh sách." [ref=e102]
          - generic [ref=e103]:
            - 'button "Về góc nhìn gốc (kịch bản tay máy: trạm tay máy)" [ref=e104] [cursor=pointer]'
            - 'button "Vừa khung đối tượng chọn (không chọn: cả mặt bằng)" [ref=e107] [cursor=pointer]'
            - button "Chế độ xem" [ref=e110] [cursor=pointer]
            - button "Phím tắt" [ref=e114] [cursor=pointer]
            - button "Hiển thị" [ref=e118] [cursor=pointer]
        - group "Điều khiển lần chạy" [ref=e121]:
          - button "Tự chạy" [disabled] [ref=e122]
          - button "+5 s" [disabled] [ref=e126]
          - button "Tạm dừng mô phỏng" [disabled] [ref=e130]
          - generic [ref=e134]:
            - generic [ref=e135]: Tốc độ chạy
            - combobox "Tốc độ chạy" [ref=e136]:
              - option "1×"
              - option "4×"
              - option "16×" [selected]
              - option "64×"
          - generic [ref=e138]: 0.0 s · tick 0
          - button "Hủy lần chạy" [disabled] [ref=e139]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {barLayout} from '../support/twin';
  3  | // Component layout regression: production markup/CSS and real allowed connection words, no runtime/private-state changes.
  4  | test('coffee attention controls and complete runtime words fit one row at 1024px',async({page},testInfo)=>{
  5  |  await page.setViewportSize({width:1024,height:700});await page.goto('/#twin');await page.locator('#twin-run-bar').waitFor();
  6  |  await page.evaluate(async()=>{
  7  |   const module='/src/ui/run-bar.ts',i18n='/src/i18n/index.ts';
  8  |   const {runBar,simLabel}=await import(module),{setLocale}=await import(i18n);setLocale('vi');
  9  |   document.querySelector('#twin-run-bar')!.outerHTML=runBar({scenarioTitle:'Cà phê sữa đá',runtime:{state:'connecting',label:'Đang kết nối',detail:''},mode:simLabel('mock',false),status:'Cần kiểm tra',simTimeS:4.2,served:'0',problems:1,primary:{action:'twin-resume',label:'Tiếp tục',disabled:false},inspectorOpen:false});
  10 |  });
  11 |  const layout=await page.locator('#twin-run-bar').evaluate(bar=>({height:bar.getBoundingClientRect().height,width:bar.getBoundingClientRect().width,items:[...bar.querySelectorAll('.twin-runbar-left,.twin-runbar-right,.twin-runbar-left>*,.twin-runbar-right>*')].map(el=>({text:el.textContent,rect:el.getBoundingClientRect().toJSON(),minWidth:getComputedStyle(el).minWidth,gap:getComputedStyle(el).gap,flex:getComputedStyle(el).flex}))}));
  12 |  await testInfo.attach('layout',{body:JSON.stringify(layout,null,2),contentType:'application/json'});
  13 |  expect(layout.height).toBe(48);
  14 |  expect(await barLayout(page)).toEqual({oneLine:true,twelve:true,label:true,overlaps:[],inside:true,noScroll:true,title:true});
  15 |  await expect(page.locator('[data-action="twin-inspector-toggle"]')).toHaveAccessibleName('Chi tiết');
  16 |  await page.getByTestId('scenario-picker').focus();await page.keyboard.press('Tab');await expect(page.getByTestId('runtime-chip')).toBeFocused();
  17 |  for(const locale of ['vi','ja','en'])for(const state of ['live','connecting','failed','lost']){
  18 |   await page.evaluate(async({locale,state})=>{
  19 |    const module='/src/ui/run-bar.ts',i18n='/src/i18n/index.ts',m=await import(module),{setLocale,tr}=await import(i18n);setLocale(locale);
  20 |    const runtime=m.runtimeWord(state==='connecting'?'connecting':state==='lost'?'runtime_lost':'live','fresh',true,false,false,{attempt:state==='failed'?'failed':'ok',pinMismatch:false});
  21 |    document.querySelector('#twin-run-bar')!.outerHTML=m.runBar({scenarioTitle:tr('Cà phê sữa đá','アイスミルクコーヒー','Iced milk coffee'),runtime:{...runtime,detail:''},mode:m.simLabel('mock',false),status:tr('Cần kiểm tra','要確認','Needs attention'),simTimeS:4.2,served:'0',problems:1,primary:{action:'twin-resume',label:tr('Tiếp tục','再開','Resume'),disabled:false},inspectorOpen:false});
  22 |   },{locale,state});
  23 |   const detail=await page.locator('#twin-run-bar').evaluate(el=>({height:el.getBoundingClientRect().height,chipFits:el.querySelector('#twin-runtime-word')!.scrollWidth<=el.querySelector('#twin-runtime-word')!.clientWidth,buttons:[...el.querySelectorAll('button')].map(b=>({text:b.textContent,width:b.getBoundingClientRect().width,height:b.getBoundingClientRect().height}))}));
  24 |   await testInfo.attach(`${locale}-${state}`,{body:JSON.stringify(detail),contentType:'application/json'});
> 25 |   expect(detail.height,`${locale} ${state}`).toBe(48);expect(detail.chipFits).toBe(true);for(const b of detail.buttons){expect(b.width).toBeGreaterThanOrEqual(44);expect(b.height).toBeGreaterThanOrEqual(44);}
     |                                              ^ Error: vi failed
  26 |   expect(await barLayout(page),`${locale} ${state}`).toEqual({oneLine:true,twelve:true,label:true,overlaps:[],inside:true,noScroll:true,title:true});
  27 |  }
  28 | 
  29 | });
  30 | 
```