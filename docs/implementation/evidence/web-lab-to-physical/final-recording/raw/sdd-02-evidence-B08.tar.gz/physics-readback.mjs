import {cp,mkdir,readFile,readdir,writeFile} from 'node:fs/promises';import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {tsImport} from '/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/source/node_modules/tsx/dist/esm/api/index.mjs';
const base='/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/source';
const {comparePhysicsRuns}=await tsImport(base+'/packages/lab-runtime/src/v2/simulation3d/physics-comparison.ts',import.meta.url);
const sha=b=>createHash('sha256').update(b).digest('hex');
const original='/tmp/mekoniq-b04a-final-681b8ad-20261114-0954',out='/tmp/mekoniq-b08-b04a-verified-copy-20261115-0100';await mkdir(out);
const ids=['turn-empty-s7','turn-center-s7','turn-offset-s7','friction-low','friction-high','brake-slow','brake-fast'];
await cp(join(original,'engineering'),join(out,'engineering'),{recursive:true,errorOnExist:true});
const runs={};
for(const id of ids){const d=join(out,id);await cp(join(original,id),d,{recursive:true,errorOnExist:true});const record=JSON.parse(await readFile(join(d,'case.json'),'utf8'));for(const ref of record.artifacts){const b=await readFile(join(d,ref.path));if(b.length!==ref.bytes||sha(b)!==ref.sha256)throw Error('ARCHIVE_COPY_HASH_MISMATCH:'+id+':'+ref.path);}const report=await readFile(join(d,'report.json'),'utf8'),artifacts=[];
 const parsedReport=JSON.parse(report),manifest=JSON.parse(await readFile(join(out,'engineering/bundles',parsedReport.manifest.engineering.bundleDigest,'manifest.json'),'utf8'));for(const f of manifest.files){const b=await readFile(join(out,'engineering/blobs',f.sha256));if(b.length!==f.sizeBytes||sha(b)!==f.sha256)throw Error('COMPILED_CLOSURE_HASH_MISMATCH');artifacts.push({ref:{path:f.path,bytes:b.length,sha256:sha(b)},content:b.toString()});}
 for(const kind of ['evidence','physics'])for(const p of await readdir(join(d,'run',kind))){if(!p.endsWith('.gz')&&!p.endsWith('.json'))continue;const b=await readFile(join(d,'run',kind,p));artifacts.push({ref:{path:kind+'/'+p,bytes:b.length,sha256:sha(b)},...p.endsWith('.gz')?{encoding:'base64',content:b.toString('base64')}:{content:b.toString()}});}
 runs[id]={report:{ref:{path:'report.json',sha256:sha(report),bytes:Buffer.byteLength(report)},content:report},artifacts};}
const results={};for(const [a,b]of [['turn-empty-s7','turn-center-s7'],['turn-center-s7','turn-offset-s7'],['turn-center-s7','friction-low'],['turn-center-s7','friction-high'],['friction-low','friction-high'],['brake-slow','brake-fast']]){const comparison=comparePhysicsRuns(runs[a],runs[b]);results[a+'__'+b]=comparison;console.log(a,b,comparison.comparable,comparison.reasons);}
await writeFile(join(out,'comparison-results.json'),JSON.stringify({accepted:false,recordedSource:'681b8adb8ed473f7195062773b23fabc3b922cd5',original,copyVerified:true,results},null,2)+'\n',{flag:'wx'});
