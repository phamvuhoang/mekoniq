# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mujoco-cell.spec.ts >> cell starts at tick zero, explicit 1×, exact admitted moving world, known pause/resume and registered new-run choices
- Location: tests/e2e/mujoco-cell.spec.ts:12:1

# Error details

```
Test timeout of 120000ms exceeded.
```

```
Error: locator.click: Test timeout of 120000ms exceeded.
Call log:
  - waiting for locator('.replay-files>summary')

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to workspace" [ref=e3] [cursor=pointer]:
    - /url: "#workspace"
  - banner [ref=e4]:
    - link "MEKONIQ Robot Lab" [ref=e5] [cursor=pointer]:
      - /url: "#design"
      - generic [ref=e6]: ROBOT LAB
    - generic [ref=e7]:
      - text: Restaurant project
      - generic [ref=e10]: R01
    - generic [ref=e11]:
      - generic [ref=e12]: PREVIEW
      - generic "Language" [ref=e14]:
        - button "VI" [ref=e15] [cursor=pointer]
        - button "JA" [ref=e16] [cursor=pointer]
        - button "EN" [pressed] [ref=e17] [cursor=pointer]
      - link "Business plan ↗" [ref=e18] [cursor=pointer]:
        - /url: /business-plan.html
  - generic [ref=e19]:
    - complementary [ref=e20]:
      - generic [ref=e21]: WORKSPACE
      - navigation "Main navigation" [ref=e22]:
        - link "Design" [ref=e23] [cursor=pointer]:
          - /url: "#design"
          - generic [aria-hidden] [ref=e27]: "01"
        - link "Assembly" [ref=e28] [cursor=pointer]:
          - /url: "#assembly"
          - generic [aria-hidden] [ref=e32]: "02"
        - link "Restaurant" [ref=e33] [cursor=pointer]:
          - /url: "#restaurant"
          - generic [aria-hidden] [ref=e37]: "03"
        - link "Scenarios" [ref=e38] [cursor=pointer]:
          - /url: "#scenarios"
          - generic [aria-hidden] [ref=e42]: "04"
        - link "Digital twin" [ref=e43] [cursor=pointer]:
          - /url: "#twin"
          - generic [aria-hidden] [ref=e47]: "05"
        - link "Results" [ref=e48] [cursor=pointer]:
          - /url: "#results"
          - generic [aria-hidden] [ref=e53]: "06"
        - link "Deployment" [ref=e54] [cursor=pointer]:
          - /url: "#deployment"
          - generic [aria-hidden] [ref=e58]: "07"
      - generic [ref=e59]:
        - generic [ref=e60]: MEKONIQ ENGINEERING LAB
        - paragraph [ref=e65]: From concept to service.
        - generic [ref=e66]:
          - text: LAB v0.1
          - generic [ref=e68]: R0
    - main [ref=e69]:
      - heading "Digital twin" [level=1] [ref=e70]
      - generic [ref=e71]:
        - region "Run" [ref=e72]:
          - generic [ref=e73]:
            - button "Scenario" [ref=e74] [cursor=pointer]:
              - generic [ref=e75]:
                - generic [ref=e76]: Scenario
                - generic [ref=e77]: Coffee delivery · simulated physical cell
            - 'button "Runtime: Live" [ref=e80] [cursor=pointer]':
              - generic [ref=e82]: "Runtime:"
              - generic [ref=e83]: Live
            - button "Simulation · not calibrated" [ref=e84] [cursor=pointer]
          - generic [ref=e89]:
            - generic [ref=e90]:
              - generic [ref=e91]: Status
              - generic [ref=e92]: Running
            - generic [ref=e93]:
              - generic [ref=e94]: Sim time
              - generic [ref=e95]: 0.1 s
            - generic [ref=e96]:
              - generic [ref=e97]: Served
              - generic [ref=e98]: "0"
            - button "Keep running" [ref=e99] [cursor=pointer]
            - button "Details" [expanded] [ref=e100] [cursor=pointer]
        - generic [ref=e104]:
          - link "Explore recording" [ref=e105] [cursor=pointer]:
            - /url: /#replay/coffee-delivery
          - button "Export replay" [ref=e106] [cursor=pointer]
          - button "Follow phases" [ref=e107] [cursor=pointer]
          - generic "Source snapshot tick 7" [ref=e108]: Waiting H7 · r2 · 0 ms
          - button "Overview" [ref=e109] [cursor=pointer]
          - button "Cell" [ref=e110] [cursor=pointer]
          - button "Follow AMR" [ref=e111] [cursor=pointer]
        - generic [ref=e112]:
          - region "Viewport" [ref=e113]:
            - generic "3D twin view. Use the entity list to select objects." [ref=e115]
            - generic [ref=e116]:
              - 'button "Reset the camera (arm scenarios: the arm cell)" [ref=e117] [cursor=pointer]'
              - 'button "Fit the selected object (none: the whole floor)" [ref=e120] [cursor=pointer]'
              - button "Watch mode" [ref=e123] [cursor=pointer]
              - button "Keyboard shortcuts" [ref=e127] [cursor=pointer]
              - button "Display" [ref=e131] [cursor=pointer]
            - status [ref=e134]:
              - generic [ref=e138]: Immutable snapshot exported; extract the ZIP and import it in Explore recordings.
              - button "Dismiss" [ref=e139] [cursor=pointer]
          - complementary "Details" [ref=e142]:
            - tablist "Details" [ref=e143]:
              - tab "Objects" [ref=e144] [cursor=pointer]
              - tab "Engineering" [ref=e145] [cursor=pointer]
              - tab "Report" [ref=e146] [cursor=pointer]
              - tab "Setup" [selected] [ref=e147] [cursor=pointer]
            - tabpanel "Setup" [ref=e148]:
              - paragraph [ref=e149]: Stop and continue handling · Pause/resume requires a known Source state. Unknown outcomes require reconciliation or a new run; commands are not resent.
              - text: Try one change · new run
              - combobox "Try one change · new run" [ref=e150]:
                - option "Coffee delivery" [selected]
                - option "Cup falls after an impact"
                - option "Dock drift after an impact"
              - paragraph [ref=e151]: "Registered impact: cup [30,0,30] N for 10 substeps during transport; dock 2000 N map X for 10 substeps before release. Changed inputs create a new run."
              - generic [ref=e152]:
                - text: Environment for new run
                - combobox "Environment for new run" [ref=e153]:
                  - option "mock-default · mock"
                  - option "mock-amr · mock"
                  - option "simulation-default · simulation"
                  - option "coffee-simulation · simulation"
                  - option "engineering-rigid-v1 · simulation"
                  - option "engineering-contact-v1 · simulation"
                  - 'option "engineering-irsim-2d-v1 · simulation · unavailable: BACKEND_NOT_INSTALLED:irsim_2d (IRSIM_DISABLED: the portable IR-SIM provider is not enabled (MEKONIQ_LAB_IRSIM=1)), CAPABILITY_MISSING:irsim_navigation_v1" [disabled]'
                  - 'option "engineering-webots-3d-v1 · simulation · unavailable: BACKEND_NOT_INSTALLED:webots_3d (WEBOTS_DISABLED: the Webots 3D provider is not configured on this runtime (MEKONIQ_LAB_WEBOTS=1)), CAPABILITY_MISSING:sim3d_navigation_v1" [disabled]'
                  - 'option "engineering-webots-arm-v1 · simulation · unavailable: BACKEND_NOT_INSTALLED:webots_arm (WEBOTS_DISABLED: the Webots arm provider is not configured on this runtime (MEKONIQ_LAB_WEBOTS=1)), CAPABILITY_MISSING:sim3d_arm_v1" [disabled]'
                  - option "engineering-mujoco-arm-v1 · simulation"
                  - option "engineering-mujoco-cell-v1 · simulation" [selected]
                  - option "engineering-mujoco-3d-v1 · simulation"
              - generic [ref=e154]:
                - button "Run with edited inputs" [ref=e155] [cursor=pointer]
                - button "Reset (new run)" [ref=e156] [cursor=pointer]
                - button "Reopen for view/reconcile · 25d06aec" [ref=e159] [cursor=pointer]
        - group "Run controls" [ref=e160]:
          - button "Auto-run" [ref=e161] [cursor=pointer]
          - button "+5 s" [ref=e165] [cursor=pointer]
          - button "Pause simulation" [ref=e169] [cursor=pointer]
          - generic [ref=e173]:
            - generic [ref=e174]: Run speed
            - combobox "Run speed" [ref=e175]:
              - option "1×" [selected]
              - option "4×"
              - option "16×"
              - option "64×"
          - generic [ref=e177]: 0.1 s · tick 7
          - button "Cancel run" [ref=e178] [cursor=pointer]
        - paragraph [ref=e182]: Cup / tray · tick 7 · Unavailable
```

# Test source

```ts
  1  | // Real shared world only; launch via test:mujoco-e2e -- --mujoco-mobile. No protocol double.
  2  | import {execFileSync} from 'node:child_process';
  3  | import {mkdirSync,readFileSync,writeFileSync,mkdtempSync} from 'node:fs';
  4  | import {join} from 'node:path';
  5  | import {createHash} from 'node:crypto';
  6  | import {test,expect} from '@playwright/test';
  7  | import {openScenarioPicker,openInspector} from '../support/twin';
  8  | const caseId='WEB-CELL-LIVE-REPLAY-390-v1',invocationId=process.env.LAB_BROWSER_INVOCATION;
  9  | let capturedRunId='',caseStartedAt=0;
  10 | test.afterEach(async({},info)=>{if(out&&invocationId)writeFileSync(join(out,'browser-case.json'),JSON.stringify({invocationId,caseId,testId:info.testId,runId:capturedRunId,title:info.title,file:'mujoco-cell.spec.ts',status:info.status,expectedStatus:info.expectedStatus,retry:info.retry,startedAtEpochMs:caseStartedAt,finishedAtEpochMs:Date.now()},null,2));});
  11 | const token=process.env.LAB_TEST_PAIRING_TOKEN,out=process.env.LAB_B07B_EVIDENCE;
  12 | test('cell starts at tick zero, explicit 1×, exact admitted moving world, known pause/resume and registered new-run choices',async({page},info)=>{
  13 |  caseStartedAt=Date.now();if(invocationId){expect(out).toBeTruthy();const invocation=JSON.parse(readFileSync(join(out!,'browser-invocation.json'),'utf8'));expect(invocation.invocationId).toBe(invocationId);}
  14 |  test.setTimeout(120000);expect(token).toBeTruthy();await page.setViewportSize({width:1440,height:900});const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('/#twin');await page.getByRole('button',{name:'EN',exact:true}).click();await page.locator('#twin-pair-token').fill(token!);const paired=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/lab/v2/sessions'));await page.locator('#twin-pair-form button[type="submit"]').click();const csrf=(await(await paired).json()).csrfToken;await openScenarioPicker(page);await page.locator('[data-action="twin-preset"][data-value="mujoco-cell"]').click();await openInspector(page,'setup');await expect(page.locator('#twin-world-experiment')).toHaveValue('world-nominal-v1');await page.locator('#twin-world-experiment').selectOption('world-cup-fall-v1');await expect(page.locator('#twin-world-experiment')).toHaveValue('world-cup-fall-v1');await page.locator('#twin-world-experiment').selectOption('world-nominal-v1');await expect(page.locator('[data-action="twin-run"]').first()).toBeEnabled({timeout:60000});
  15 |  const created=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/lab/v2/runs'));await page.locator('[data-action="twin-run"]').first().click();const response=await created,body=response.request().postDataJSON(),run=await response.json();capturedRunId=run.run.id;expect(body.worldExperimentId).toBe('world-nominal-v1');await expect(page.locator('#twin-transport-time')).toContainText('tick 0');await expect(page.locator('#twin-run-speed')).toHaveValue('1');const canvas=page.locator('#twin-stage canvas');await expect(canvas).toHaveAttribute('data-arm-supports','1',{timeout:30000});
  16 |  const seven=await page.evaluate(async({id,csrf})=>{const v=await(await fetch(`/lab/v2/runs/${id}`)).json(),r=await fetch(`/lab/v2/runs/${id}/actions`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({actionId:crypto.randomUUID(),expectedRevision:v.run.runRevision,kind:'step',payload:{ticks:7,pace:{factor:1}}})});return {status:r.status,view:await r.json()};},{id:run.run.id,csrf});expect(seven.status).toBe(200);expect(seven.view.tick).toBe(7);await expect(page.locator('#twin-transport-time')).toContainText('tick 7');
  17 |  const evidence=out??mkdtempSync('/tmp/b07b-browser-h7-'),zipPath=join(evidence,'live-H7.zip'),folder=join(evidence,'live-H7');mkdirSync(folder,{recursive:true});const downloaded=page.waitForEvent('download');await page.locator('[data-action="twin-world-export"]').click();await(await downloaded).saveAs(zipPath);execFileSync('unzip',['-q',zipPath,'-d',folder]);const manifest=JSON.parse(readFileSync(join(folder,'manifest.json'),'utf8'));expect(manifest.horizon.tick).toBe(7);writeFileSync(join(evidence,'live-H7-identity.json'),JSON.stringify({runId:run.run.id,tick:7,manifestSha256:createHash('sha256').update(readFileSync(join(folder,'manifest.json'))).digest('hex'),accepted:false},null,2));
> 18 |  const offline=await page.context().newPage();const attempts:string[]=[];await offline.route('**/lab/**',r=>{attempts.push(r.request().url());return r.abort();});await offline.goto('/#replay');await offline.locator('.replay-files>summary').click();await offline.locator('#replay-import').setInputFiles(folder);await expect(offline.locator('#replay-cursor')).toHaveAttribute('max','7',{timeout:45000});await expect(offline.locator('#replay-cursor')).toHaveAttribute('step','1');await offline.locator('#replay-cursor').focus();await offline.keyboard.press('End');await expect(offline.locator('#replay-cursor')).toHaveValue('7');await expect(offline.locator('#replay-stage canvas')).toHaveAttribute('data-world-tick','7');expect(attempts).toEqual([]);await offline.locator('.replay-files>summary').click();await offline.selectOption('#replay-camera','cell');await expect(offline.locator('#replay-time')).toContainText('tick 7/7');await offline.waitForTimeout(250);if(out)await offline.screenshot({path:join(out,'offline-real-H7-terminal.png')});await offline.close();await page.bringToFront();
     |                                                                                                                                                                                                                                                 ^ Error: locator.click: Test timeout of 120000ms exceeded.
  19 |  // Both existing Report-tab replay entries use actual H7 reports; held network routes are deterministic isolation evidence, not timing qualification.
  20 |  const reportURL=`**/lab/v2/runs/${run.run.id}/report`;let reportGets=0;page.on('request',r=>{if(r.method()==='GET'&&r.url().endsWith(`/runs/${run.run.id}/report`))reportGets++;});
  21 |  await page.locator('#transport-twin-pause').click();await expect(page.locator('[data-testid="primary-action"][data-action="twin-resume"]')).toBeEnabled();await openInspector(page,'report');await expect(page.getByTestId('report-captured-horizon')).toContainText('tick 7');await expect(canvas).toHaveAttribute('data-world-tick','7');
  22 |  const matchingReportGets=reportGets;await page.locator('[data-action="twin-replay"]').click();await expect(page.locator('#twin-replay-cursor')).toHaveValue('0');await expect(page.locator('#twin-replay-cursor')).toHaveAttribute('step','1');await expect(page.getByTestId('cell-report-world-unavailable')).toContainText('WORLD_NOT_RECORDED_IN_REPORT');await expect(canvas).toHaveAttribute('data-world-tick','');await page.waitForTimeout(550);await expect(page.locator('#twin-transport-time')).toContainText('tick 0');await expect(canvas).toHaveAttribute('data-world-tick','');expect(reportGets).toBe(matchingReportGets);await page.locator('#twin-replay-cursor').focus();await page.keyboard.press('End');await expect(page.locator('#twin-transport-time')).toContainText('tick 7');if(out)await page.screenshot({path:join(out,'report-replay-matching-H7-unavailable.png')});await page.locator('[data-action="twin-replay-exit"]').click();await expect(canvas).toHaveAttribute('data-world-tick','7');
  23 |  await page.locator('#transport-twin-resume').click();await expect(page.locator('[data-testid="primary-action"][data-action="twin-play"]')).toBeEnabled();await expect(page.getByTestId('report-captured-horizon')).toContainText('tick 7');
  24 |  let holdReports=true;const heldReports:import('@playwright/test').Route[]=[],holdReport=async(route:import('@playwright/test').Route)=>{if(holdReports){heldReports.push(route);return;}await route.continue();};await page.route(reportURL,holdReport);
  25 |  try{const pause=await page.evaluate(async({id,csrf})=>{const v=await(await fetch(`/lab/v2/runs/${id}`)).json(),r=await fetch(`/lab/v2/runs/${id}/actions`,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({actionId:crypto.randomUUID(),expectedRevision:v.run.runRevision,kind:'pause',payload:{}})});return {status:r.status,view:await r.json()};},{id:run.run.id,csrf});expect(pause.status).toBe(200);expect(pause.view.tick).toBe(7);await expect(page.locator('[data-testid="primary-action"][data-action="twin-resume"]')).toBeEnabled();await page.locator('[data-action="twin-replay"]').click();await expect.poll(()=>heldReports.length).toBeGreaterThan(0);await expect(page.getByTestId('cell-report-world-unavailable')).toBeVisible();await expect(canvas).toHaveAttribute('data-world-tick','');holdReports=false;await Promise.all(heldReports.splice(0).map(r=>r.continue()));await expect(page.locator('#twin-replay-cursor')).toHaveValue('0');await page.waitForTimeout(550);await expect(page.locator('#twin-transport-time')).toContainText('tick 0');await expect(canvas).toHaveAttribute('data-world-tick','');if(out)await page.screenshot({path:join(out,'report-replay-fetched-cursor0-unavailable.png')});await page.setViewportSize({width:390,height:900});expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);await expect(page.getByTestId('cell-report-world-unavailable')).toBeVisible();if(out){const imageStartedAtEpochMs=Date.now();const dom=await page.evaluate(()=>({atEpochMs:performance.timeOrigin+performance.now(),topbarCount:document.querySelectorAll('header.topbar').length,headers:[...document.querySelectorAll('header')].map(h=>({className:h.className,text:h.textContent,rect:h.getBoundingClientRect().toJSON()})),viewport:{width:innerWidth,height:innerHeight},html:document.documentElement.outerHTML}));const identity={invocationId,caseId,testId:info.testId,runId:run.run.id},domBytes=Buffer.from(JSON.stringify({...dom,...identity,flow:'live-report-replay',runtimeIdentity:body.runtimeIdentity},null,2));writeFileSync(join(out,'report-replay-fetched-cursor0-390-dom.json'),domBytes);const png=await page.screenshot({path:join(out,'report-replay-fetched-cursor0-390.png'),scale:'css'});writeFileSync(join(out,'report-replay-fetched-cursor0-390-image.json'),JSON.stringify({...identity,startedAtEpochMs:imageStartedAtEpochMs,finishedAtEpochMs:Date.now(),domSha256:createHash('sha256').update(domBytes).digest('hex'),sha256:createHash('sha256').update(png).digest('hex'),bytes:png.length},null,2));expect(dom.topbarCount).toBe(1);}await page.setViewportSize({width:1440,height:900});}
  26 |  finally{holdReports=false;await Promise.all(heldReports.splice(0).map(r=>r.continue().catch(()=>{})));await page.unroute(reportURL,holdReport);}
  27 |  await page.locator('[data-action="twin-replay-exit"]').click();await expect(canvas).toHaveAttribute('data-world-tick','7');await page.locator('#transport-twin-resume').click();await expect(page.locator('[data-testid="primary-action"][data-action="twin-play"]')).toBeEnabled();
  28 | 
  29 |  await page.locator('[data-action="twin-play"]').first().click();await expect.poll(async()=>{const r=await page.evaluate(async id=>(await(await fetch(`/lab/v2/runs/${id}/world-display`)).json()),run.run.id);return r.tick;},{timeout:30000}).toBeGreaterThan(10);await page.locator('[data-action="twin-pause"]').first().click();await expect(page.locator('[data-action="twin-resume"]').first()).toBeEnabled();const paused=await page.evaluate(async id=>(await(await fetch(`/lab/v2/runs/${id}/world-display`)).json()),run.run.id);expect(paused.snapshot.tick).toBe(paused.tick);expect(paused.control.targetTick).toBe(paused.tick);await page.waitForTimeout(300);expect((await page.evaluate(async id=>(await(await fetch(`/lab/v2/runs/${id}/world-display`)).json()),run.run.id)).tick).toBe(paused.tick);for(const language of ['VI','JA','EN']){await page.getByRole('button',{name:language,exact:true}).click();for(const width of [390,1024,1440]){await page.setViewportSize({width,height:900});await page.waitForTimeout(100);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1)).toBe(true);if(width===390){const box=await canvas.boundingBox();expect(box!.y).toBeLessThan(460);expect(box!.height).toBeGreaterThan(300);await expect(page.locator('[data-action="twin-resume"]').first()).toBeInViewport();}await page.waitForTimeout(200);if(out)await page.screenshot({path:`${out}/live-${language}-${width}.png`});}}await page.setViewportSize({width:1440,height:900});await page.locator('[data-action="twin-resume"]').first().click();await expect(page.locator('[data-action="twin-play"]').first()).toBeEnabled();if(out)await page.screenshot({path:`${out}/cell-live-paused-resumed.png`});await openInspector(page,'setup');await page.locator('#twin-world-experiment').selectOption('world-cup-fall-v1');const fresh=page.waitForResponse(r=>r.request().method()==='POST'&&r.url().endsWith('/lab/v2/runs'));await page.locator('[data-action="twin-run"]').first().click();const second=await fresh,newRun=await second.json();expect(second.request().postDataJSON().worldExperimentId).toBe('world-cup-fall-v1');expect(newRun.run.id).not.toBe(run.run.id);await expect(page.locator('#twin-transport-time')).toContainText('tick 0');await expect(canvas).toHaveAttribute('data-arm-supports','1');if(out)await page.screenshot({path:`${out}/cell-new-impact-trial-tick0.png`});expect(errors).toEqual([]);
  30 | });
  31 | 
```