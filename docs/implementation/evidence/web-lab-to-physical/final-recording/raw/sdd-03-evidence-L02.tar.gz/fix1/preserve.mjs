import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const base='.superpowers/sdd/03-r3-linux-readiness/',sha=b=>createHash('sha256').update(b).digest('hex');
const index=JSON.parse(readFileSync(base+'root-L02-evidence-file-index.json'));
for(const f of index.files){const b=readFileSync(index.root+'/'+f.path);if(b.length!==f.bytes||sha(b)!==f.sha256)throw Error('Modified historical evidence '+f.path);}
const before=readFileSync(base+'evidence-L02/fix1/pre-fix1-report.md'),report=readFileSync(base+'task-L02-report.md');
if(before.length!==25692||sha(before)!=='6fd0359cda1e0a09b24ecd73deb8fc2ac57bf1b40f7ad876ee400a123ac1e1c1'||!report.subarray(0,before.length).equals(before))throw Error('Report prefix changed');
for(const file of ['scripts/lab-sil.mjs','robotics/simulation/fixtures/engineering-navigation-v1/compiler-manifest.json','robotics/simulation/fixtures/engineering-navigation-v1/native-mapping.json','robotics/simulation/profiles/engineering-amd64.lock.json','robotics/simulation/profiles/engineering-arm64.lock.json']){
 const old=spawnSync('git',['show','e6db696b2ac1266fdeede8c2a64521cd4064481a:'+file],{timeout:10000});if(old.status!==0||!old.stdout.equals(readFileSync(file)))throw Error('Unexpected change '+file);
}
console.log(JSON.stringify({historicalEvidenceFiles:index.files.length,reportPrefixBytes:before.length,reportPrefixSha256:sha(before),originalCliCompilerManifestsAndLocksUnchanged:true,accepted:false}));
