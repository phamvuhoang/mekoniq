# L02 implementation report

Status: **DONE_WITH_CONCERNS — executable native preparation complete; native qualification not_run.**

The separate canonical engineering FD01 Gazebo/Nav2 path is implemented and committed. Portable compiler/readback, protocol, prerequisite, clock, evidence and handoff regressions pass. No Linux native host was assigned. No ROS/Gazebo process, native nominal/fault campaign, native SDF conversion, native bag capture, hardware or commissioning was executed. All new native case records remain `accepted:false`, `not_calibrated`, `not_run/blocked_external`. Neither G-NATIVE-AMR nor DEP-NAV-01–04/SEC-01 is closed.

## Scope and identities

All mutations were in the assigned feature worktrees, both `codex/web-lab-to-physical`:

- Source base: `874d05aedfbf573496994fd73016f19ef19e6932`.
- Lab base: `4a207b43c613cf0c1226a9ff3c1990a96ec5ac08`.
- Source final: **`e6db696b2ac1266fdeede8c2a64521cd4064481a`**, `feat: prepare canonical engineering Gazebo lifecycle`.
- Lab final: **`7652851fb9e92e560c70e4e6675b85fa5f445cf4`**, `chore: pin source runtime e6db696`.
- Runtime artifact SHA-256: `89686e9595476379e12b980caccb714d7f0d7fab6560ddd45bf18b5d88ed360d`.
- Schema hash: `07e01e8efb146fb50b8c68eebfa27d989ee07d4e80bcdb796639e3c2aaa42068`.
- Native tool closure: `6643ae338a7b3ee2e03c5659cbed5e962ae346d01746c1aaabd0ef912f61140f`.
- Portable tool closure: `5c58ddfacb92fc52adc7106cbe03f2758a9dd6ee23f4d64686e33803757774d3`.
- Native compiler-manifest file SHA-256: `03e5eb26079b0b849b148293364dd35eb73d96265364edc569161a892605277b`.
- Clean export: `/tmp/l02-runtime-e6db696-20261115`, `manifest.json` has `dirty:false`.
- Both worktrees were clean after commits and native preflight recording; see `evidence-L02/identities.json`.

The checker identity here means the committed local portable tests and Mac preflight code, not an independent native qualification or host attestation. The final tests cover the implementation tree committed in `e6db696`; the final interpreter-default test adjustment has its own covering `final-factory.log`, and the final not_run manifest identity fields are script-only changes covered by syntax/lint plus the subsequent actual preflight runs. No claim is made that a later Git check audited an already-cached helper import graph. L01's historical checker/probe/subject interfaces were not repurposed.

R85 explicitly authorizes the exact L00 canonical project/scene/model. The older `tests/fixtures/engineering/fd01.project.json` command example is superseded **only for this new native mapping**. Existing legacy/non-native compiler behavior remains covered by its original integration tests. The canonical project's `requestedProfile: engineering-webots-3d-v1` and portable navigation scene engine stay unchanged as source provenance; `native-mapping.json` separately binds target `engineering-rigid-v1` and the engineering environment profiles. There is no general profile-ignore policy.

## Implementation and API

### Compiler and static handoff

`robotics/simulation/compiler/engineering_native.py` accepts exactly the canonical EngineeringProject, NavigationSceneV1 and RobotPhysicalModelV1 from `robotics/simulation-3d/fixtures/serve-3d-v1/`. It emits a distinct native mapping, URDF, gz_ros2_control configuration, world, occupancy map, target bindings, scene index and hashed compiler manifest. It preserves SI link/joint names, inertias, masses, collision shapes, wheel dimensions, sensor parent frame/rate/range/beam count, canonical spawn and semantic target bindings. Friction and all physical parameters remain assumed; ideal velocity actuation is declared.

`robotics/simulation/fixtures/engineering-navigation-v1/{compiler-manifest,native-mapping}.json` are the frozen reproducible native output identities. Portable tests compare freshly compiled bytes against them. The original `compiler/engineering.py` was intentionally left unchanged so existing description and portable compiler bytes retain their old behavior.

`bridge/engineering_launch.py` checks all listed bytes and canonical manifest identity, then independently recompiles into a temporary directory and compares the full manifest. A merely resealed altered plugin/robot is rejected. TypeScript `readEngineeringCompiledWorld()` also checks the frozen manifest, every listed artifact and the original canonical documents.

`native-handoff-documents.ts` recognizes the exact attached native manifest/mapping. Missing mapping remains `NATIVE_ENGINE_MAPPING_UNRESOLVED`; missing manifest outputs become `NATIVE_ARTIFACT_CLOSURE_MISSING`; unresolved/wrong engineering native profile remains `NATIVE_ENGINE_PROFILE_UNRESOLVED`. Adding a factory or mapping does not set nativeReady. Existing OCI/native_apt discrimination and the old unresolved preparation behavior pass handoff unit/security regressions.

### Factory, Source lifecycle and time

`packages/lab-runtime/src/v2/sil/engineering-native.ts` adds `engineeringNativeProviderFactory({bundleDirectory,environmentProfile,simulationRoot,python?,nativeCase?})`. The factory consumes a compiled bundle plus server options, returns the existing GazeboBackend command/observation contract, and owns a latched `EngineeringClock`, fault receipt and evidence finalization. It admits only FD01, engineering-rigid-v1, an engineering-amd64/arm64 environment profile, and the canonical runtime project.

`cli.ts`, `campaign.ts` and `scripts/lab-sil.mjs` route this path separately. Source's existing FD01 journal/dispatcher/confirmation logic remains authoritative; engineering iterations are paced by actual provider-clock changes and Source timestamps use the resulting 20 ms logical tick. Clock mapping records `providerSimNs`, `sourceTick`, and `receiveMonotonicNs`. Reset, stale feedback and wall deadline stop progress with explicit attention. Legacy BV01 `nativeProviderFactory/createNativeScenarioRun` and engineering-contact refusal remain intact; this does not implement xArm/MoveIt motion, which belongs to L03.

`gazebo-nav2.ts` selects the engineering entrypoint only with an explicit matching environment profile; an engineering selection without that profile cannot fall through to the legacy worker. The engineering worker runs in an owned detached process group; worker exit kills that owned group. Native command receipts preserve unknown/no-resend behavior and an existing worker state directory is refused.

### Prepared ROS/Gazebo path

`launch/engineering_world.launch.py` starts the canonical Gazebo world paused, robot_state_publisher, model spawn, joint-state/diff-drive controller spawners, fixed bridge topics and the existing navigation launch with compiled frames/footprint/initial pose. There is one ros2_control velocity writer per drive joint; no parallel Gazebo DiffDrive writer. The worker stamps Nav2 Twist commands for the Jazzy controller's TwistStamped input.

`bridge/engineering_session.py` uses the existing Nav2 durable goal protocol, adds strict readiness/freshness checks and a separate engineering command guard, leases an engineering ROS domain (101–200), refuses a nonempty graph, uses a run-specific GZ partition and localhost-only ROS transport. Startup advances the initially paused simulation so controllers/localization/sensors can initialize before business dispatch. It checks native process liveness, clock, navigation lifecycle/localization, TF paths, joint identities, scan/joint receipt and simulation timestamps. Cleanup targets the owned launch/recorder and the supervisor-owned process group. These ROS/process behaviors are implemented but not observed on a native host.

The fixed case allowlist is `nominal`, `obstacle`, `no-path`, `cancel`, `worker-loss`. Obstacle/no-path move only compiled dormant case fixtures; cancel follows the first accepted goal; worker-loss exits the owned worker after a retained fault event. No caller names an action, topic, executable, endpoint, launch argument or arbitrary world entity. Negative cases require observed fault evidence, Source attention, zero served/completed outcomes and no repeated effect attempts. Native geometry effectiveness and timing remain unverified until native execution.

### Profile and evidence readiness

`engineering_profile.py`, `native_profile.py` and `scripts/native-sim/profile-report.mjs` retain the generic consistency comparator and add stricter native prerequisites: actual installed dpkg versions, absolute plugin file digests, runtime executable/environment/overlay fingerprints and apt source provenance. Both architecture lock files remain untouched, with unresolved exact package/plugin locks and `qualification:not_run`. Installed consistency is not native-host authenticity; the separate L00 native_apt provenance requirements remain necessary.

The worker records rosbag2 with simulation timestamps and an explicit expected topic allowlist. Normal finalization retains byte-verified copies. Deliberate worker loss uses a read-only SQLite backup and checks a digest of message contents before retaining the recovered copy. Original runtime files are preserved; the artifact list references the verified `rosbag2/` copy. No SQLite was retained in the actual L02 evidence here: native execution never started, and portable SQLite test files remained temporary test data.

`bridge/engineering_bag.py` replays actual SQLite message timestamps, not metadata claims. `assessEngineeringEvidence()` requires every expected topic and continuous clock/TF/odom/joints/scan/pose/contact coverage, with a 500 ms maximum uncovered interval. Static TF and event-driven command/action/AMCL streams require presence. Empty, missing, partial or inconsistent evidence stays not_run. `verify-engineering` rereads the bag and canonical bundle, then reassesses negative cases against Source journal/effects and retained fault observations.

Artifacts include normalized native events (trajectory, contacts, joints, LiDAR, clock), durable native commands, actual inventory, shutdown record, bag files, Source journal/effects, telemetry and assertions. LiDAR nonfinite no-return ranges have an explicit null normalization policy. This is offline coverage replay; independent ROS replay and numerical/physical outcome qualification are not claimed.

## Validation and retained attempts

Evidence root (ignored task records, not a rewritten historical candidate):

`/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/source/.superpowers/sdd/03-r3-linux-readiness/evidence-L02/`

Portable logs are under `portable/`; the original working copies also remain under `/tmp/l02-checks/`. Node was 24.22.2 and pnpm 10.32.1. Portable Python tests used `.venv-irsim/bin/python` **3.11.15**, `PYTHONDONTWRITEBYTECODE=1`, and pytest `-p no:cacheprovider`. No portable root bytecode/cache was created by these tests.

| Evidence | Actual result |
| --- | --- |
| `portable/python-red.log` | 4 RED failures for absent native compiler/launch/clock APIs. |
| `portable/python-green1.log` | First compiler/readback/clock/tamper checks: 4 pass. |
| `portable/ts-red.log` / `ts-green1.log` | New native module absent (2 suite failures), then routing/clock/topic coverage: 4 pass. |
| `portable/python-red-resealed.log` | Resealed tampered native artifact was wrongly accepted: 1 fail, 5 pass before reproduction guard. |
| `portable/profile-red.log` / `python-green2.log` | Missing native prerequisite function: 1 fail, 7 pass; native profile + parity: 14 pass. |
| `portable/protocol-red.log` | Engineering protocol guard absent: 3 fail, 6 pass. |
| `portable/protocol-green1.log`, `protocol-green2.log` | Test-helper import path error, then missing rfc3339-validator dependency: each 3 fail, 6 pass. These were not native failures. |
| `portable/python-dependency.log` / `protocol-green3.log` | Installed rfc3339-validator 0.1.4 and six 1.17.0 in isolated `/tmp/l02-python311`; then 9 pass. Existing worker venvs and package locks were not changed. |
| `portable/handoff-red.log` / `handoff-green1.log` | Exact native handoff mapping still unresolved: 1 fail; after binding, 106 tests pass including existing handoff security/unit coverage. |
| `portable/fault-red.log` / `fault-green1.log` | Missing fixed fault mapping: 1 fail, 9 pass; then 10 pass. |
| `portable/fault-ts-red.log` | Negative-case assessment absent: 1 fail, 3 pass before implementation. |
| `portable/worker-routing-red.log` | Engineering helper without a profile fell through to legacy selection: 1 fail, 3 pass before explicit guard. |
| `portable/final-ts.log` | **127 tests passed in 7 files**, no skips. Exact command below. |
| `portable/final-python.log` | **74 tests passed**, no skips. Exact command below. |
| `portable/final-factory.log` | **4 tests passed** after the final test-only interpreter-default adjustment. On environments without compiler dependencies that single actual-compiler integration test is explicitly skipped/not_run, never a native pass. |
| `portable/final-typecheck.log` | Source typecheck passed. |
| `portable/contracts-check.log` | Generated contracts match schemas. |
| `portable/final-focused-lint2.log` | Changed TypeScript/JavaScript/test files lint passed (empty successful output). `git diff --check` passed. |
| `portable/lint-combined1.log` | **Full `pnpm lint` failed: 27 pre-existing errors in five historical evidence scripts.** No L02 changed file appears in the errors. Root independently verified these files are byte-identical to L02 base and upstream11d25b4; see root's `root-L02-historical-lint-audit.json`. B10 owns exact lint configuration follow-up; no historical evidence was rewritten or broadly suppressed. |
| `export.log` | Clean committed Source export, dirty:false. |
| `lab-import.log`, `lab-sync.log`, `lab-check-source.log`, `lab-typecheck.log` | Lab import, generated-contract sync, source verification and typecheck passed. |
| `native-not-run/doctor.json` and per-case logs/manifests | Actual Mac preflight denied native execution; all five cases not_run/blocked_external. |
| `native-not-run/verify-nominal.log` | Verifier printed NOT_RUN and preserved all prerequisite blockers. |

Final TypeScript command (bounded 180 s):

```sh
ENGINEERING_PYTHON="$PWD/.venv-irsim/bin/python" perl -e 'alarm 180; exec @ARGV' pnpm exec vitest run \
 tests/integration/engineering-native-lifecycle.test.ts \
 tests/integration/engineering-native-evidence.test.ts \
 tests/integration/engineering-profile-routing.test.ts \
 tests/integration/engineering-compiler.test.ts \
 tests/unit/native-handoff.test.ts tests/security/native-handoff.test.ts \
 tests/integration/lab-v2-native-profile.test.ts
```

Final Python command (bounded 180 s):

```sh
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=robotics/simulation:robotics/agent:/tmp/l02-python311/lib/python3.11/site-packages \
perl -e 'alarm 180; exec @ARGV' .venv-irsim/bin/python -m pytest -p no:cacheprovider -q \
 robotics/simulation/tests/test_engineering_native_parity.py \
 robotics/simulation/tests/test_engineering_compiler.py \
 robotics/simulation/tests/test_engineering_profile.py \
 robotics/simulation/tests/test_engineering_worker.py \
 robotics/simulation/tests/test_native_profile.py \
 robotics/simulation/tests/test_nav2_session.py
```

Additional development attempts preserved in tool history: `.venv-mujoco` and `.venv-webots` lacked PyYAML; `.venv-irsim` supplied compiler deps. No packages were installed in those environments. The first helper search used nonexistent requirements filenames and returned file-not-found. The direct ROS docs page was access-denied, so official Jazzy upstream source was used. Lab's initial pin commit omitted the two regenerated source-commit headers; the agent immediately amended its own new, unpushed commit to include them, yielding final7652851. The generated files had already passed typecheck before that commit.

No broad full Source build or entire repository test suite was run. Clean runtime export exercised bundling; focused combined coverage and source/Lab typechecks covered the changed seams. Root owns independent review.

## Actual native matrix after commit and pin

The doctor reported the actual host as Darwin arm64, with shell `python3` 3.15.2. That interpreter was used only for failed native preflight/inventory introspection; portable compiler/protocol tests used Python 3.11.15, and the prepared ROS path requires target-distro Python. Missing Linux/ROS/Gazebo/compiler dependencies and unresolved engineering-amd64 inventory blocked every native run before compilation/provider launch. The actual Mac report is not native inventory evidence.

| Requested case | Requested seeds/repeats | Actual native execution | Record |
| --- | --- | --- | --- |
| nominal | 17,18,19 / 3 | not_run, blocked_external | `native-not-run/nominal/run-manifest.json` |
| obstacle | 17 / 1 | not_run, blocked_external | `native-not-run/obstacle/run-manifest.json` |
| no-path | 17 / 1 | not_run, blocked_external | `native-not-run/no-path/run-manifest.json` |
| cancel | 17 / 1 | not_run, blocked_external | `native-not-run/cancel/run-manifest.json` |
| worker-loss | 17 / 1 | not_run, blocked_external | `native-not-run/worker-loss/run-manifest.json` |

All preflight commands exited2. `native-not-run/cases.json` indexes the actual records and doctor exit. Runtime inventory capture on a real host, exact apt package/plugin locks, clean native install/doctor, upstream/legacy smoke, actual SDF readback, three-seed native nominal execution, real obstacle/no-path/cancel/worker-loss outcomes, actual rosbag coverage and independent native replay remain **not_run**. No native engine mapping or plugin hash was invented to close those gates.

## Prepared command and API references

The committed runbook is `docs/operations/engineering-native-navigation.md`. Its canonical R85 command is:

```sh
node scripts/lab-sil.mjs doctor --backend gazebo_nav2 --environment-profile engineering-amd64 --json
perl -e 'alarm 1800; exec @ARGV' node scripts/lab-sil.mjs run \
 --scenario FD01 --seed 17 --repeat 3 --out "$native_evidence_dir" \
 --backend-set engineering-rigid-v1 --environment-profile engineering-amd64 \
 --engineering-project robotics/simulation-3d/fixtures/serve-3d-v1/serve-3d-project.json
node scripts/lab-sil.mjs verify --input "$native_evidence_dir"
```

Use a fresh output directory and one fixed `--engineering-case` for each fault run. No hardware or cloud route is enabled.

Official API references consulted (Jazzy/Harmonic, not installed-version qualification): [gz_ros2_control](https://control.ros.org/jazzy/doc/gz_ros2_control/doc/index.html), [diff_drive_controller](https://control.ros.org/jazzy/doc/ros2_controllers/diff_drive_controller/doc/userdoc.html), [rosbag2 record CLI source](https://github.com/ros2/rosbag2/blob/jazzy/ros2bag/ros2bag/verb/record.py), [rosbag2 recorder source](https://github.com/ros2/rosbag2/blob/jazzy/rosbag2_transport/src/rosbag2_transport/recorder.cpp), [TF listener source](https://github.com/ros2/geometry2/blob/jazzy/tf2_ros_py/tf2_ros/transform_listener.py), and [Nav2 parameter defaults](https://github.com/ros-navigation/navigation2/blob/jazzy/nav2_bringup/params/nav2_params.yaml). TF remapping was implemented on a separate node because Jazzy's listener constructor has no `tf_topic` keyword. Jazzy's controller input is TwistStamped, so the worker explicitly stamps Nav2 Twist output. No upstream source was vendored or unpinned package lock claimed.

## Self-review and remaining concerns

- Admission stays fail-closed: legacy fixture, noncanonical/resealed physical model, unsupported scenario/set/profile and altered native artifacts are rejected. The existing BV01/coffee/arm factory is not used for engineering FD01.
- Source owns business journal, commands and confirmations. Protocol tests cover failed/no-path/cancelled outcomes, stale TF/feedback, clock reset and lost ACK without resend; native process behavior itself is not claimed tested.
- Canonical input provenance is preserved independently of the native target mapping. Native profile/tool requirements are distinct from static compiler consistency. Both package/plugin lock files stay unresolved.
- Missing expected bag topics/time coverage, unobserved faults, replay attempts and false completion cannot become a passing prepared assessment. Candidate acceptance remains false regardless of a portable pass.
- Actual ROS/Gazebo startup, controller/TF behavior, clock/pacing under load, process-tree teardown, fault fixture placement, sensor/contact fidelity and bag recovery need assigned-host validation. Portable protocol doubles and synthetic SQLite coverage tests do not satisfy those gates. The native contact sensor currently observes the base collider; native whole-body/contact qualification must be assessed on the real engine before any stronger contact claim.
- Only the exact one-AMR canonical subject is mapped. Other engineering projects, xArm/MoveIt contact work, measured dynamics, full independent ROS message replay and hardware are outside the delivered L02 native preparation evidence.
- Full repository lint remains failing for unchanged historical evidence files, confirmed by root; changed-file lint passes. This is an explicit integration limitation, not a silently skipped gate.
- No push, main merge, deployment, Docker retry, cloud/native host provisioning, robot connection, operational port mutation or human acceptance signature occurred. Original main checkouts, trial and web were untouched.

## Audit appendix — exact final lint and syntax command scope

Appended after root's export/pin audit; no code, heads, existing report bytes or existing log bytes changed, and no checks were rerun.

The final focused lint invocation ran in the Source worktree with Node 24.22.2 selected:

```sh
export PATH="$HOME/.nvm/versions/node/v24.22.2/bin:$PATH"
perl -e 'alarm 120; exec @ARGV' pnpm exec eslint packages/lab-runtime/src/v2/sil/engineering-native.ts packages/lab-runtime/src/v2/sil/campaign.ts packages/lab-runtime/src/v2/sil/cli.ts packages/lab-runtime/src/v2/sil/native-handoff-documents.ts packages/lab-runtime/src/v2/backends/gazebo-nav2.ts scripts/lab-sil.mjs scripts/native-sim/profile-report.mjs scripts/native-sim/tool-identity.mjs tests/integration/engineering-native-lifecycle.test.ts tests/integration/engineering-native-evidence.test.ts tests/integration/engineering-profile-routing.test.ts > /tmp/l02-checks/final-focused-lint2.log 2>&1
cat /tmp/l02-checks/final-focused-lint2.log
git diff --check
```

The retained copy is `evidence-L02/portable/final-focused-lint2.log`. The recorded tool-shell exit status was **0**, with no lint diagnostics. **The ESLint subprocess exit status was not separately captured**: this shell invocation ended with `git diff --check`. The empty log therefore records the exact lint scope and absence of diagnostics; it is not an independently captured numeric ESLint exit receipt. This clarifies the earlier table's “empty successful output” wording.

The standalone JavaScript syntax command actually used was:

```sh
node --check scripts/lab-sil.mjs
```

It produced no diagnostics. That tool shell then ran the following Python AST check and returned **0**; the Node syntax subprocess exit status was not separately captured:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv-irsim/bin/python - <<'PY'
import ast
from pathlib import Path
for path in [*Path('robotics/simulation/bridge').glob('engineering*.py'),Path('robotics/simulation/compiler/engineering_native.py'),Path('robotics/simulation/launch/engineering_world.launch.py')]:
    ast.parse(path.read_text());print(path)
PY
```

Chronology correction: the standalone `node --check` preceded the final script-only addition of `subjectCommit`, `engineeringCase`, `accepted` and `dynamics` to engineering not_run manifests. No second standalone syntax check was run after that addition. The final script was subsequently linted by the exact focused command above and actually parsed/executed after the clean commit/pin by the recorded doctor, five case preflights and nominal verifier. Those executions preserve their actual `not_run` results; they are not a substitute claim of an independently logged final-tree `node --check` exit status. The earlier report's general “syntax/lint plus subsequent actual preflight” wording should be read with this chronology.

## Audit appendix — focused lint exit gap closed

At root's explicit request, the exact focused lint argv above was run **once** on unchanged Source `e6db696b2ac1266fdeede8c2a64521cd4064481a`, with Node `v24.22.2`. A Node harness invoked `perl` with `['-e', 'alarm 120; exec @ARGV', 'pnpm', 'exec', 'eslint', ...the exact eleven file paths above]`, captured the child result directly, wrote new evidence using exclusive creation, and returned the captured child exit code. No later shell command masked that result.

**Actual focused lint exit code: 0. Signal: null. Spawn error: null.** The new log contains no diagnostics. Source HEAD was checked before and after, remained exactly `e6db696b2ac1266fdeede8c2a64521cd4064481a`, and the tracked/untracked worktree status was clean before and after.

- Log: `evidence-L02/portable/final-focused-lint-unmasked.log`.
- Numeric exit receipt, full argv, Node version and checked Source identity: `evidence-L02/portable/final-focused-lint-unmasked.receipt.json`.

This closes the focused-lint exit-status gap disclosed in the preceding appendix. The earlier logs and report bytes remain preserved. No code, commit, export or Lab pin changed; no broad suite or standalone syntax check was rerun. The full-repository historical-evidence lint limitation remains unchanged.
