import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const source=process.cwd(),lab=source+'/../lab',directory=new URL('.',import.meta.url),exportDirectory='/tmp/l02-fix1-runtime-00d41e7-20261115';
const read=p=>JSON.parse(readFileSync(p)),sha=b=>createHash('sha256').update(b).digest('hex');
const git=(cwd,...args)=>{const r=spawnSync('git',args,{cwd,encoding:'utf8',timeout:10000});if(r.status!==0)throw Error(r.stderr);return r.stdout.trim();};
const m=read(exportDirectory+'/manifest.json'),pin=read(lab+'/config/source-runtime.lock.json'),sourceCommit=git(source,'rev-parse','HEAD'),labCommit=git(lab,'rev-parse','HEAD');
if(git(source,'status','--porcelain')||git(lab,'status','--porcelain'))throw Error('Dirty subject');
if(m.dirty||pin.dirty||m.sourceCommit!==sourceCommit||pin.sourceCommit!==sourceCommit)throw Error('Source pin mismatch');
if(m.artifactSha256!==pin.artifactSha256||m.schemaHash!==pin.schemaHash)throw Error('Artifact/schema pin mismatch');
const cached=lab+'/.runtime/'+pin.artifactSha256;
if(JSON.stringify(read(cached+'/manifest.json'))!==JSON.stringify(m))throw Error('Cached manifest mismatch');
for(const root of [exportDirectory,cached])if(sha(readFileSync(root+'/runtime.mjs'))!==m.artifactSha256)throw Error('Runtime hash mismatch');
for(const entry of [...m.nativeTools.files,...m.portableSimulationTools.closure.files])if(sha(readFileSync(source+'/'+entry.path))!==entry.sha256)throw Error('Closure mismatch '+entry.path);
const attribution={};
for(const [name,paths] of Object.entries({'combined-python':['robotics/simulation/bridge/engineering_session.py','robotics/simulation/tests/test_engineering_native_parity.py'],'final-cli':['tests/integration/engineering-native-cli.test.ts','tests/support/engineering-cli-probes.mjs'],'final-focused-lint':['tests/integration/engineering-native-cli.test.ts','tests/support/engineering-cli-probes.mjs'],'final-typecheck':['tests/integration/engineering-native-cli.test.ts','tests/support/engineering-cli-probes.mjs']})){
 const r=read(new URL(name+'.receipt.json',directory));if(r.exitCode!==0)throw Error('Check failed '+name);
 attribution[name]={checkedHead:r.before.head,diffSha256:r.before.diffSha256,files:{}};
 for(const path of paths){const digest=sha(readFileSync(source+'/'+path));if(digest!==r.before.changedFiles[path]||digest!==r.after.changedFiles[path])throw Error('Check attribution mismatch '+name+' '+path);attribution[name].files[path]=digest;}
}
const cases=[];
for(const name of ['nominal','obstacle','no-path','cancel','worker-loss']){
 const path='native-not-run/'+name+'/run-manifest.json',record=read(new URL(path,directory)),receipt=read(new URL('native-'+name+'.receipt.json',directory));
 if(record.sourceCommit!==sourceCommit||record.status!=='not_run'||record.result!=='blocked_external'||record.accepted!==false||receipt.exitCode!==2)throw Error('Native claim mismatch');
 cases.push({case:name,path,sha256:sha(readFileSync(new URL(path,directory))),exitCode:receipt.exitCode,status:record.status,sourceCommit});
}
const identity={schemaVersion:1,accepted:false,dynamics:'not_calibrated',nativeExecution:'not_run',subject:{sourceCommit,sourceTree:git(source,'rev-parse','HEAD^{tree}'),labCommit,labTree:git(lab,'rev-parse','HEAD^{tree}'),sourceClean:true,labClean:true,schemaHash:m.schemaHash,runtimeArtifactSha256:m.artifactSha256,nativeToolsDigest:m.nativeTools.digest,nativeRefs:m.nativeTools.files.length,portableToolsDigest:m.portableSimulationTools.closure.digest,portableRefs:m.portableSimulationTools.closure.files.length},checker:{kind:'portable-tests-and-macos-preflight',sourceCommit,nativeHostAssigned:false,independentNativeQualification:false},pin,exportDirectory,attribution,cases};
writeFileSync(new URL('identities.json',directory),JSON.stringify(identity,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(identity.subject,null,2));
