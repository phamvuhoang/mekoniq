

## Correction4 — tick-boundary HTTP controls with writer/lifecycle reservations

**DONE for the isolated prerequisite correction; ready for root's independent scoped architecture review.** This does not resume or complete final recording/publication, B10/L06, or the ONE whole-branch review. The complete 82,236-byte prior report prefix is preserved, SHA256 `f776790ede1f9ffb854d4206dcdf6e983bb9da168890edf11c48905085cf2575`. All earlier report prefixes and successful/failed recordings remain historical at their original subjects. The complete dispatch, prior report, correction3 review/dispositions, and B09 brief/full review/fix/re-review were read. No helper/reviewer agent was dispatched.

Work remained in the two `codex/web-lab-to-physical` worktrees. No main/trial/web, operational port, unrelated service, Docker, builder, host provisioning, hardware, deployment, push, publication or acceptance-gate change. Known unavailable service/Docker prerequisites were not retried and no service receipt was borrowed. Every check wrapper explicitly removed `MEKONIQ_TEST_SERVICE_RECEIPT`. No original retained SQLite file was opened with an engine.

### Final paired code and export identities

| Repository | Commit | Tree |
|---|---|---|
| Source | `981e234b1a0da8c72d220445daaf780b3bf65ae4` — `fix: admit tick-boundary controls under the run reservation` | `0f00b40f4cdff7ea8acb08db7901b119beee9216` |
| Lab | `b0fcedec2bc826c4501972f424f3c9798b6b7449` — `chore: pin source runtime 981e234` | `2ac16ff1c956f6b57210778c88e29812121583c2` |

Both trees are clean. Source FIX_BASE is `229efa7f565876f8f9d69634f8fbc24b9196ed3f`; Lab FIX_BASE is `45794aa8ec7eb8a19214a6e16786455f7c948bb1`. Complete binary packages and commit/stat companions are in `evidence-final-recording/fix4/`: `source-fix-base.patch` 31,692 bytes / SHA256 `baa18a98be7de50958cb482881f38a86868a67e8f351e16689a555ed6ea1b222`; `lab-fix-base.patch` 2,624 bytes / SHA256 `02f8294927315b9586ecd1810b7ec885ac925b5185bdea1855c0db435195ae93`.

Source changes four files only: `packages/lab-runtime/src/v2/gateway.ts`, `navigation2d/runner.ts`, the optional internal `ScenarioRun` interface in `scenario-runner.ts`, and new `tests/security/lab-run-controls.test.ts`. Lab changes only its source-runtime lock and the two generated Source-identity headers. Generated schema bodies and Lab product behavior are unchanged.

Fresh external output root: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix4-127p5qi7`. Clean export is its `export/`, with a retained exact 60-file copy in `fix4/export-final/`. Runtime artifact: `8eb11109765263e0b209ece7649bb511b8f67a0c0a035edba1d78b803d4ceec1`; raw manifest: `d5a9b7386987437d916c1ab602c8fae36cdb55f2ad59ec41e12ac003b1adb7a8`. Source was committed and clean before normal export; no dirty or identity override was used. Lab import, contract synchronization, installed bytes, generated headers and lock all match that export.

The actual old/new full path lists and bytes were compared and aggregate digests recomputed: schema 58 files / `0d4ae124258123d27a21b67a8441dee13d703fd5ab7596ad298bcab9233a31e5`; native 226 files / 1,578,397 bytes / `79018e0a2601d8a27d3739751910bb392c86c2857cc39ad5fb451a977de78634`; portable 238 files / 8,116,001 bytes / `30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b`. All are unchanged from the prior export. Runtime and Source subject nevertheless changed: prior229 preparation/production/qualification results cannot qualify981.

The full trusted checker input graph has the same 1,115 paths; exactly the three production TypeScript files above change their Git blobs. Graph changes from `4598c7ab2b4d7fc7e991ca5af8f485982197140b0108cdbb240052f5d7a808f2` to `2d911a9d0028b12d0b6360b49170d77bbbe95b8ca2feed7cf5771ac3bef07ffe`, audited at Source981. Complete lists and changed entries are in `checker-graph-comparison.json`; this is a checker identity, not host authenticity.

### Scheduling and authority design

The original full-action gateway reservation prevented HTTP pause/cancel from entering the existing fixed-step queue. Removing that reservation would have broken reviewed writer transfer, reclaim and resource ownership. The fix retains the same logical-run queue through complete action settlement and adds an internal, optional atomic `controlDuringStep` admission method only to fixed-step runners. Generic ScenarioRun implementations omit it and retain ordinary ordering, including the existing future-revision paced pause behavior.

A fixed-step request synchronously registers an ordered reservation token before the run-queue microtask. This closes a separately reproduced same-turn admission gap. A token becomes active and resolves readiness only when its original serial callback owns the run and has invoked runner.action. Pause/cancel can select only the oldest token for the same entry. They check current authority before waiting, again after readiness, and again at actual runner execution. They attach only if that same token is still active and first, with no await between this check and the runner's synchronous step-counter check/enqueue. If the runner already drained its batch, admission returns undefined and the control takes the ordinary run queue with exact revision checks.

Every token's outer finally clears active state, resolves readiness even when authority/runner admission throws, and removes only that token. A later queued step never replaces an older active/pending token. Controls waiting behind a transfer-before-step wake and refuse the former writer; a refused runner step still drains its independently valid control. There is no readiness/queue cycle: controls wait for step admission, the step never waits for a control's gateway queue position, and controls execute inside the runner rather than reserving a second lifecycle operation.

The original logical-run reservation still owns transfer, cold/live reclaim, archive, expiry and complete step settlement. Cold reclaim still resolves the current entry inside that reservation, holds through factory/hold/durable epoch/install, and remains view/reconcile-only. No world is created by the new path. Transfer cannot publish a writer/epoch while a prior admitted batch/control owns mutating work. Public close still stops new HTTP admission and waits admitted handlers before closing workers and releasing the data-root lease. A real public-close regression with a held fixed-step batch and admitted control verifies lease refusal until both settle and the worker closes; then the same root can be opened again.

The fixed-step queue now carries `beforeExecute` with each control. Each control still uses its own validation, revision, action hash, receipt and state checks; callbacks execute after asynchronous state reads and before effects. Priority cached receipts also check current authority at their queued execution boundary. Ordinary cached start/resume and generic runner retry semantics are unchanged; no readiness check was added to those cached paths. Private404, session/owner/current-entry/epoch, cookie CSRF, Origin and existing readiness/engineering-closure checks remain.

A denied/expired/stale control has no stopping effect on the already admitted batch. Once a control passes execution admission, the batch ends at that boundary even if checkpoint/worker work fails; uncertain mutation cannot be followed by additional ticks. A successful cached control returns its original receipt without reapplying pause/cancel or adding a control revision. The batch still yields at that boundary, preserving the old queue's behavior when a cached control was pending. A denied cached replay neither returns the receipt nor truncates the batch. Pending runner controls are capped at the existing 10,000 action-limit scale; durable receipt limits remain intact.

Runner controls are drained only between completed individual ticks, after a pacing wait, or in the step's existing finally drain. They cannot issue a mutating worker request alongside a tick request. Tick size, dt, unknown-ACK recovery, physical completion checks, receipt revisions and no-resend/no-respawn semantics are unchanged. Late controls are either drained by the step or explicitly take the ordinary queue; none are left pending without an owner.

### RED/GREEN and covering evidence

All commands have own argv/cwd/relevant environment, start/end time, actual exit/signal, before/after Git/checked-byte state and raw-log SHA256 under `fix4/checks/`. Long invocations used bounded Perl alarms and transient owned caffeinate. Node is24.22.2, pnpm10.32.1; the existing `.venv-irsim` is Python3.11.15 / ir-sim2.12.0 / PyYAML6.0.3, requirements lock SHA256 `428308122946981ae3da4e3080f55357a0c56ee6d9a73ccacff9929edb8322e4`. Bytecode and pytest cache generation were disabled. No environment was installed or modified.

- `control-red`: 6 failed / 1 passed. Five failures demonstrate the original production defects; the negative-admission test additionally had a fixture timeout because it awaited serialized refusals before releasing its own batch barrier. That timeout is retained, explicitly not semantic evidence. The initial test source is preserved as `control-red-input.ts`.
- `control-red2`, after fixing only that test ordering: 6 failed / 3 passed / 0 skipped. Held-boundary pause/cancel lost to transfer with409; controls lost to reclaim/archive with404; the direct queued execution callback was dropped, allowing pause; queued cached controls returned receipts without authority. This ran before production edits. All raw assertions remain.
- Initial `control-green`:9/9; expanded `control-complete`:11/11. The first unchanged-byte covering run (`source-covering`) passed45/45 across eight complete files, including the original real HTTP regression. These belong to the earlier draft, not final-byte verification.
- Self-review added two failure-path probes. `failure-boundary-red`:2 failed /1 passed /11 filtered-not_run. An admitted control checkpoint failure allowed20 ticks rather than stopping at1; same-turn handler step/pause fell through the gateway admission microtask gap and returned409. The permitted cached replay case already passed. These are genuine draft defects, not original229 failures. Both were corrected at the same narrow control boundary; `control-final` then passed14/14.
- **Final covering run: own0/signalnull,62 passed /0 failed /0 skipped across nine complete files**, including all17 new cases and every original assertion in `irsim-authority.test.ts`, whose100tick batch and120s bound are unchanged. The three final safety additions cover refused-step drain/readiness settlement, transfer-before-step waiting controls, and preservation of the oldest reservation. The exact final Source bytes are present at both receipt boundaries.
- Source full typecheck, contracts check, authored-tree lint excluding only `.superpowers/**`, full build and diff-check pass. An earlier successful lint invocation shell-expanded its exclusion to `.superpowers/sdd`; it is retained separately and was followed by the exact quoted exclusion, including the final-byte check. Source build retains inherited nested-npm environment warnings; no pristine-output claim erases them.
- **Lab11/11 across three complete files**, including actual Source IR-SIM report/evidence import, plus full typecheck/build/check:source and diff-check pass on final pinned bytes. No UI/browser behavior was changed, so no additional browser journey or full mock/performance campaign was run. These checks do not promote older229 recordings to the new tuple.

Final Source test selection (exact bounded argv and JSON output selector are in `checks/final-covering.receipt.json`):

```sh
pnpm exec vitest run \
 tests/security/lab-run-controls.test.ts tests/security/irsim-authority.test.ts \
 tests/security/lab-run-writer.test.ts tests/security/web-replay-gateway.test.ts \
 tests/integration/lab-v2-paced-step.test.ts tests/integration/lab-v2-reclaim-targets.test.ts \
 tests/integration/irsim-mission.test.ts tests/integration/irsim-recovery.test.ts \
 tests/integration/irsim-faults.test.ts
pnpm typecheck
pnpm contracts:check
pnpm exec eslint . --ignore-pattern '.superpowers/**'
pnpm build
# Lab, after normal clean export/import/sync:
pnpm exec vitest run tests/integration/runtime-artifact.test.ts tests/unit/runtime-compatibility.test.ts tests/integration/source-report-import.test.ts
pnpm typecheck
pnpm build
pnpm check:source
```

The new scheduling fixture uses controlled handler request objects and explicit wall/result barriers around the real fixed-step runner, Source journal and local IR-SIM worker. One checkpoint method is fault-injected in its stated failure test. These are scheduling/authority tests, not native/physics qualification or measured HTTP arrival timing. Separate unchanged real HTTP coverage remains the actual network positive. Existing recovery doubles retain their original protocol-only meaning. No assertion duration is recast as an arrival/latency observation. Test scopes overlap and are not summed across repeated invocations.

### Self-review, retention and handoff

Read the full final four-file Source diff and three-file Lab diff. Self-review found and corrected the same-turn admission gap and post-admission failure distinction described above, with retained RED/GREEN evidence. No known remaining implementation blocker was found; root owns independent scoped review. The existing gateway/runner files are large and dense; this correction deliberately confines the change to their action/control seam rather than restructuring unrelated behavior.

`final-byte-attribution.json` verifies both final clean Git heads/trees/blobs, complete binary patches, all final Source/Lab bytes at both boundaries of their respective final tests/gates, exact export/pin and checker graph. It revalidated **14,869 historical indexed file entries across18 indices**: the prior16-index9,791-entry set, plus all141 previous-phase metadata and4,937 external files indexed at correction4 entry. Counts overlap and are not unique files/tests. The earlier root139-file frozen summary retains its own historical scope; no earlier index was rewritten. The20 original security-failure snapshots still match their original hashes; code inputs are also checked against Source229 Git blobs, while unchanged raw/log paths remain byte-identical. Changed current product paths are not falsely described as229 bytes.

The audit had32 preceding own receipts; its own successful receipt makes33. All33 raw receipt/log pairs are retained with actual statuses: three own1 RED invocations and30 own0 checks. Git staging/commit and import/sync receipts correctly show intended before/after changes; all test/gate invocations kept checked bytes unchanged. New final metadata/external indices and completion bindings are in `fix4/`, explicitly excluding their own recursive hashes. Local hashes and own receipts establish the stated local provenance, not independent host authenticity or an all-host cleanup guarantee.

No final qualification, long IR-SIM batch campaign, R1/R1.1/R2a/R2b/R3 recording, image/container attempt, production measurement, full mock, publication or reviewer dispatch occurred. Original service-dependent failures remain failed/not_run at their original scopes. Native/controller/hardware/calibration/security-host/human acceptance gates remain open, `accepted:false`/`not_calibrated` unchanged. Root must audit/review this paired981/b0f tuple before deciding fresh final recording; previous229 preparations, mock/acceptance and successful/failed security outputs remain immutable and cannot be reused as current-subject execution.
