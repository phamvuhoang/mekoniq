from pathlib import Path
import subprocess,json,hashlib
b=Path(__file__).resolve().parent;s=b.parents[4];lab=s.parent/'lab';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();digest=lambda x:hashlib.sha256(x).hexdigest()
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def text(repo,*args):return git(repo,*args).decode().strip()
sourceBase='229efa7f565876f8f9d69634f8fbc24b9196ed3f';labBase='45794aa8ec7eb8a19214a6e16786455f7c948bb1'
assert not text(s,'status','--porcelain','--untracked-files=all') and not text(lab,'status','--porcelain','--untracked-files=all')
result={'repositories':{}}
for name,repo,base in [('source',s,sourceBase),('lab',lab,labBase)]:
 head=text(repo,'rev-parse','HEAD');patch=git(repo,'diff','--binary',base,head);(b/(name+'-fix-base.patch')).write_bytes(patch)
 (b/(name+'-commits-stat.txt')).write_bytes(git(repo,'log','--format=fuller','--stat',base+'..'+head)+git(repo,'diff','--stat',base,head))
 paths=text(repo,'diff','--name-only',base,head).splitlines();files=[]
 for p in paths:
  data=(repo/p).read_bytes();assert data==git(repo,'show',head+':'+p);files.append({'path':p,'bytes':len(data),'sha256':digest(data)})
 result['repositories'][name]={'head':head,'tree':text(repo,'rev-parse','HEAD^{tree}'),'clean':True,'base':base,'files':files,'patchBytes':len(patch),'patchSha256':digest(patch)}
# The historical failure input's changed code is compared with its original Git subject, never mislabelled as current bytes.
handoff=b.parent/'229efa7/security-failure-handoff';inputs=read(handoff/'input-hashes.json');snapshots=[]
for f in inputs['files']:
 snapshot=handoff/f['snapshot'];assert snapshot.stat().st_size==f['bytes'] and sha(snapshot)==f['sha256'];p=Path(f['source']);scope='unchanged path'
 if p.is_relative_to(s) and not str(p.relative_to(s)).startswith('.superpowers/'):
  original=git(s,'show',sourceBase+':'+str(p.relative_to(s)));assert len(original)==f['bytes'] and digest(original)==f['sha256'];scope='original Git subject'
 else:assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
 snapshots.append({'source':str(p),'sha256':f['sha256'],'checkedAgainst':scope,'snapshot':str(snapshot)})
result['originalFailureInputs']=snapshots
# Revalidate every earlier retained index from the frozen phase, plus that complete phase's new bytes.
preserved=[]
for item in read(b.parent/'229efa7/phase-preservation-audit.json')['preserved']:
 p=Path(item['index']);assert sha(p)==item['sha256'];j=read(p)
 for f in j['files']:
  q=Path(j['root'])/f['path'];assert q.stat().st_size==f['bytes'] and sha(q)==f['sha256'],str(q)
 for f in j.get('symlinks',[]):assert (Path(j['root'])/f['path']).is_symlink()
 preserved.append(item)
for name in ['previous-phase-metadata-index.json','previous-phase-external-index.json']:
 j=read(b/name)
 for f in j:
  p=Path(f['path']);assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],str(p)
 preserved.append({'index':str(b/name),'sha256':sha(b/name),'files':len(j)})
result['preservedIndices']=preserved;result['preservedFileEntries']=sum(x['files'] for x in preserved)
prefix=(b/'report-prefix-82236.md').read_bytes();assert len(prefix)==82236 and digest(prefix)=='f776790ede1f9ffb854d4206dcdf6e983bb9da168890edf11c48905085cf2575';assert (s/'.superpowers/sdd/README/task-final-recording-report.md').read_bytes().startswith(prefix)
result['preservedReportPrefix']={'bytes':len(prefix),'sha256':digest(prefix)}
checks=[]
for p in sorted((b/'checks').glob('*.receipt.json')):
 j=read(p);log=p.with_name(p.name.replace('.receipt.json','.log'));assert sha(log)==j['logSha256'];checks.append({'name':p.name.removesuffix('.receipt.json'),'receiptSha256':sha(p),**j})
(b/'check-index.json').write_text(json.dumps(checks,indent=2)+'\n')
# Require all final source bytes at BOTH boundaries of the complete final tests and gates.
for name in ['final-covering','source-final-type','source-final-lint','source-final-contracts','source-build']:
 j=next(x for x in checks if x['name']==name);assert j['exitCode']==0 and j['signal'] is None
 for side in ['before','after']:
  files={x['path']:x['sha256'] for x in j[side]['changed']}
  for f in result['repositories']['source']['files']:assert files.get(f['path'])==f['sha256'],(name,side,f['path'])
result['finalSourceByteChecks']=['final-covering','source-final-type','source-final-lint','source-final-contracts','source-build']
for name in ['lab-tests','lab-type','lab-check-source','lab-build']:
 j=next(x for x in checks if x['name']==name);assert j['exitCode']==0 and j['signal'] is None
 for side in ['before','after']:
  files={x['path']:x['sha256'] for x in j[side]['changed']}
  for f in result['repositories']['lab']['files']:assert files.get(f['path'])==f['sha256'],(name,side,f['path'])
result['finalLabByteChecks']=['lab-tests','lab-type','lab-check-source','lab-build']

# Full checker input lists/bytes, independently recomputing old/new graph hashes.
roots=['scripts','packages','robotics','integrations','tests/fixtures','package.json','pnpm-lock.yaml','tsconfig.json','.gitignore'];graphs={}
for label,head in [('old',sourceBase),('new',result['repositories']['source']['head'])]:
 raw=git(s,'ls-tree','-r','-z','--full-tree',head,'--',*roots).decode().strip();rows=[]
 for line in raw.split('\0'):
  if not line:continue
  entry,path=line.split('\t');mode,kind,blob=entry.split();rows.append({'path':path,'mode':mode,'kind':kind,'blob':blob})
 graphs[label]={'sourceCommit':head,'toolSha256':digest(raw.encode()),'files':rows}
assert [f['path'] for f in graphs['old']['files']]==[f['path'] for f in graphs['new']['files']]
graphs['changed']=[n['path'] for o,n in zip(graphs['old']['files'],graphs['new']['files']) if o!=n]
checker=read(b/'checker-identity.json');assert checker['toolSha256']==graphs['new']['toolSha256'];assert checker['sourceCommit']==graphs['new']['sourceCommit']
(b/'checker-graph-comparison.json').write_text(json.dumps(graphs,indent=2)+'\n');result['checker']={'old':graphs['old']['toolSha256'],'new':graphs['new']['toolSha256'],'files':len(graphs['new']['files']),'changed':graphs['changed']}
result['export']=read(b/'export-verification.json');result['limits']=['Local provenance only; no host authenticity','No native, physical, image, service-CI, qualification or human acceptance','Historical indices overlap and are not unique-file/test counts']
(b/'final-byte-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':result['repositories']['source']['head'],'lab':result['repositories']['lab']['head'],'preservedEntries':result['preservedFileEntries'],'failureInputs':len(snapshots),'checks':len(checks),'checker':result['checker']},indent=2))
