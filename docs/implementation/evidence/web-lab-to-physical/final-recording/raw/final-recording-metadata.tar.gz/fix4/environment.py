from pathlib import Path
import subprocess,json,hashlib
b=Path(__file__).resolve().parent;s=b.parents[4]
commands=[['node','--version'],['pnpm','--version'],[str(s/'.venv-irsim/bin/python'),'-c','import sys,json,importlib.metadata as m; print(json.dumps({"executable":sys.executable,"version":sys.version,"irsim":m.version("ir-sim"),"PyYAML":m.version("PyYAML")}))']]
rows=[]
for argv in commands:
 r=subprocess.run(argv,cwd=s,text=True,capture_output=True,timeout=20);assert r.returncode==0;rows.append({'argv':argv,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
assert rows[0]['stdout'].strip()=='v24.22.2' and rows[1]['stdout'].strip()=='10.32.1'
for p in [s/'.venv-irsim/pyvenv.cfg',s/'robotics/navigation-2d/requirements.lock']:
 rows.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(b/'environment.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
