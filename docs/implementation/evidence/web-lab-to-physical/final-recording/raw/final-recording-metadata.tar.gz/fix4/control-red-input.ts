// Handler/request objects and wall-clock barriers control scheduling; the fixed-step runner,
// Source journal and IR-SIM worker are real. This is authority/lifecycle coverage, not qualification.
import {afterAll,afterEach,beforeAll,expect,test} from 'vitest';
import {rm} from 'node:fs/promises';
import {join} from 'node:path';
import type {IncomingMessage,ServerResponse} from 'node:http';
import {createV2Gateway} from '../../packages/lab-runtime/src/v2/gateway';
import {createIRSimScenarioRun} from '../../packages/lab-runtime/src/v2/navigation2d/runner';
import {portableCatalog} from '../../packages/lab-runtime/src/v2/navigation2d/readiness';
import type {ScenarioRun,RunView} from '../../packages/lab-runtime/src/v2/scenario-runner';
import {findReclaim} from '../../packages/lab-runtime/src/v2/reclaim-store';
import {irsimAvailable,irsimBundle,irsimProviders,removeBundles,temp} from '../support/irsim-mission';
const gate=()=>{let release!:()=>void;return {promise:new Promise<void>(r=>release=r),release:()=>release()};};
const turn=()=>new Promise<void>(r=>setImmediate(r));
const origin='http://127.0.0.1:4175',schemaHash='a'.repeat(64),IR='engineering-irsim-2d-v1';
let bundle:Awaited<ReturnType<typeof irsimBundle>>;
const cleanup:(()=>Promise<void>)[]=[];
beforeAll(async()=>{if(irsimAvailable)bundle=await irsimBundle();},120_000);
afterEach(async()=>{for(const close of cleanup.splice(0))await close();});
afterAll(removeBundles);
interface Reply {status:number;body:RunView&{sessionToken:string;sessionId:string;csrfToken:string;reclaimToken:string;error:string;writer:{controlEpoch:number;sessionId:string}}}
async function fixture(){
 const directory=await temp('priority-control-'),boundary=gate(),release=gate();let now=1000,wall=0,run!:ScenarioRun,closes=0;
 const requests=new WeakMap<IncomingMessage,Record<string,unknown>>(),responses=new WeakMap<ServerResponse,Reply>();
 const g=createV2Gateway({directory,sourceCommit:'test-commit',schemaHash,now:()=>now,pairingValid:()=>true,spendPairing(){},same:(a,b)=>a===b,catalog:portableCatalog(true),enabledBackends:['irsim_2d'],engineering:bundle.service,
  portableChecks:async()=>['model','clock','fixture','profile','runner'].map(id=>({id,status:'ready' as const,reasonCodes:[],evidenceRef:'test-owned-worker'})),
  readBody:async r=>requests.get(r)!,send:(r,status,body)=>{responses.set(r,{status,body:body as Reply['body']});},
  simulationFactory:async(input,p)=>{run=await createIRSimScenarioRun(input,{...await irsimProviders(p.directory,bundle.service),wall:{now:()=>wall,sleep:async ms=>{boundary.release();await release.promise;wall+=ms;}}});const close=run.close.bind(run);run.close=async()=>{closes++;await close();};return run;}});
 const pending:Promise<unknown>[]=[];
 const call=(path:string,body:Record<string,unknown>,token?:string,headers:Record<string,string>={},requestOrigin:string|undefined=origin)=>{
  const req={method:'POST',headers:{...token?{authorization:`Bearer ${token}`}:{},...headers}} as IncomingMessage,res={setHeader(){}} as unknown as ServerResponse;requests.set(req,body);
  const p=g(req,res,'/lab/v2'+path,requestOrigin).then(()=>responses.get(res)!);pending.push(p);return p;
 };
 cleanup.push(async()=>{release.release();await Promise.allSettled(pending);await g.close();await rm(directory,{recursive:true,force:true});});
 const pair=async()=>(await call('/sessions',{token:'pair'})).body,a=await pair(),b=await pair(),c=await pair();
 const compiled=await call('/engineering/compile',{project:bundle.locked.project},a.sessionToken);
 const ref=compiled.body as unknown as {bundleDigest:string;projectDigest:string};
 const made=await call('/runs',{scenarioId:'IR-FD01',scenarioRevision:1,seed:5,mode:'simulation',access:'simulated',backendSetId:IR,runtimeIdentity:{sourceCommit:'test-commit',schemaHash},engineeringRef:{bundleDigest:ref.bundleDigest,projectDigest:ref.projectDigest}},a.sessionToken);
 expect(made.status,JSON.stringify(made.body)).toBe(201);const path=`/runs/${made.body.run.id}`;
 const act=(kind:string,revision:number,who=a,extra:Record<string,string>={},actionId=kind,payload:Record<string,unknown>={})=>call(path+'/actions',{actionId,expectedRevision:revision,kind,payload},who.sessionToken,extra);
 const started=await act('start',made.body.run.runRevision);expect(started.status).toBe(200);const rev=started.body.run.runRevision;
 const writer=(operation:string,who=a,recipient=b,epoch=0)=>call(path+'/writer',{operation,recipientSessionId:recipient.sessionId,controlEpoch:epoch},who.sessionToken);
 const batch=()=>act('step',rev,a,{},'batch',{ticks:20,pace:{factor:1}});
 return {g,run,call,act,a,b,c,pair,writer,batch,path,made,rev,boundary,release,advance:(ms:number)=>{now+=ms;},directory,closes:()=>closes};
}
for(const kind of ['pause','cancel'])test.skipIf(!irsimAvailable)(`priority ${kind} crosses a held batch boundary while transfer keeps the reservation`,async()=>{
 const f=await fixture();expect((await f.writer('grant_read')).status).toBe(200);
 const batch=f.batch();await f.boundary.promise;expect(f.run.pulse().tick).toBe(1);
 let transferred=false;const transfer=f.writer('transfer').then(r=>{transferred=true;return r;});
 const control=f.act(kind,f.rev);await turn();expect(transferred).toBe(false);expect((await findReclaim(f.directory,f.run.id))!.record.controlEpoch??0).toBe(0);
 f.release.release();const [s,c,t]=await Promise.all([batch,control,transfer]);expect(c.status,JSON.stringify(c.body)).toBe(200);expect(s.status).toBe(200);
 expect(c.body.tick).toBe(1);expect(s.body.tick).toBe(c.body.tick);expect([c.body.run.runRevision,s.body.run.runRevision]).toEqual([f.rev+1,f.rev+2]);
 expect(t.status).toBe(200);expect(t.body.writer).toMatchObject({sessionId:f.b.sessionId,controlEpoch:1});expect((await findReclaim(f.directory,f.run.id))!.record.controlEpoch).toBe(1);
 expect((await f.act(kind,f.rev)).body.error).toBe('RUN_WRITER_CONFLICT');
 // Receipt replay remains available to the current writer, with no second mutation; changed payload/id remains a conflict.
 const retry=await f.act(kind,f.rev,f.b,{'x-lab-control-epoch':'1'});expect(retry.status).toBe(200);expect(retry.body.tick).toBe(c.body.tick);expect(retry.body.run).toEqual(c.body.run);
 expect((await f.act(kind,f.rev+2,f.b,{'x-lab-control-epoch':'1'})).body.error).toBe('ACTION_CONFLICT');
},120_000);

test.skipIf(!irsimAvailable)('priority admission refuses reader, stranger, stale epoch, CSRF and Origin before reaching the step queue',async()=>{
 const f=await fixture();await f.writer('grant_read');const batch=f.batch();await f.boundary.promise;
 const rejected=await Promise.all([f.act('pause',f.rev,f.b),f.act('cancel',f.rev,f.c),f.act('pause',f.rev,f.a,{'x-lab-control-epoch':'1'}),
  f.call(f.path+'/actions',{actionId:'csrf',expectedRevision:f.rev,kind:'pause',payload:{}},undefined,{cookie:`mekoniq_lab_session_v2=${f.a.sessionToken}`}),
  f.call(f.path+'/actions',{actionId:'origin',expectedRevision:f.rev,kind:'pause',payload:{}},f.a.sessionToken,{},undefined)]);
 expect(rejected.map(r=>r.status)).toEqual([409,404,409,403,403]);expect(rejected.map(r=>r.body.error)).toEqual(['RUN_WRITER_CONFLICT','RUN_NOT_FOUND','RUN_WRITER_CONFLICT','CSRF_INVALID','ORIGIN_REQUIRED']);
 f.release.release();expect((await batch).body.tick).toBe(20);expect(f.run.pulse().paused).toBe(false);
},120_000);

test.skipIf(!irsimAvailable)('priority control rechecks session expiry at execution and expiry cleanup waits for the batch',async()=>{
 const f=await fixture(),batch=f.batch();await f.boundary.promise;const pause=f.act('pause',f.rev);await turn();f.advance(3600001);const fresh=await f.pair();
 const expiry=f.call('/readiness',{scenarioId:'IR-FD01',backendSetId:IR,engineeringRef:f.run?bundle.locked.ref:undefined},fresh.sessionToken);
 await turn();expect(f.closes()).toBe(0);f.release.release();const [s,p]=await Promise.all([batch,pause]);expect(s.status).toBe(200);expect(p.status).toBe(401);expect(p.body.error).toBe('SESSION_REQUIRED');expect(f.run.pulse().paused).toBe(false);await expiry;
},120_000);

test.skipIf(!irsimAvailable)('direct fixed-step queue forwards the control execution callback and does not cache a refused pause',async()=>{
 const f=await fixture(),batch=f.batch();await f.boundary.promise;let allowed=true;
 const raw={actionId:'guarded-pause',expectedRevision:f.rev,kind:'pause',payload:{}};
 const control=f.run.action(raw,async()=>{if(!allowed)throw Error('SESSION_REQUIRED');}).then(v=>({view:v,error:null}),e=>({view:null,error:(e as Error).message}));
 allowed=false;f.release.release();const [s,c]=await Promise.all([batch,control]);expect(c.error).toBe('SESSION_REQUIRED');expect(f.run.pulse().paused).toBe(false);
 const retry=await f.run.action({...raw,expectedRevision:s.body.run.runRevision},async()=>{});expect(retry.run.status).toBe('paused');
},120_000);

for(const operation of ['reclaim','archive'])test.skipIf(!irsimAvailable)(`priority pause settles before ${operation} changes or closes the entry`,async()=>{
 const f=await fixture(),batch=f.batch();await f.boundary.promise;let finished=false;
 const lifecycle=f.call(f.path+'/'+operation,operation==='reclaim'?{proof:f.made.body.reclaimToken}:{},operation==='reclaim'?f.b.sessionToken:f.a.sessionToken).then(r=>{finished=true;return r;});
 const pause=f.act('pause',f.rev);await turn();expect(finished).toBe(false);expect(f.closes()).toBe(0);f.release.release();const [s,p,l]=await Promise.all([batch,pause,lifecycle]);
 expect(p.status,JSON.stringify(p.body)).toBe(200);expect(s.body.tick).toBe(p.body.tick);expect(l.status).toBe(200);
 if(operation==='reclaim'){expect(l.body.writer.controlEpoch).toBe(1);expect((await f.act('cancel',s.body.run.runRevision)).status).toBe(404);}else expect(f.closes()).toBe(1);
},120_000);
