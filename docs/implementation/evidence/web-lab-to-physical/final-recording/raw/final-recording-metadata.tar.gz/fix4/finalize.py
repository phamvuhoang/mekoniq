from pathlib import Path
import json,hashlib,subprocess,shutil,os
b=Path(__file__).resolve().parent;s=b.parents[4];root=Path(json.loads((b/'paths.json').read_text())['root']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
for p in sorted((b/'checks').glob('*.receipt.json')):
 j=json.loads(p.read_text());log=p.with_name(p.name.replace('.receipt.json','.log'));assert sha(log)==j['logSha256'];checks.append({'receipt':p.name,'receiptSha256':sha(p),**j})
assert len(checks)==33 and sum(x['exitCode']==0 for x in checks)==30 and sum(x['exitCode']==1 for x in checks)==3
(b/'check-index-complete.json').write_text(json.dumps(checks,indent=2)+'\n');shutil.copytree(b/'checks',root/'checks')
report=s/'.superpowers/sdd/README/task-final-recording-report.md';prefix=(b/'report-prefix-82236.md').read_bytes();assert report.read_bytes().startswith(prefix) and len(prefix)==82236
heads={}
for name,repo in [('source',s),('lab',s.parent/'lab')]:
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=repo)
 heads[name]={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip()}
def index(directory,exclude=()):
 files=[];symlinks=[]
 for p in sorted(directory.rglob('*')):
  path=str(p.relative_to(directory))
  if path in exclude:continue
  if p.is_symlink():symlinks.append({'path':path,'target':os.readlink(p)})
  elif p.is_file():files.append({'path':path,'bytes':p.stat().st_size,'sha256':sha(p)})
 return {'root':str(directory),'excludedRootNames':list(exclude),'files':files,'symlinks':symlinks,'fileCount':len(files),'bytes':sum(f['bytes'] for f in files)}
external=index(root);(b/'external-retention-index.json').write_text(json.dumps(external,indent=2)+'\n')
metadata=index(b,['metadata-retention-index.json','handoff-completion.json']);(b/'metadata-retention-index.json').write_text(json.dumps(metadata,indent=2)+'\n')
for j in [external,metadata]:
 for f in j['files']:
  p=Path(j['root'])/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
completion={'scope':'correction4 frozen scoped-review handoff; no final campaigns/publication','heads':heads,'report':{'path':str(report),'bytes':report.stat().st_size,'sha256':sha(report),'prefixBytes':82236,'prefixSha256':hashlib.sha256(prefix).hexdigest()},'ownChecks':33,'metadata':{'files':metadata['fileCount'],'bytes':metadata['bytes'],'indexSha256':sha(b/'metadata-retention-index.json')},'external':{'files':external['fileCount'],'bytes':external['bytes'],'indexSha256':sha(b/'external-retention-index.json')},'notes':['Indices exclude their own recursive hash and separately bound completion','Raw logs copied to the new external root without changing originals','No host authenticity or new qualification claim']}
(b/'handoff-completion.json').write_text(json.dumps(completion,indent=2)+'\n');print(json.dumps(completion,indent=2))
