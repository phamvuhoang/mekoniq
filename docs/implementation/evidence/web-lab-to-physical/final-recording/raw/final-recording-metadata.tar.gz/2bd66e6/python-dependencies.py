import subprocess,json
from pathlib import Path
root=Path.cwd()
code="""import sys,json,importlib,importlib.metadata
modules={}
for name,dist in [('numpy','numpy'),('yaml','PyYAML'),('jsonschema','jsonschema'),('pytest','pytest'),('compiler.engineering_native',None),('bridge.protocol',None)]:
 try:
  module=importlib.import_module(name);modules[name]={'import':'ok','file':getattr(module,'__file__',None),'version':importlib.metadata.version(dist) if dist else None}
 except Exception as e: modules[name]={'import':'failed','type':type(e).__name__,'message':str(e)}
print(json.dumps({'python':sys.version,'executable':sys.executable,'modules':modules},indent=2))
"""
for name in ['.venv-irsim','.venv-commissioning']:
 print(name,flush=True)
 env=__import__('os').environ.copy();env['PYTHONPATH']=str(root/'robotics/simulation')+':'+str(root/'integrations/arm-controller')+':'+str(root/'robotics/agent')
 r=subprocess.run([str(root/name/'bin/python'),'-B','-c',code],env=env,capture_output=True,text=True,timeout=20);print(r.stdout,r.stderr,'exit',r.returncode,flush=True)
