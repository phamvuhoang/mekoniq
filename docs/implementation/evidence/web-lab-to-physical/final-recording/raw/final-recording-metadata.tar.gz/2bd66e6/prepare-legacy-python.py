from pathlib import Path
import os,subprocess,json,hashlib
root=Path.cwd();out=Path(__file__).parent
if os.path.lexists(root/'.venv'):raise SystemExit('REFUSE_NEWLY_APPEARED_VENV')
r=subprocess.run(['git','check-ignore','-v','.venv/probe'],capture_output=True,text=True,check=True);print(r.stdout,flush=True)
req=root/'robotics/simulation/requirements-dev.txt';print('requirementsSha256',hashlib.sha256(req.read_bytes()).hexdigest(),flush=True)
subprocess.run(['/opt/homebrew/bin/python3.11','-m','venv',str(root/'.venv')],check=True)
subprocess.run([str(root/'.venv/bin/python'),'-m','pip','install','-r',str(req)],check=True,timeout=180)
subprocess.run([str(root/'.venv/bin/python'),'-m','pip','check'],check=True)
code="import sys,json,importlib,importlib.metadata; import yaml,jsonschema,pytest,rfc8785,rfc3339_validator; print(json.dumps({'python':sys.version,'prefix':sys.prefix,'packages':{n:importlib.metadata.version(n) for n in ['pytest','rfc8785','jsonschema','rfc3339-validator','pyyaml']},'origins':{m.__name__:m.__file__ for m in [yaml,jsonschema,pytest,rfc8785,rfc3339_validator]}},indent=2))"
subprocess.run([str(root/'.venv/bin/python'),'-B','-c',code],check=True)
for cwd,imports in [('robotics/simulation','compiler.engineering_native'),('integrations/arm-controller','bridge.protocol')]:
 subprocess.run([str(root/'.venv/bin/python'),'-B','-c',f'import {imports} as m; print(m.__file__)'],cwd=root/cwd,check=True)
print('sourceStatus',subprocess.run(['git','status','--porcelain','--untracked-files=all'],capture_output=True,text=True,check=True).stdout)
