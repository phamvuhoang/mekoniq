from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root'])
commands=[('mock-regression','source',['env','LAB_PYTHON=/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/source/.venv-commissioning/bin/python','perl','-e','alarm 14400; exec @ARGV','node','../lab/scripts/record-regression.mjs','--suite','physical-robot-lab','--out',str(root/'mock-regression')]),('opt-in-stream-measurement','source',['env','LAB_V2_MEASURE='+str(root/'stream-measurement.json'),'perl','-e','alarm 400; exec @ARGV','pnpm','exec','vitest','run','tests/integration/lab-v2-stream.test.ts','-t','measure telemetry latency']),('source-adapters','source',['perl','-e','alarm 300; exec @ARGV','pnpm','test:adapters']),('source-security','source',['perl','-e','alarm 600; exec @ARGV','pnpm','test:security'])]
for name,repo,args in commands:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,repo,*args]);print(name,r,flush=True)
 if r and name=='mock-regression':print('REGRESSION_FAILURE_REQUIRES_INSPECTION; stopping further scheduled suites',flush=True);break
