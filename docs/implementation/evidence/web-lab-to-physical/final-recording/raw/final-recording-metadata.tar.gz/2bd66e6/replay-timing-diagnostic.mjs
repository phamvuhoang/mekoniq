import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {tsImport} from 'tsx/esm/api';
import {retainedInput,retainedInventory} from '../../../../../scripts/retained-inputs.mjs';
const base=dirname(fileURLToPath(import.meta.url)),paths=JSON.parse(await readFile(join(base,'paths.json'),'utf8')),out=join(paths.root,'replay-timing-diagnostic');await mkdir(out);
const events=[],stamp=()=>({epochMs:Date.now(),monotonicNs:process.hrtime.bigint().toString()}),emit=async row=>{events.push(row);await writeFile(join(out,'timing.json'),JSON.stringify(events,null,2));};
async function stage(id,fn){const before=stamp();try{const value=await fn();await emit({id,before,after:stamp(),status:'completed'});return value;}catch(e){await emit({id,before,after:stamp(),status:'failed',error:{name:e.name,message:e.message,stack:e.stack}});throw e;}}
const {createScenarioRun}=await tsImport('../../../../../packages/lab-runtime/src/v2/scenario-runner.ts',import.meta.url),{defaultCatalog}=await tsImport('../../../../../packages/lab-runtime/src/v2/capabilities.ts',import.meta.url),{amrAsset}=await tsImport('../../../../../tests/support/lab-v2.ts',import.meta.url),{exportWebReplay}=await tsImport('../../../../../packages/lab-runtime/src/v2/replay/export.ts',import.meta.url);
const original=await stage('verify-original',async()=>retainedInput('cell-nominal-7')),before=retainedInventory(original);await writeFile(join(out,'original-before.json'),JSON.stringify(before,null,2));const directory=join(out,'run');let run,opens=0;
try{
 await stage('copy',()=>cp(original,directory,{recursive:true,errorOnExist:true}));const copied=retainedInventory(directory);if(JSON.stringify(copied)!==JSON.stringify(before))throw Error('COPY_BYTES_MISMATCH');
 const cpState=JSON.parse(await readFile(join(directory,'run.json'),'utf8')),project=JSON.parse(await readFile(join(directory,'mujoco-world/bundle/project.json'),'utf8')),catalog={...defaultCatalog,backends:defaultCatalog.backends.map(b=>['mujoco_arm','mujoco_3d'].includes(b.id)?{...b,installed:true,compatible:true,reachable:true}:b)};
 run=await stage('open',()=>createScenarioRun({project,scenarioId:'MJ-CELL-BV01',scenarioRevision:1,seed:7,mode:'simulation',access:'simulated',backendSetId:'engineering-mujoco-cell-v1',sourceCommit:cpState.manifest.sourceCommit},{directory,catalog,assets:[amrAsset],enabledBackends:['mujoco_arm','mujoco_3d','mock_coffee'],worldPorts:async()=>{opens++;throw Error('RESPAWN_FORBIDDEN');}}));
 const [a,b]=await Promise.all([stage('capture-a',()=>run.captureReplay()),stage('capture-b',()=>run.captureReplay())]);if(opens||a.world.records.length!==10851||b.world.records.at(-1).snapshot.tick!==10850)throw Error('CAPTURE_ASSERTION');a.world.records[0].snapshot.robots[0].poseDriveMap[0]=999;if(b.world.records[0].snapshot.robots[0].poseDriveMap[0]===999)throw Error('CAPTURE_ALIAS');
 const manifest=await stage('export',()=>exportWebReplay(b,join(out,'export'))),report=await stage('report',()=>run.report());if(manifest.horizon.tick!==10850||report.outcome.tick!==10850)throw Error('EXPORT_REPORT_HORIZON');
 await writeFile(join(out,'result.json'),JSON.stringify({opens,recordsA:a.world.records.length,recordsB:b.world.records.length,horizon:manifest.horizon.tick,reportTick:report.outcome.tick,accepted:false},null,2));
}finally{if(run)await stage('close',()=>run.close());const after=await stage('verify-original-after',async()=>retainedInventory(original));await writeFile(join(out,'original-after.json'),JSON.stringify(after,null,2));if(JSON.stringify(before)!==JSON.stringify(after))throw Error('ORIGINAL_BYTES_CHANGED');}
