from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent; root=Path(json.loads((b/'paths.json').read_text())['root']);native=root/'native-empty';native.mkdir()
profiles=['mujoco-linux-amd64','mujoco-linux-arm64','engineering-amd64','engineering-arm64','xarm6-jazzy-sim']
def run(name,args):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source',*args]);print(name,r,flush=True);return r
for profile in profiles:
 handoff=root/('handoff-'+profile);out=root/('r3-'+profile+'-prepared')
 if not handoff.exists():
  if run('prepare-'+profile,['perl','-e','alarm 120; exec @ARGV','node',str(b/'assemble-prepared.mjs'),profile,str(handoff)]):continue
 if run('handoff-'+profile,['perl','-e','alarm 120; exec @ARGV','node','scripts/native-handoff.mjs','verify','--input',str(handoff)]):continue
 if run('record-r3-'+profile,['perl','-e','alarm 180; exec @ARGV','node','scripts/record-sim-extension.mjs','--release','r3','--handoff',str(handoff),'--native-records',str(native),'--profile',profile,'--scope','prepared','--out',str(out),'--candidate-id','r3-'+profile+'-final-bab05a5']):continue
 run('readback-r3-'+profile,['perl','-e','alarm 120; exec @ARGV','node','scripts/verify-r3.mjs',str(out)])
 run('acceptance-r3-'+profile,['env','LAB_SIMEXT_EVIDENCE_DIR='+str(out),'perl','-e','alarm 120; exec @ARGV','pnpm','test:acceptance','--','sim-extension'])
