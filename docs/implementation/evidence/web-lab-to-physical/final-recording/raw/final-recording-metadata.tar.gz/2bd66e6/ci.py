import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent
commands=[('entry-inventory',['node',str(b.parent/'inventory.mjs')]),('source-contracts',['perl','-e','alarm 120; exec @ARGV','pnpm','contracts:check']),('source-type',['perl','-e','alarm 300; exec @ARGV','pnpm','typecheck']),('source-lint',['perl','-e','alarm 300; exec @ARGV','pnpm','exec','eslint','.','--ignore-pattern','.superpowers/**']),('source-build',['perl','-e','alarm 900; exec @ARGV','pnpm','build']),('owned-source-ci',['perl','-e','alarm 30; exec @ARGV','node','scripts/owned-source-ci.mjs','--','pnpm','test'])]
for name,args in commands:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source',*args]);print(name,r,flush=True)
