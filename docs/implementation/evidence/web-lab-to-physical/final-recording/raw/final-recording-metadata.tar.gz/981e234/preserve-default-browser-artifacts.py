from pathlib import Path
import json,hashlib,shutil,datetime,subprocess
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';root=Path(json.loads((b/'paths.json').read_text())['root']);origin=lab/'test-results';dest=root/'r2a-supplemental-headless/default-artifacts-twin-polish';assert origin.is_dir() and not dest.exists()
def inventory(base):
 rows=[]
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():rows.append({'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mtimeNs':p.stat().st_mtime_ns})
 return rows
before=inventory(origin);shutil.copytree(origin,dest);assert inventory(origin)==before==inventory(dest)
raw=root/'r2a-supplemental-headless/suites/lab-e2e-twin-polish-twin-polish.json';j=json.loads(raw.read_text());receipt=json.loads((b/'checks/r2a-supplement-lab-e2e-twin-polish.receipt.json').read_text());assert receipt['exitCode']==1 and receipt['signal']==None
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original':str(origin),'copy':str(dest),'files':before,'rawResult':str(raw),'rawResultSha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'actualStats':j['stats'],'config':j.get('config'),'ownReceipt':'checks/r2a-supplement-lab-e2e-twin-polish.receipt.json','scope':'Settled actual default Playwright artifacts copied without modification; original paths in JSON remain unchanged; no product/test/config edit or retry','gitHeads':{name:subprocess.check_output(['git','rev-parse','HEAD'],cwd=path,text=True).strip() for name,path in [('source',source),('lab',lab)]}};(b/'twin-polish-default-artifact-preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'original':str(origin),'copy':str(dest),'files':before,'stats':j['stats'],'rawResultSha256':result['rawResultSha256']}))
