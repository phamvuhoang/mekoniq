from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent;source=b.parents[4];root=Path(json.loads((b/'paths.json').read_text())['root'])
def run(name,args,bound=14400):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
run('record-irsim',['node','scripts/record-irsim.mjs','--campaign','c02-qualification','--out',str(root/'irsim'),'--candidate-id','irsim-final-981e234','--irsim-python',str(source/'.venv-irsim/bin/python')])
run('verify-irsim-campaign',['node','scripts/lab-irsim.mjs','verify','--input',str(root/'irsim/campaign')],300)
run('acceptance-irsim',['env','LAB_IRSIM_EVIDENCE_DIR='+str(root/'irsim'),'pnpm','test:acceptance','--','linkforge-irsim'],300)
run('record-r1',['node','scripts/record-sim-extension.mjs','--release','r1','--out',str(root/'r1'),'--candidate-id','r1-final-981e234','--irsim-record',str(root/'irsim'),'--mock-regression',str(root/'mock-regression'),'--webots-home','/Applications/Webots.app','--webots-python',str(source/'.venv-webots/bin/python')],21600)
run('acceptance-r1',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(root/'r1'),'pnpm','test:acceptance','--','sim-extension'],300)
run('record-r11',['node','scripts/record-sim-extension.mjs','--release','r1.1','--out',str(root/'r11'),'--candidate-id','r11-final-981e234','--r1-record',str(root/'r1'),'--mock-regression',str(root/'mock-regression'),'--webots-home','/Applications/Webots.app','--webots-python',str(source/'.venv-webots/bin/python')],21600)
run('acceptance-r11',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(root/'r11'),'pnpm','test:acceptance','--','sim-extension'],300)
run('record-r2a-partial',['node','scripts/record-sim-extension.mjs','--release','r2a','--skip-suites','--out',str(root/'r2a-partial'),'--candidate-id','r2a-partial-final-981e234','--r11-record',str(root/'r11'),'--mock-regression',str(root/'mock-regression')],600)
run('acceptance-r2a-partial',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(root/'r2a-partial'),'pnpm','test:acceptance','--','sim-extension'],300)
