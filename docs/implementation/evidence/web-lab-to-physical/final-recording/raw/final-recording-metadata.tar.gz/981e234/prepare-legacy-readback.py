from pathlib import Path
import subprocess,json,hashlib,os,shutil,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];paths=json.loads((b/'paths.json').read_text());stage=json.loads((b/'legacy-stage-paths.json').read_text());root=Path(paths['root']);ops=[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(argv,cwd):
 r=subprocess.run(argv,cwd=cwd,text=True,capture_output=True,timeout=240,env={**os.environ,'GIT_LFS_SKIP_SMUDGE':'1'});ops.append({'argv':argv,'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,(argv,r.stdout,r.stderr);return r.stdout.strip()
for name,commit in [('source',stage['sourceCommit']),('lab',stage['labCommit'])]:
 target=Path(stage[name]);assert not target.exists();origin=active if name=='source' else active.parent/'lab'
 run(['git','clone','--shared','--no-checkout',str(origin),str(target)],Path(stage['root']));run(['git','checkout','--detach',commit],target)
 assert run(['git','rev-parse','HEAD'],target)==commit and not run(['git','status','--porcelain','--untracked-files=all'],target)
 assert not (target/'node_modules').exists();(target/'node_modules').symlink_to(origin/'node_modules',target_is_directory=True)
 assert sha(target/'pnpm-lock.yaml')==sha(origin/'pnpm-lock.yaml')
source=Path(stage['source']);lab=Path(stage['lab'])
identity=json.loads(run(['node','--input-type=module','-e',"const {checkedCheckerIdentity}=await import('./scripts/native-checker-bootstrap.mjs');process.stdout.write(JSON.stringify(await checkedCheckerIdentity()));"],source));assert identity=={'sourceCommit':stage['sourceCommit'],'toolSha256':'2d911a9d0028b12d0b6360b49170d77bbbe95b8ca2feed7cf5771ac3bef07ffe'}
deps=json.loads(run(['node','--input-type=module','-e',"import {createRequire} from 'node:module';import {readFileSync,realpathSync} from 'node:fs';const r=createRequire(process.cwd()+'/package.json');process.stdout.write(JSON.stringify({node:process.version,vitest:r.resolve('vitest/package.json'),vitestVersion:JSON.parse(readFileSync(r.resolve('vitest/package.json'))).version,tsx:r.resolve('tsx/esm/api'),nodeModules:realpathSync('node_modules')}));"],source));assert deps['node']=='v24.22.2'
assert run(['pnpm','--version'],source)=='10.32.1'
legacy={'irsim':'docs/implementation/evidence/linkforge-irsim/irsim','r1':'docs/implementation/evidence/sim-extension/r1','r11':'docs/implementation/evidence/sim-extension/r11'}
for rel in legacy.values():
 probe=subprocess.run(['git','cat-file','-e','HEAD:'+rel],cwd=source,capture_output=True,text=True);assert probe.returncode!=0 and not (source/rel).exists();ops.append({'argv':['git','cat-file','-e','HEAD:'+rel],'cwd':str(source),'exitCode':probe.returncode,'expected':'absent in immutable Git HEAD','stderr':probe.stderr})
def inventory(base):
 rows=[]
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink(),str(p)
  if p.is_file():rows.append({'path':p.relative_to(base).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
 return rows
copies=[]
for key in ['irsim','r1']:
 origin=root/key;dest=source/legacy[key];before=inventory(origin);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(origin,dest);assert inventory(origin)==before==inventory(dest);copies.append({'source':str(origin),'destination':str(dest),'files':before})
checked=[]
for rel in ['tests/acceptance/sim-extension.acceptance.test.ts','scripts/lab-irsim.mjs','scripts/sim-extension-qualification.mjs','scripts/irsim-qualification.mjs','scripts/r2b-readback.mjs','scripts/r3-readback.mjs','scripts/native-checker-bootstrap.mjs']:
 p=source/rel;blob=subprocess.check_output(['git','show','HEAD:'+rel],cwd=source);assert p.read_bytes()==blob;checked.append({'path':rel,'gitBlob':run(['git','rev-parse','HEAD:'+rel],source),'bytes':len(blob),'sha256':sha(p)})
status=run(['git','status','--porcelain','--untracked-files=all'],source);assert not run(['git','diff','HEAD','--name-only'],source)
for rel in run(['git','ls-files','--others','--exclude-standard'],source).splitlines():assert any(rel.startswith(legacy[k]+'/') for k in ['irsim','r1']),rel
result={'preparedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(source),'lab':str(lab),'sourceHead':stage['sourceCommit'],'labHead':stage['labCommit'],'sourceTree':run(['git','rev-parse','HEAD^{tree}'],source),'labTree':run(['git','rev-parse','HEAD^{tree}'],lab),'cleanCheckerIdentityBeforeStaging':identity,'dependencyResolution':deps,'dependencyPolicy':'Explicit reused existing node_modules via ignored symlinks, matching exact frozen lock bytes; no package install/download. Assessment/test code stays in exact isolated checkout. No independent host authenticity claim.','checkedCode':checked,'copies':copies,'actualSourceStatusAfterStaging':status,'executionLabel':'Readback from unchanged exact code with evidence-only staging; not clean production execution','ops':ops}
(b/'legacy-stage-preparation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'source':str(source),'lab':str(lab),'sourceHead':result['sourceHead'],'labHead':result['labHead'],'copiedFiles':sum(len(x['files']) for x in copies),'dependencies':deps,'trackedChanges':False,'stagedRoots':[c['destination'] for c in copies]}))
