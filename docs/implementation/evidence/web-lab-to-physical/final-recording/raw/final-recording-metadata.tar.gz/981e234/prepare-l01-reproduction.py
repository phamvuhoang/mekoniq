from pathlib import Path
import subprocess,json,hashlib,os,tempfile,shutil,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];root=Path(json.loads((b/'paths.json').read_text())['root']);out=root/'l01-reproduction';assert not out.exists();out.mkdir();checkout=Path(tempfile.mkdtemp(prefix='mekoniq-l01-exact-checker-'))/'source';commit='874d05aedfbf573496994fd73016f19ef19e6932';ops=[]
def run(argv,cwd):
 r=subprocess.run(argv,cwd=cwd,env={**os.environ,'GIT_LFS_SKIP_SMUDGE':'1'},text=True,capture_output=True,timeout=180);ops.append({'argv':argv,'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,(argv,r.stdout,r.stderr);return r.stdout.strip()
run(['git','clone','--shared','--no-checkout',str(active),str(checkout)],checkout.parent);run(['git','checkout','--detach',commit],checkout);assert not run(['git','status','--porcelain','--untracked-files=all'],checkout);(checkout/'node_modules').symlink_to(active/'node_modules',target_is_directory=True)
identity=json.loads(run(['node','--input-type=module','-e',"const {checkedCheckerIdentity}=await import('./scripts/native-checker-bootstrap.mjs');console.log(JSON.stringify(await checkedCheckerIdentity()));"],checkout));assert identity=={'sourceCommit':commit,'toolSha256':'f0052cf8449b7c978d432ead1c65a9ebfda784db166933ada3e9c6bba9f0557f'}
def inv(base):
 rows=[]
 for p in sorted(base.rglob('*')):
  assert not p.is_symlink(),p
  if p.is_file():rows.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 return rows
copies=[]
for name in ['handoff','native-not-run']:
 src=Path('/tmp/mekoniq-L01-fix2-preparation-sQ7TjS')/name;dest=out/name;before=inv(src);shutil.copytree(src,dest);assert before==inv(src)==inv(dest);copies.append({'source':str(src),'destination':str(dest),'files':before})
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(out/'handoff/manifest.json')=='d0016f8d04d9a2d6446d4e94722ace768957e64f8ea5c4f0b478a3783afa406c';assert digest(out/'native-not-run/manifest.json')=='2fc0b0d0958a2e37eee60bd8b1bf957779c2df3aedb8da478e000a4710c94e5f'
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checkout':str(checkout),'commit':commit,'tree':run(['git','rev-parse','HEAD^{tree}'],checkout),'checker':identity,'copies':copies,'dependencyReuse':{'nodeModulesSymlink':str(checkout/'node_modules'),'target':str(active/'node_modules'),'historicalLockSha256':digest(checkout/'pnpm-lock.yaml'),'installedLockSha256':digest(active/'pnpm-lock.yaml'),'policy':'Explicit existing dependency reuse, no install/download. Exact graph/source identity independently checked; not independent host authenticity.'},'status':run(['git','status','--porcelain','--untracked-files=all'],checkout),'ops':ops};assert not record['status'];(b/'l01-reproduction-preparation.json').write_text(json.dumps(record,indent=2)+'\n');(b/'l01-reproduction-paths.json').write_text(json.dumps({'source':str(checkout),'out':str(out)},indent=2)+'\n');print(json.dumps({'source':str(checkout),'out':str(out),'checker':identity,'files':sum(len(c['files']) for c in copies)}))
