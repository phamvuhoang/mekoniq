import {SUITES_R2A} from '../../../../../scripts/sim-extension-qualification.mjs';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {dirname,resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const base=dirname(fileURLToPath(import.meta.url)),source=resolve(base,'../../../../..'),lab=resolve(source,'../lab'),paths=JSON.parse(readFileSync(join(base,'paths.json'))),out=join(paths.root,'r2a-supplemental-continuation'),prior=join(paths.root,'r2a-supplemental-headless/execution-index.json');
if(existsSync(out))throw Error('OUT_EXISTS');
mkdirSync(out);mkdirSync(join(out,'suites'));mkdirSync(join(out,'screens'));mkdirSync(join(out,'pycache'));
const table=readFileSync(join(source,'scripts/sim-extension-qualification.mjs'));
writeFileSync(join(out,'table.json'),JSON.stringify({sourceSha256:createHash('sha256').update(table).digest('hex'),suites:SUITES_R2A},null,2));
const previous=JSON.parse(readFileSync(prior)),seen=new Set(previous.map(r=>r.id));if(seen.size!==previous.length)throw Error('PRIOR_DUPLICATE_ROWS');
const remaining=SUITES_R2A.filter(s=>!seen.has(s.id));writeFileSync(join(out,'continuation-plan.json'),JSON.stringify({prior,priorSha256:createHash('sha256').update(readFileSync(prior)).digest('hex'),remaining:remaining.map(s=>s.id),allTableRows:SUITES_R2A.map(s=>s.id),scope:'Original stopped index/own1 immutable. This invocation runs only remaining default-config mock rows with existing LAB_PW_OUTPUT_DIR; provider rows await checked fresh isolated boundary.'},null,2));
const results=[];
for(const s of remaining.filter(s=>s.command?.[0]==='scripts/test-mock-e2e.mjs')){
 if((s.command??[]).includes('webots')){results.push({id:s.id,repo:s.repo,kind:s.kind,command:s.command,status:'not_run',reason:'Current ordinary record-r11 preflight refused SCREEN_LOCKED; no repeat GUI invocation absent external-state change',prerequisiteReceipt:join(base,'checks/record-r11.receipt.json')});continue;}
 if(s.image){results.push({id:s.id,status:'not_run',reason:'Latest owned Docker inventory failed; no repeated probe or image build allowed absent state change'});continue;}
 const cwd=s.repo==='lab'?lab:source,abs=join(out,'suites',s.id+(s.kind==='pytest'?'.xml':'.json')),shots=join(out,'screens',s.id);mkdirSync(shots);
 const webots={MEKONIQ_WEBOTS_HOME:'/Applications/Webots.app'};
 const env=s.kind==='vitest'?{LAB_V2_CLEAN_EXPORT:'1',...webots}:s.kind==='pytest'?{PYTHONPATH:(s.pythonPath??[]).map(p=>join(source,p)).join(':'),PYTHONDONTWRITEBYTECODE:'1',PYTHONPYCACHEPREFIX:join(out,'pycache'),PYTHONNOUSERSITE:'1',...webots}:{LAB_PW_JSON:abs,LAB_PW_OUTPUT_DIR:join(out,'playwright',s.id),LAB_IRSIM_SCREENSHOTS:shots,LAB_EVIDENCE_DIR:shots,...webots};
 const command=s.kind==='vitest'?[process.execPath,join(cwd,'node_modules/vitest/vitest.mjs'),'run',...s.files,'--reporter=json','--outputFile='+abs,'--reporter=default']:s.kind==='pytest'?[join(source,s.python),'-m','pytest','-p','no:cacheprovider',...s.files,'-q','--junitxml='+abs]:[process.execPath,...s.command.map(a=>a.endsWith('.mjs')?join(cwd,a):a)];
 const argv=['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT',...Object.entries(env).map(([k,v])=>k+'='+v),'caffeinate','-dims','perl','-e','alarm 3600; exec @ARGV',...command];
 const r=spawnSync('python3',[join(base,'run.py'),'r2a-continuation-'+s.id,s.repo,...argv],{stdio:'inherit'});
 results.push({id:s.id,repo:s.repo,kind:s.kind,files:s.files??null,command,cwd,env,exitCode:r.status,signal:r.signal,declaredResult:abs,actualResults:[abs,...s.kind==='playwright'&&s.command?.[0]==='scripts/test-mock-e2e.mjs'?[abs.replace(/\.json$/,`-${s.command.at(-1).replace(/\.spec\.ts$/,'')}.json`)]:[]].filter(p=>existsSync(p))});
 writeFileSync(join(out,'execution-index.json'),JSON.stringify(results,null,2));
 console.log('SUPPLEMENT',s.id,r.status);
 if(r.status) {writeFileSync(join(out,'needs-inspection.json'),JSON.stringify(results.at(-1),null,2));process.exit(1);}
}
writeFileSync(join(out,'execution-index.json'),JSON.stringify(results,null,2));
