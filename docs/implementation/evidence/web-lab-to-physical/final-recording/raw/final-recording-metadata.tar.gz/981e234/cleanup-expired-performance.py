from pathlib import Path
import subprocess,json,os,signal,datetime,time
b=Path(__file__).resolve().parent;old=json.loads((b/'production-performance-ownership-before-disposition.json').read_text());start=json.loads((b/'production-performance-wrapper-live-start.json').read_text());expected={r['pid']:r for r in old['hierarchy']};starts={int(a[0]):' '.join(a[3:8]) for line in start['stdout'].splitlines() if len(a:=line.split())>=10};offset=datetime.datetime.fromisoformat(start['observedAtLocal']).tzinfo;originalStart=datetime.datetime.strptime(starts[50786],'%a %b %d %H:%M:%S %Y').replace(tzinfo=offset);deadline=originalStart.timestamp()+start['boundSeconds']
assert time.time()>=deadline+2,'ORIGINAL_BOUND_NOT_YET_EXPIRED'
excluded={50741,50751,50786,50787};history=[];events=[];known={}
def ps():
 rows={}
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,lstart=,stat=,command='],text=True).splitlines():
  a=line.split(None,9)
  if len(a)==10:rows[int(a[0])]={'pid':int(a[0]),'ppid':int(a[1]),'pgid':int(a[2]),'start':' '.join(a[3:8]),'state':a[8],'command':a[9]}
 return rows

def refresh(label):
 allRows=ps();valid={}
 for pid,row in expected.items():
  now=allRows.get(pid)
  if now and 'Z' not in now['state'] and now['start']==starts[pid] and now['command']==row['command']:valid[pid]=now;known[pid]=now
 for pid,row in list(known.items()):
  now=allRows.get(pid)
  if now and 'Z' not in now['state'] and now['start']==row['start'] and now['command']==row['command']:valid[pid]=now
 # Only new children of a currently validated owned descendant qualify.
 while True:
  new=[r for r in allRows.values() if r['ppid'] in valid and r['ppid'] not in excluded and r['pid'] not in valid and 'Z' not in r['state']]
  if not new:break
  for r in new:valid[r['pid']]=r;known[r['pid']]=r
 history.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stage':label,'validatedOwned':list(valid.values()),'protectedOriginalWrapperRows':[allRows[p] for p in excluded if p in allRows]});return {p:r for p,r in valid.items() if p not in excluded}

def send(pid,sig):
 now=refresh('revalidate-before-'+str(pid));row=now.get(pid)
 if not row:events.append({'pid':pid,'signal':sig.name,'sent':False,'reason':'not a live revalidated owned descendant'});return
 try:os.kill(pid,sig);sent=True;reason=None
 except ProcessLookupError:sent=False;reason='already exited'
 events.append({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':pid,'signal':sig.name,'sent':sent,'reason':reason,'matchedStart':row['start'],'matchedCommand':row['command']})

def wait(seconds):
 until=time.monotonic()+seconds
 while time.monotonic()<until:
  if not refresh('bounded-wait'):return
  time.sleep(.5)

before=refresh('after-original-bound');interventionAt=datetime.datetime.now(datetime.timezone.utc).isoformat();send(50794,signal.SIGINT);wait(8)
if refresh('after-measure-grace'):
 send(50835,signal.SIGINT);send(50841,signal.SIGTERM);wait(12)
for pid in refresh('before-term-escalation'):send(pid,signal.SIGTERM)
wait(8)
for pid in refresh('before-kill-escalation'):send(pid,signal.SIGKILL)
wait(3);remaining=refresh('final')
out={'originalBoundSeconds':start['boundSeconds'],'originalPnPmOSStart':originalStart.isoformat(),'boundExpiryEpochMs':int(deadline*1000),'interventionAtUTC':interventionAt,'before':list(before.values()),'events':events,'history':history,'remainingOwnedDescendants':list(remaining.values()),'scope':'Bounded cleanup only after unchanged original deadline; exact start+command ownership and live ancestry checked before every signal. Original wrapper/check/pnpm/caffeinate not signaled. No private-state reads, product edits, bound changes or retries.','qualification':'incomplete; no post-intervention output promoted','outerExecSession':80574};p=b/'production-performance-deadline-cleanup.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'events':events,'remainingOwnedPids':list(remaining),'qualification':out['qualification']}));raise SystemExit(bool(remaining))
