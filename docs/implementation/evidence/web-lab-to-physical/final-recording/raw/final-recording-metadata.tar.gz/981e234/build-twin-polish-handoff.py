from pathlib import Path
import json,hashlib,subprocess,shutil,datetime
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';root=Path(json.loads((b/'paths.json').read_text())['root']);out=b/'twin-polish-handoff';assert not out.exists();(out/'snapshots').mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['tests/e2e/twin-polish.spec.ts','tests/support/twin.ts','src/ui/run-bar.ts','src/styles/main.css','playwright.config.ts','playwright.irsim.config.ts','playwright.b07b.config.ts','scripts/test-mock-e2e.mjs','scripts/start-mock.mjs','scripts/measure-cell-production.ts','config/source-runtime.lock.json'];snap=[]
for rel in files:
 p=lab/rel;q=out/'snapshots'/('lab--'+rel.replace('/','--'));data=p.read_bytes();blob=subprocess.check_output(['git','show','HEAD:'+rel],cwd=lab);assert data==blob;q.write_bytes(data);baseline=subprocess.run(['git','show','a7449541e118d01f65af0ad1466e0c963a173f3c:'+rel],cwd=lab,capture_output=True);snap.append({'repository':'lab','path':rel,'snapshot':str(q.relative_to(out)),'bytes':len(data),'sha256':sha(p),'gitBlob':subprocess.check_output(['git','rev-parse','HEAD:'+rel],cwd=lab,text=True).strip(),'frozenUpstreamExists':baseline.returncode==0,'frozenUpstreamBytes':len(baseline.stdout) if baseline.returncode==0 else None,'frozenUpstreamSha256':hashlib.sha256(baseline.stdout).hexdigest() if baseline.returncode==0 else None,'sameAsFrozenUpstream':data==baseline.stdout if baseline.returncode==0 else None})
rel='scripts/browser-evidence-readback.mjs';p=source/rel;q=out/'snapshots'/'source--scripts--browser-evidence-readback.mjs';assert p.read_bytes()==subprocess.check_output(['git','show','HEAD:'+rel],cwd=source);shutil.copy2(p,q);snap.append({'repository':'source','path':rel,'snapshot':str(q.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p),'gitBlob':subprocess.check_output(['git','rev-parse','HEAD:'+rel],cwd=source,text=True).strip()})
raw=root/'r2a-supplemental-headless/suites/lab-e2e-twin-polish-twin-polish.json';j=json.loads(raw.read_text());fail=[]
def walk(suites):
 for s in suites:
  for spec in s.get('specs',[]):
   for t in spec.get('tests',[]):
    for r in t.get('results',[]):
     if r.get('status')!='passed':fail.append({'title':spec['title'],'file':spec['file'],'line':spec['line'],'status':r['status'],'durationMs':r['duration'],'errors':r.get('errors'),'attachments':r.get('attachments')})
  walk(s.get('suites',[]))
walk(j['suites']);receipts={}
for name in ['r2a-supplemental-driver','r2a-supplement-lab-e2e-twin-polish','preserve-twin-polish-default']:
 p=b/'checks'/f'{name}.receipt.json';r=json.loads(p.read_text());receipts[name]={k:r[k] for k in ['argv','cwd','startedAt','finishedAt','exitCode','signal','before','after','logSha256']}
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'labCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab,text=True).strip(),'actualStats':j['stats'],'failureRows':fail,'observedHeightsPx':{'wide':48,'width1024Height700':98},'assertionDurationMs':98,'receipts':receipts,'rawResult':str(raw),'rawResultSha256':sha(raw),'preservedDefaultArtifacts':json.loads((b/'twin-polish-default-artifact-preservation.json').read_text()),'snapshots':snap,'interpretation':'Actual complete serial token-owned mock file failed its final1024 one-row assertion. No cause assigned, retry, test/product/config/threshold edit or new campaign. Earlier unpaired broad file skipped this token-gated scope; retain actual reports separately.'};(out/'actual-failure.json').write_text(json.dumps(summary,indent=2)+'\n')
# Exact installed primary implementation excerpts and origins; not a claimed global env override.
primary=lab/'node_modules/.pnpm/playwright@1.64.1/node_modules/playwright/lib';excerpts=[]
for rel,start,end in [('common/index.js',580,594),('program.js',198,209),('runner/index.js',1532,1553),('runner/index.js',6795,6807)]:
 p=primary/rel;lines=p.read_text().splitlines();excerpts.append({'path':str(p),'fileSha256':sha(p),'lines':{'start':start,'end':end},'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(start,end+1))})
(out/'output-boundary-primary-source.json').write_text(json.dumps({'version':'playwright1.64.1','excerpts':excerpts,'findings':['default playwright.config.ts already supports LAB_PW_OUTPUT_DIR; supplemental invocation omitted it','irsim and b07b configs have no outputDir/env override','pinned core uses CLI/project/config/default test-results outputDir; reporter output env and last-run env do not override failure artifact directory','closed browser directory reader requires exact producer argv; no added flags/preload/monkeypatch authorized'],'proposedBoundary':'Future default/mock rows can supply existing LAB_PW_OUTPUT_DIR. Unchanged irsim/closed producer can use fresh isolated exact paired producer with hash-identical dist/runtime and explicit dependencies; must retain actual default-path use, producer/host/environment identity and clean tracked trees.'},indent=2)+'\n')
(out/'README.md').write_text('''# Actual supplemental twin-polish failure and output-boundary handoff

No retry or product/test/config/threshold edits. The owned driver stopped naturally on the first nonzero row; remaining rows are pending. Source981e234/Lab b0fcede unchanged. `actual-failure.json` retains full failing row/errors, own receipts/argv/cwd/times and original→copy artifact hash map. `snapshots/` contains complete exact Git bytes for the serial test/setup, runbar/style, launcher/config and closed producer/reader; `snapshots` rows also compare frozen Lab a744 bytes without assigning cause.

Actual ten-test serial paired-runtime file:9passed/1failed, no skipped/flaky. At1024×700, runbar48px at wide viewport becomes98px; assertion execution duration98ms is separate. The PNG visibly has two rows, VI coffee/mock needs_attention state. Earlier unpaired broad scope skipped this token-gated describe; it is not proof this token-owned serial flow passed. Original raw Playwright JSON and its attachment paths are not rewritten.

Fresh external byte-verified default-artifact copy is under `r2a-supplemental-headless/default-artifacts-twin-polish` at the current external root. It contains the actual .last-run, PNG and error-context. No browser may reuse original Lab/test-results before this copy and inventory were verified; that preservation completedown0. Root triages actual layout policy/mechanism versus inherited assertions before any correction.

`output-boundary-primary-source.json` records installed pinned primary source excerpts and code/config hashes. Existing LAB_PW_OUTPUT_DIR covers default config only. No assumed global env, CLI injection or monkeypatch is proposed. The unchanged closed browser producer/reader exact argv requires a real fresh isolated default-output boundary if no supported override exists. Production/stock capture waits root disposition; independent doc preparation continues.
''')
rows=[]
for p in sorted(out.rglob('*')):
 if p.is_file():rows.append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)})
(out/'index.json').write_text(json.dumps({'files':rows,'scope':'Complete current narrow handoff before any correction; original outputs unchanged'},indent=2)+'\n');print(json.dumps({'handoff':str(out),'files':len(rows),'indexBytes':(out/'index.json').stat().st_size,'indexSha256':sha(out/'index.json')}))
