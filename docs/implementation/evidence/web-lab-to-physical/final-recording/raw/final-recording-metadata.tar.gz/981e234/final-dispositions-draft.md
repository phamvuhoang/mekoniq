# Draft final dispositions — refresh after recordings

This draft is not a completion verdict. The full task reviews, root dispositions and central deferred ledger remain authoritative. Original failures and their producer identities stay unchanged. Root performs the final whole-branch triage.

| Item | Concrete disposition and remaining boundary |
|---|---|
| B02b mobile README wording | Resolved by the reviewed B00R documentation. Historical Python-only scope is labeled historical. |
| B00R wrong touch harness | Retained failed historical invocation; corrected owned mock harness passed7. No retrospective pass assigned to the failed invocation. |
| B00R process lifecycle | Reviewed helper supports direct local asynchronous roots on Node24.22.2. Synchronous/subprocess/worker-thread creators require separate integration; historical unknown global-kill targets remain unknown. |
| B04a dense payload verifier | Deferred maintenance. Current behavior is reviewed; no extraction/refactor was performed in final recording. |
| B04a PAYLOAD_FALL console output | Retain as historical diagnostic output, not an additional retained physics artifact or qualification case. Current19case production campaign has its own raw reports/traces and public verification. |
| B04b / B07b color warnings | Owning invocation normalization was addressed in B10; old successful logs retain their NO_COLOR/FORCE_COLOR noise. No physics rerun was used to erase warnings. |
| B04b generic legacy arm block | Historical UI scope/readability observation remains a final-review concern; real mobile physics must not be described as absent merely because an arm verification block is unavailable. No new product wording fix is claimed. |
| B04b narrow assertion table | Readability observation remains distinct from evidence values. Current screenshot observations must be reported at their actual viewport/case; no general readability closure inferred. |
| B05 focused timeout | Original107pass/1timeout and exact349ms follow-up remain. Current complete mock is separate new-subject evidence; no root cause assigned to the historical timeout. |
| B05 vendor NOTICE | Eleven inherited whitespace warnings remain in byte-identical licensed material. Authored lint is separate; vendor bytes were not normalized. |
| B06 report publication | Closed by reviewed in-process coalescing fix, not a cross-process/global writeDurable lock. Later exporters own their own concurrency. |
| B06 old performance | Historical .608/.590/.591× end-to-end observations retain their old scope. Final production/browser metrics require their actual new capture; do not substitute batch means or RAF. |
| B06 broader6mm geometry | General navigation robustness is limited: the broader offset model failure is not covered by three nominal seeds or simulation/hardware calibration. |
| B07a retained /tmp inputs | Closed by reviewed digest-bound three-input preparation/catalog selectors with explicit missing/wrong-byte refusal. Retained expected export manifest is declared, not a hidden workstation fallback. |
| B07a public held-response close / R63 | Closed by B09 reviewed drain/stop/data-root ordering at its tested process/protocol/Mac scopes. Actual unavailable WEB05/container behavior remains separate. |
| B07b clock/window evidence | B10 reviewed producer/consumer now bind epochs/windows/action IDs and actual observations. Preparation tests do not themselves prove a final measured capture. Refresh this row with actual current capture/readback. |
| B07b JSON/build warnings | B10 runner/import normalization plus correction3's19JSON attributes across6Lab modules are reviewed. Preserve original warning logs and final actual build receipts. |
| B07b extra390px stripe | Original image has no simultaneous DOM evidence and cause remains unproved. Refresh with final exact390 live-report DOM/header count/PNG; no compositor or product-duplication cause assumed. |
| B08 stale-seal negatives | I1 closed through review3 and nine coherent profile/model mutations; B10 also adds coherent goal/frame coverage. Wider stale-seal/adjacent-physics negative precision remains deferred; integrity-corruption checks are not mislabeled semantic checks. |
| L00 negative provenance seals | Nonblocking test-precision observation remains deferred where resealing was not done. No blanket claim that every refusal isolates the intended predicate. |
| L01 lift threshold | Reviewed B10 fix preserves frozen0.14m acceptance distinct from0.15m command. Historical exact874/f005 readback reproduced honest not_qualified, not native execution. |
| L02 historical lint | Scoped configuration fixes actual CommonJS/Node environment for five unchanged historical files. Current authored full lint own0 is separate from earlier27errors; old bytes/logs are retained. |
| L03 rounded negative zero | Deferred conservative false refusal for equivalent -0/-0e0 offsets in Python mapping. Pinned vendor emits positive zero; no native capability or fix claimed. |
| L03 native X1/X2/X3 | Unmet qualification gates, not a deferred code Minor: actual expansion/motion/fault/stop/controller restart/contact trials require matching assigned host or observed unsupported disposition. |
| L04 large imported traces | Deferred capacity mismatch: admitted100000samples can exceed RTB10000poses/1MiB request. Ordinary short captures do not establish the larger capacity. No batched-oracle fix claimed. |
| B10 marketing link | Pending actual final replacement and normal sibling-clone audit. Local read-only Git proof binds exact web e8d7639 index.html/90841c4b…; preserve2026-10-30 producer/2026-11-14 observation and do not publish marketing. |
| L06 arm64 blocker M1 | Closed separately in correction1: case/blocked row/native gate now name absent host artifacts and missing arm64 adapter. Adapter remains absent; a host alone cannot close it. |
| R2b cloud payload coupling | Existing mj-evidence includes cloud HTTP payload security hooks. No owned service receipt means refused hooks/not_run; successful local19case physics cannot close all G-MJ1. Table coupling remains for whole-branch review, unchanged. |
| Cold-reclaim expiry | Review4 static observation deferred: requester checked before asynchronous work, no demonstrated unauthorized mutation. Root whole-branch triage assesses policy; priority-control fix's execution-time checks are separate. |
| Inherited malformed JUnit | Actual stored hostname="<host>" XML is not parseable by standard XML; regex counters/hash readback and actual pytest exits remain separately observed. No XML repair or valid-JUnit claim; whole-branch reviewer assesses interoperability/contract impact. |
| Legacy fixed upstream paths | Original R1 public guard11/1 retained. Exact paired isolated staging of actual upstream bytes yields unchanged complete12/0 at that fixture layout. Not clean producer execution or arbitrary-layout portability fix. |
| Current SCREEN_LOCKED | Actual R1.1 preflight own2/no candidate remains. Webots semantic/lineage stages await reported external state change; no unlock/settings operation, old candidate substitution or blind retry. Refresh final status when actual work settles. |

All prepared R3 profiles remain accepted:false/not_calibrated. Missing matching host/image/package inventories, unsupported TF/UUID/controller/clock/security capabilities, actual native/physical motion, calibration and human acceptance stay explicit. Doctor, protocol doubles, numeric FK subsets, archive integrity or a native_capture label cannot close them.
