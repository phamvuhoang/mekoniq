import {readFile} from 'node:fs/promises';import {createServer} from 'node:net';
const config=await readFile('supabase/config.toml','utf8'),ports=[...new Set([...config.matchAll(/^\s*port\s*=\s*(\d+)/gm)].map(m=>Number(m[1])))],servers=[];
console.log(JSON.stringify({ports}));
const timer=setTimeout(()=>{console.log('DIAGNOSTIC_DEADLINE');for(const s of servers)s.close();process.exitCode=2;},3000);
try{for(const port of ports){console.log('BEFORE_BIND',port);const s=createServer();s.on('error',e=>console.log('SERVER_ERROR',port,e.code));await new Promise((ok,fail)=>{s.once('error',fail);s.listen(port,'127.0.0.1',ok);});servers.push(s);console.log('BOUND',port);}}
catch(e){console.log('CAUGHT',e.code);}
finally{for(const s of servers){console.log('BEFORE_CLOSE',s.address());await new Promise(r=>s.close(()=>{console.log('CLOSED');r();}));}clearTimeout(timer);console.log('DONE');}
