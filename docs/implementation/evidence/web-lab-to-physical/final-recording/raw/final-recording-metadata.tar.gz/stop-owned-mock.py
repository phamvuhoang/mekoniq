import subprocess,os,signal,time,json
root_pid=63988
rows={}
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
 p=line.strip().split(None,2)
 if len(p)==3: rows[int(p[0])]={'pid':int(p[0]),'ppid':int(p[1]),'command':p[2]}
root=rows.get(root_pid)
if not root or not root['command'].startswith('node ../lab/scripts/record-regression.mjs --suite physical-robot-lab --out /var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-6e5eee9-aricgzue/mock-regression'):raise SystemExit('OWNERSHIP_NOT_PROVED')
os.kill(root_pid,signal.SIGSTOP)
owned=[root_pid]
for pid in owned:
 owned.extend(r['pid'] for r in rows.values() if r['ppid']==pid and r['pid'] not in owned)
print(json.dumps({'proof':root,'ownedSnapshot':[rows[x] for x in owned],'cleanup':'signal only verified descendant hierarchy; parent frozen before cleanup'}))
for pid in reversed(owned):
 try:os.kill(pid,signal.SIGINT)
 except ProcessLookupError:pass
os.kill(root_pid,signal.SIGCONT)
time.sleep(2)
left=[]
for pid in owned:
 try:os.kill(pid,0);left.append(pid)
 except ProcessLookupError:pass
for pid in left:
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
print(json.dumps({'remainingAfterINT':left,'termOnlyTheseOwnedPids':left}))
