import {mkdtempSync,mkdirSync,writeFileSync,readFileSync,existsSync} from 'node:fs';import {join} from 'node:path';import {tmpdir} from 'node:os';import {spawnSync} from 'node:child_process';
const base=mkdtempSync(join(tmpdir(),'final-ci-conflict-test-'));mkdirSync(join(base,'bin'));const marker=join(base,'pnpm-called.ndjson');
const stub=`#!/bin/sh\nprintf '%s\\n' \"$*\" >> '${marker}'\nexit 2\n`;
writeFileSync(join(base,"bin/pnpm"),stub,{mode:0o755});writeFileSync(join(base,"bin/docker"),`#!/bin/sh\nprintf '%s\\n' '{"ID":"existing-unrelated","Ports":"0.0.0.0:57422->5432/tcp"}'\n`,{mode:0o755});
const r=spawnSync(process.execPath,['scripts/owned-source-ci.mjs','--',process.execPath,'-e','process.exit(0)'],{cwd:process.cwd(),env:{...process.env,PATH:join(base,'bin')+':'+process.env.PATH},encoding:'utf8',timeout:5000});const calls=existsSync(marker)?readFileSync(marker,'utf8'):'';
console.log(JSON.stringify({base,childOwnExit:r.status,signal:r.signal,error:r.error?.message,stdout:r.stdout,stderr:r.stderr,pnpmCalls:calls,scope:'owned fake Docker/PNPM only; no services invoked'}));
if(calls.includes('supabase start'))throw Error('PORT_CONFLICT_REACHED_SUPABASE_START');if(r.status===0)throw Error('CONFLICT_NOT_REFUSED');
