import {readFileSync,writeFileSync,readdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual as same} from 'node:util';
import {pathToFileURL} from 'node:url';
const source=process.cwd(),lab=resolve(source,'../lab'),base=resolve('.superpowers/sdd/README/evidence-final-recording/fix1'),sha=b=>createHash('sha256').update(b).digest('hex'),read=p=>JSON.parse(readFileSync(p));
const assert=(v,m)=>{if(!v)throw Error(m);},git=(cwd,...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim(),write=(p,v)=>writeFileSync(join(base,p),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
const trees=[];for(const [name,cwd,from]of [['source',source,'6e5eee9d7d504b0365422eb0ef7096e74e72e210'],['lab',lab,'283696be56bdaea1d310a1e56182f49792cf3b2c']]){
 const status=git(cwd,'status','--porcelain','--untracked-files=all'),head=git(cwd,'rev-parse','HEAD');assert(!status,name+' dirty');assert(git(cwd,'branch','--show-current')==='codex/web-lab-to-physical','branch');
 const patch=execFileSync('git',['diff','--binary','--no-renames',from,head],{cwd});writeFileSync(join(base,name+'-fix-base.patch'),patch,{flag:'wx'});
 const files=git(cwd,'diff','--name-only',from,head).split('\n').filter(Boolean).map(path=>{const b=readFileSync(join(cwd,path));assert(b.equals(execFileSync('git',['show',head+':'+path],{cwd})),name+': HEAD bytes '+path);return {path,bytes:b.length,sha256:sha(b)};});trees.push({name,base:from,head,tree:git(cwd,'rev-parse','HEAD^{tree}'),status,patchBytes:patch.length,patchSha256:sha(patch),files});
}
const manifest=read(join(base,'export-final/manifest.json')),pin=read(join(lab,'config/source-runtime.lock.json')),installed=read(join(lab,'.runtime',pin.artifactSha256,'manifest.json'));
assert(manifest.dirty===false&&pin.dirty===false&&same(manifest,installed),'clean manifest');assert(manifest.sourceCommit===trees[0].head&&pin.sourceCommit===trees[0].head&&pin.schemaHash===manifest.schemaHash&&pin.artifactSha256===manifest.artifactSha256&&pin.portableToolsDigest===manifest.portableSimulationTools.closure.digest,'pin identity');
for(const p of [join(base,'export-final/runtime.mjs'),join(lab,'.runtime',pin.artifactSha256,'runtime.mjs')])assert(sha(readFileSync(p))===pin.artifactSha256,'runtime hash');
const old=read(resolve('.superpowers/sdd/02-r2b-cell-and-web/evidence-B10/fix1/export-final2/manifest.json'));assert(same(old.nativeTools,manifest.nativeTools)&&same(old.portableSimulationTools,manifest.portableSimulationTools),'closure changed');
for(const n of manifest.schemas)assert(readFileSync(join(base,'export-final/schemas',n)).equals(readFileSync(join(source,'packages/contracts/schemas',n))),'schema bytes');
for(const f of [...manifest.nativeTools.files,...manifest.portableSimulationTools.closure.files]){const b=readFileSync(join(source,f.path));assert(b.length===f.bytes&&sha(b)===f.sha256,'closure source bytes '+f.path);}
const preservation=[];for(const name of ['root-B10-evidence-file-index.json','root-B10-r1-evidence-file-index.json','root-B10-smoke-27d6be9-file-index.json']){const index=read(resolve('.superpowers/sdd/02-r2b-cell-and-web',name));for(const f of index.files){const b=readFileSync(join(index.root,f.path));assert(b.length===f.bytes&&sha(b)===f.sha256,'preservation '+name+': '+f.path);}preservation.push({index:name,root:index.root,files:index.files.length,verified:true});}
const priorIndex=read(resolve('.superpowers/sdd/03-r3-linux-readiness/root-L06-evidence-file-index.json'));
for(const f of priorIndex.files){const b=readFileSync(join(priorIndex.root,f.path));assert(b.length===f.bytes&&sha(b)===f.sha256,'L06 preservation '+f.path);}
preservation.push({index:'root-L06-evidence-file-index.json',root:priorIndex.root,files:priorIndex.files.length,verified:true});
const priorFixIndex=read(resolve('.superpowers/sdd/03-r3-linux-readiness/root-L06-r1-evidence-file-index.json'));
for(const f of priorFixIndex.files){const b=readFileSync(join(priorFixIndex.root,f.path));assert(b.length===f.bytes&&sha(b)===f.sha256,'L06 fix preservation '+f.path);}
preservation.push({index:'root-L06-r1-evidence-file-index.json',root:priorFixIndex.root,files:priorFixIndex.files.length,verified:true});
const prefix=readFileSync(join(base,'report-prefix.txt'));
assert(readFileSync(resolve('.superpowers/sdd/README/task-final-recording-report.md')).subarray(0,prefix.length).equals(prefix),'final report prefix');
const checks=[];for(const name of readdirSync(join(base,'checks')).filter(n=>n.endsWith('.receipt.json')).sort()){
 const p=join(base,'checks',name),r=read(p),log=readFileSync(p.replace('.receipt.json','.log'));assert(sha(log)===r.logSha256,'receipt log '+name);checks.push({receipt:'checks/'+name,receiptSha256:sha(readFileSync(p)),exitCode:r.exitCode,argv:r.argv,cwd:r.cwd,source:r.before.commit,stableCommit:r.before.commit===r.after.commit,logSha256:r.logSha256});
}
write('check-index.json',checks);
const {checkedCheckerIdentity}=await import(pathToFileURL(join(source,'scripts/native-checker-bootstrap.mjs'))),checker=await checkedCheckerIdentity();
const result={status:'TOOLING_ONLY_FINAL_RECORDING_PENDING',trees,pin,checker,runtimeSha256:pin.artifactSha256,schemaHash:manifest.schemaHash,schemaCount:manifest.schemas.length,nativeClosure:{digest:manifest.nativeTools.digest,files:manifest.nativeTools.files.length},portableClosure:{digest:manifest.portableSimulationTools.closure.digest,files:manifest.portableSimulationTools.closure.files.length},exportManifestSha256:sha(readFileSync(join(base,'export-final/manifest.json'))),preservation,originalReportPrefix:{bytes:prefix.length,sha256:sha(prefix)},checks:checks.length,limits:['No native/browser/physical execution or final candidate recording','Checker and subject/publication identities remain separate','Byte audit does not authenticate host or execution']};
write('final-byte-attribution.json',result);console.log(JSON.stringify({...result,trees:trees.map(t=>({...t,files:t.files.length}))},null,2));
