# Final B10/L06 recording — append-only work log

Producer entry Source `6e5eee9d7d504b0365422eb0ef7096e74e72e210`, tree `34929dcd892b595530e0cc583a48385706541acb`; Lab `283696be56bdaea1d310a1e56182f49792cf3b2c`, tree `d1446e526398b5922d00475958986e0b01291754`. Both clean. Runtime `17bbdc1a92569f8fcb2de02b25e55ba3c774a515ca4f70ae917bd6e97964e3af`. No publication commit yet. All actual outputs use fresh external root `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-6e5eee9-aricgzue`.

Own-exit wrappers, exact argv/cwd/environment/Git snapshots and raw logs are in `README/evidence-final-recording/checks/`. The copied L06 wrapper was extended to record commissioning/acceptance selectors. Failed attempts are retained separately. No helper/reviewer agent, original-main mutation, physical action, push/merge/deploy/outreach/spend/provision.

Initial inventory confirms Node24.22.2/pnpm10.32.1, Darwin arm64. Existing OrbStack listeners occupy57421/57422/57424; those services are unrelated and untouched. Docker's one bounded prerequisite observation succeeded in0.337s, Docker29.8.2, server Linux arm64. That is neither native assignment nor a current image build. Current reviewed local OCI build is being attempted under its existing-builder rules.

`owned-source-ci-prerequisite` was bounded30s and ended SIGALRM with an empty output log. No owned-ci directory or surviving child existed afterward. This is a failed prerequisite attempt, not a passing service check. Root was notified of the likely port-reservation cleanup hang; no code was changed. Cloud integration is not_run absent compatible owned services. Contracts, typecheck and reviewed whole authored-tree lint passed at the entry tuple. Build/remaining recordings in progress.

## Corrected prerequisite diagnosis and root hold

The initial no-directory statement was wrong: Node tmpdir is `/var/folders/.../T`, while `/tmp` resolves separately. The actual owned-CI temp workdir is `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-owned-ci-OCrXns`; it contains copied config/migrations and an empty logs directory. The bounded copied port loop binds and closes all six ports successfully, despite OrbStack's published ports. Therefore the reservation/finally loop is NOT established as the hang cause. The30s SIGALRM occurred after preparation and before synchronous start returned (its built-in timeout is300s). The exact stall cause is unestablished. A read-only owned-resource inventory confirms only eight old unrelated Supabase containers and no new owned-ci container; no unrelated resource was stopped/reset/pruned.

Root requested a hold on new final campaigns for a coordinated correction. The already-started mock regression remains on the original tuple and has retained the actual source-lint failure (1647problems). Its source-lint command omits the reviewed internal evidence exclusion. Current OCI attempt failed `LOCAL_BUILDER_REQUIRED`: existing OrbStack builder uses driver `docker`; reviewed OCI path requires existing running `docker-container`. No builder was provisioned. Separate current arm64 WEB05 image build passed, exact config image `sha256:1b2bcbc1eb37fb1dd0606922df85ab6e9869fd7aedff6acc02d05d04935eb941`, tag `mekoniq-final:6e5eee9-web05`. This image is built from the original entry tuple, not a later corrected producer and not native readiness.

Root received proposed narrow fixes (not yet authored): Docker published-port conflict guard before service preparation, plus explicit Lab recorder lint argv excluding only internal `.superpowers/**`. All initial logs, temp artifacts and image identity remain under their actual tuple. Source build passed with retained inherited nested-npm environment warnings. No performance capture has started.

## Final prerequisite correction 1 — scoped handoff ready for independent review

**DONE_WITH_CONCERNS, correction tooling only.** Root authorized `README/fix-final-prerequisites-1-dispatch.md`, including its test-only addendum, after reading the actual failures. This is a separate final-triage correction; the L06 I1–I3 loop remains CLOSED. No new final campaign, production browser measurement, R3 recording, native collection, physical operation or public publication ran during the correction. Parent B10/L06 and full final recording remain pending.

### Exact fixed tuple and packages

FIX_BASE Source `6e5eee9d7d504b0365422eb0ef7096e74e72e210` / Lab `283696be56bdaea1d310a1e56182f49792cf3b2c`.

- Final source: `bab05a5311a9db3be447519b3b9ac48eb0e4a90d`, tree `86ced26c4a071704d0e7296387fd08fe2055f768`, clean. Complete package `evidence-final-recording/fix1/source-fix-base.patch`: 28,374 bytes, SHA256 `886dea1ecb334fa13dec5151ba188b0b334c12cd6a4eaa25d78ddaad8af7f0bc`; 9 changed files.
- Final lab: `1f9b48d6d2767bdcd623f08cfa45ba0f9af33d1d`, tree `e6225d8fb666aab04a00ec5e124a7521c7a3c402`, clean. Complete package `evidence-final-recording/fix1/lab-fix-base.patch`: 6,860 bytes, SHA256 `aee5c540198311a6929a53eac3b75e55906aaa9ac6899fc9a38535cdf12b6f19`; 5 changed files.

Source commit is `fix: guard final recording prerequisites and retain native blockers`; Lab is `chore: pin source runtime bab05a5 and correct regression lint`. These are reviewed-correction candidates, not evidence-publication commits. Source changes only the bounded prerequisite guard, arm64 blocker diagnosis, assigned regression expectations/tests and directly related runbooks. Lab changes only recorder lint, its behavioral test, pin and two generated Source headers. Generated schema bodies are unchanged.

Runtime artifact `e280572231e51db029dc3db7a9c67dfd1b63a1417d0527ccbd20786683a45ba0`; raw export manifest `98924033c8a47ea533e80f0c1f54e4235e429000c71bfb128c436acc67fa9f04`. Schema `c2bdaca0b5ce9b03ee52a8c497719f4ea83b2cbb0e23c4e18365099fd163fa12` / 58 files; native `35aebff4ba065eae48c088a91c94fd7a08af6fd723560e0fdb68cbdc112cce0b` / 226 files; portable `778c336cd3bcffa975cbea2967915f27fd5f94124ec986e75f2dac031d55df93` / 238 files. Native/portable objects and schema bytes match the predecessor. Checker Source `bab05a5311a9db3be447519b3b9ac48eb0e4a90d`, graph `a71ce7c0419047b59a4b2a853d09df0f2efaa06c23c216cb506d9788eaaffa28`.

Fresh clean export: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix1-bab05a5-export`; exact retained copy `evidence-final-recording/fix1/export-final/`. Import preserved the previous runtime cache and rollback pin. The installed Lab manifest/runtime and new lock match the clean export. The unused fresh scratch root `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix1-bab05a5-3i7ilbr7` is not a campaign or evidence result.

### Correction dispositions

1. **CI published-port admission: implemented, pending scoped review.** The missing boundary was confirmed by actual Docker/lsof occupancy plus a copied Node loop that still bound all six ports. The later portable regression runs the real CLI under exclusive owned Docker/PNPM stubs and demonstrates that old code invokes start and stop despite the published conflict. It does not diagnose the real start's unknown delay. New read-only `docker ps --quiet --no-trunc` and structured inspect output are each bounded to5seconds/1MiB, at most1000full IDs. IDs, cardinality, port keys, binding objects, IPs and decimal port values must be readable and coherent; timeout/failure/truncation/ambiguity refuses before workdir or Supabase operations. Existing host binds/cleanup remain, with an owned listener regression. The two checks are sampled, not an atomic global lock. No automatic port changes or unrelated service cleanup were added.
2. **Integrated recorder lint: implemented, pending scoped review.** The real recorder now records `pnpm -s exec eslint . --ignore-pattern .superpowers/**`. No caller-selected ignore list or product-path waiver exists. The Lab regression extracts this actual call site and executes it against a scratch project: generated ignored `.superpowers/generated.js` contains a real no-debugger violation and is excluded; adding the same violation to `authored.js` still exits1 and names only the authored file. Raw fixture files and separate generated-only own-exit0 / authored-violation own-exit1 receipts/logs are retained under `fix1/lint-invocations/recorder-lint-qbqJzI`. The test's `node_modules` symlink is an explicit scratch dependency reference, not a portable tool closure or archived dependency copy. The test source retains the initial clean authored input and full recipe; final scratch authored.js intentionally retains the failing input.
3. **L06-R1-M1 final triage: implemented, pending scoped review.** Arm64 DEP-MJ-01 now has category `tooling_and_observation` and reason `ASSIGNED_HOST_CASE_ARTIFACTS_MISSING; MUJOCO_ARM64_CAMPAIGN_ADAPTER_NOT_IMPLEMENTED`. Derived blockedNativeCases and native-gate blockers expose both prerequisites. A coherent prepared arm64 fixture first passes public directory verification, then checks the case, blocked row and gate together. Fixed cases/scopes remain; no adapter was implemented and no native result was promoted. Host assignment alone is still insufficient. This is separate from the already resolved L06 Important findings.
4. **Four stale legacy expectations: corrected at root's authorized test-only scope.** Both denial cases now capture/assert the exact startup ownership baseline `.runtime-owner.sqlite` and require no additional root entry after all denials. The successful idempotent path requires exactly one new run directory, reads its run.json to bind the returned runId, and preserves that exact directory set through all repeated/conflicting/stale/other-session actions. The explicit registry list adds MJ-FD01 and MJ-CELL-BV01 in the actual registered order. Network, backend denial, session, idempotency and health-filtering assertions remain. No production authority changed.

### RED/GREEN and verification scope

All checks use Node24.22.2/pnpm10.32.1 and preserve exact argv/cwd/relevant environment/Git/changed-file hashes, own exit or signal and log hash. Workers retain bytecode-free Python settings; no engine/native worker campaign was launched. Counts below overlap and are not summed.

- Initial scratch `ci-conflict-red` is a quoting SyntaxError, preserved with its invalid helper; it is NOT behavioral evidence. Corrected `ci-conflict-red2` throws `PORT_CONFLICT_REACHED_SUPABASE_START` against real old CLI under owned stubs. No real Supabase command ran in that reproducer.
- `fix1/source-red`:8failed/1passed/47filtered. Seven initial CLI conflict/unreadable variants fail the expected early-refusal assertion against old code; the coherent arm64 case passes upstream public admission and fails the case/blocker/gate comparison. Filtered tests are not_run.
- `fix1/lab-lint-red`:1failed because the integrated old command reports the generated debugger violation. This is a genuine behavioral RED, not a missing helper/import.
- `source-green1`:9passed/47filtered. `source-port-broad`:2files/18passed, including added malformed/duplicate ID/container/null/invalid-binding variants, bounded timeout/output overflow, valid nonconflicting start boundary and owned host-bind cleanup.
- `source-combined`:all5files/104passed on final committed Source code/test bytes: owned-ci-ports, owned-ci-config, sim-extension-qualification, r3-native-readback, r2b-readback. Existing historical recorder-plan tests use their owned fake Docker executable, not installed Docker. Synthetic R3/ROS bags remain protocol/readback evidence, not native execution.
- `legacy-green`:29passed/1failed, because my first explicit registry update placed the two entries in the wrong order. That failed attempt is preserved. `legacy-green2` runs both complete corrected files and passes30/30.
- `lab-lint-green`:both requested files/16passed; this includes the integrated invocation's successful and deliberate failing lint outcomes, not a full mock-chain rerun.
- Actual changed prerequisite `actual-owned-ci-refusal`:own exit2 in under1second, `CI_PORT_INVENTORY_NOT_RUN`, `CI_PORT_INVENTORY_CONFLICT:57424`, `servicesStarted:false`. This is the required local service refusal, not a full-CI pass or another availability probe. Existing unrelated Supabase services remain untouched.
- Source contracts, full typecheck, scoped lint of all changed code/test files and staged diff-check exit0. Lab typecheck, final-pin typecheck and check:source exit0. Clean export/import/sync, checker identity, both commits and final byte audit have their own exit0. No full Source build/test/browser chain was rerun during this narrow correction. The initial successful build belongs only to6e5eee9.

### Original failed mock and cleanup

The already-started original-tuple mock invocation was stopped after its failures were known, before product edits. `stop-owned-failed-mock` records a verified root PID63988 with the exact external --out argv and its3descendants; the recorder was frozen before signaling the snapshot hierarchy leaf-first with SIGINT, then resumed to deliver its pending SIGINT. No PID remained after2seconds; no TERM was needed. No pattern kill or unrelated process cleanup occurred. The wrapper's own receipt is `exitCode:null, signal:SIGINT`, not a completed mock result.

Partial original mock results: Source typecheck/contracts exit0; unexcluded lint exit1 with1647problems; referenced suite exit1 with282passed/4failed/1skipped of287. The skip is the explicit LAB_V2_MEASURE telemetry/memory opt-in and remains not_run. Source unit was interrupted with no complete result; every later contracts/engineering/Python/Lab/browser/offline/performance step is not_run for this invocation. No manifest was fabricated for the partial chain. The production web capture remains a separate pending measurement.

Original actual outputs remain at `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-6e5eee9-aricgzue`: refused OCI attempt plus partial mock. `fix1/external-original-tuple-index.json` hashes all14files. Earlier successful current arm64 image remains ONLY the6e5eee9producer, tag `mekoniq-final:6e5eee9-web05`, config `sha256:1b2bcbc1eb37fb1dd0606922df85ab6e9869fd7aedff6acc02d05d04935eb941`. It is not the bab05a5image and cannot be reused as current-tuple qualification. OCI remains unbuilt/refused due `LOCAL_BUILDER_REQUIRED`; no builder was provisioned/changed. Linux host assignment remains absent.

### Retention, byte attribution and reproduction

`fix1/final-byte-attribution.json` verifies9Source/5Lab committed file bytes, clean exact heads/trees, full patches, installed/exported pin/runtime, all58schemas and226native/238portable references. It verifies1040indexed predecessor file entries across five retained B10/L06 indexes; these are file-entry counts, not distinct execution runs. The original3778byte report prefix is preserved, SHA256 `808ad562c50e65353737c5ee71d299f08b281be0a2606fa062c250f5c76782ef`. No original SQLite database was opened; byte hashing does not execute a database engine.

`fix1/check-index.json` has22checks; `check-index-complete.json` adds final audit's own receipt as the23rd. `checked-file-attribution.json` maps each final file to exact same-byte receipts, without claiming every check behaviorally covers each file. It also confirms42initial evidence files unchanged. Raw logs include intentional failures and corrective attempts. The final retention inventory excludes only itself and records scratch symlink metadata separately; no historical log/report/candidate was rewritten.

Reproduce scoped checks from the fixed commits with frozen dependencies:

```sh
# Source, Node24.22.2/pnpm10.32.1; no native/Docker availability probe required by unit tests.
PYTHONDONTWRITEBYTECODE=1 PYTEST_ADDOPTS='-p no:cacheprovider' pnpm exec vitest run tests/unit/owned-ci-ports.test.ts tests/unit/owned-ci-config.test.ts tests/unit/sim-extension-qualification.test.ts tests/unit/r3-native-readback.test.ts tests/unit/r2b-readback.test.ts
pnpm exec vitest run tests/integration/lab-v2-contracts.test.ts tests/integration/lab-v2-mock.test.ts
pnpm contracts:check
pnpm typecheck
# Lab sibling checkout at1f9b48d, matching clean pin:
pnpm exec vitest run tests/unit/recorder-lint.test.ts tests/unit/regression-recorder.test.ts
pnpm check:source
pnpm typecheck
```

Exact bounded argv/environment/receipts are in the complete check index; historical retained tests still require both digest-bound corpus selectors. Reproduction of historical L01/native evidence must use its exact recorded clean checker checkout and graph, not this later commit. Subject, checker, installed-host and later publication identities remain separate.

**Next:** root audits this complete correction and dispatches fresh scoped review. No final recording resumes until PASS at this replacement tuple. Full owned-service CI remains not_run with occupied fixed ports; actual final mock/IR-SIM/R1/R1.1/R2a/payload/cell/study/web/WEB05/R2b/R3prepared chain, performance/390px observation, versioned final design/GTM/ruling/review retention, link audits and the ONE whole-branch review remain pending. Native collector gaps, physical/calibration/human acceptance, `accepted:false` and `not_calibrated` remain unchanged.
