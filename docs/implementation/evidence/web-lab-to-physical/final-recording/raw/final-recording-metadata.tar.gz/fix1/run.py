import os, subprocess, sys
from pathlib import Path
base=Path(__file__).resolve().parent
source=base.parents[4]
env=os.environ.copy()
env.update(PATH='/Users/hoangpham/.nvm/versions/node/v24.22.2/bin:'+str(source/'.venv-irsim/bin')+':'+env['PATH'],PYTHONDONTWRITEBYTECODE='1',PYTEST_ADDOPTS='-p no:cacheprovider',MEKONIQ_RETAINED_INPUTS='/tmp/b10-fix1-inputs/inputs.json',MEKONIQ_RETAINED_INPUTS_SHA256='30351aae82c52171d3744d07446fc13341850da7eda155976de586493498a56f')
name,repo,*argv=sys.argv[1:]
cwd=source if repo=='source' else source.parent/repo
sys.exit(subprocess.call(['node',str(base/'check.mjs'),name,str(cwd),*argv],env=env))
