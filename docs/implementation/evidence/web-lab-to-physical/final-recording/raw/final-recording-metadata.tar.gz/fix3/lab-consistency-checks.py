import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent
checks=[('lab-archive-model-tests',['pnpm','exec','vitest','run','tests/unit/model-validation.test.ts','tests/integration/engineering-migration.test.ts','tests/integration/engineering-assembly-workspace.test.ts','tests/integration/engineering-storage.test.ts','tests/unit/engineering-assembly-content.test.ts','tests/unit/engineering-assembly.test.ts','tests/unit/engineering-estimates.test.ts','--reporter=default','--reporter=json','--outputFile=/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/lab-archive-model-tests.json']),('lab-consistency-typecheck',['pnpm','typecheck']),('lab-consistency-build',['pnpm','build']),('lab-final-discovery',['pnpm','exec','playwright','test','--list']),('lab-check-source',['pnpm','check:source'])]
for name,args in checks:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'lab','env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','caffeinate','-dims','perl','-e','alarm 300; exec @ARGV',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
