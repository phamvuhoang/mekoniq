import {spawn,execFileSync} from 'node:child_process';
import {readFile,writeFile,mkdir,appendFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createServer} from 'node:net';
import {runOwnedProcess} from '../../../../../scripts/native-sim/owned-process.mjs';
const base=import.meta.dirname,source=resolve(base,'../../../../..'),lab=resolve(source,'../lab'),out=join(JSON.parse(await readFile(join(base,'paths.json'),'utf8')).root,'brand-focus-diagnostic'),{pairingOutput}=await import(pathToFileURL(join(lab,'scripts/launcher-output.mjs')).href);await mkdir(join(out,'browser-process'));
const env={...process.env,BRAND_FOCUS_DIAGNOSTIC_OUT:out};delete env.MEKONIQ_TEST_SERVICE_RECEIPT;delete env.LAB_TEST_PAIRING_TOKEN;delete env.MEKONIQ_LAB_ACCESS_KEY;
const launcher=spawn(process.execPath,[join(lab,'scripts/start-mock.mjs'),'--data-dir',join(out,'owned-runtime')],{cwd:lab,env,stdio:['ignore','pipe','pipe'],detached:true});let text='',finished=false,ready=false,pending=Promise.resolve();const closed=new Promise((done)=>launcher.once('close',(code,signal)=>{finished=true;done({code,signal});}));const redacted=pairingOutput(chunk=>{pending=pending.then(()=>appendFile(join(out,'launcher-stdout.log'),chunk));});launcher.stdout.on('data',chunk=>{text+=chunk.toString();redacted.write(chunk);});launcher.stdout.once('end',()=>redacted.end());launcher.stderr.on('data',chunk=>{pending=pending.then(()=>appendFile(join(out,'launcher-stderr.log'),chunk));});
const controller=new AbortController();for(const signal of ['SIGINT','SIGTERM','SIGALRM'])process.once(signal,()=>{controller.abort();launcher.kill('SIGINT');});
try{
 await new Promise((done,reject)=>{const timer=setTimeout(()=>reject(Error('OWNED_LAUNCHER_READY_TIMEOUT')),30000),poll=setInterval(()=>{if(text.includes('Ready in')){clearInterval(poll);clearTimeout(timer);ready=true;done();}else if(finished){clearInterval(poll);clearTimeout(timer);reject(Error('OWNED_LAUNCHER_EARLY_EXIT'));}},25);});
 const ids=[launcher.pid,...[...text.matchAll(/(?:runtime|UI) pid (\d+)/g)].map(m=>Number(m[1]))];await writeFile(join(out,'owned-process-birth.txt'),execFileSync('ps',['-ww','-o','pid=,ppid=,pgid=,lstart=,command=','-p',ids.join(',')],{encoding:'utf8'}));
 const receipt=await runOwnedProcess('pnpm',['exec','playwright','test','--config',join(out,'playwright.config.ts')],{out:join(out,'browser-process'),cwd:lab,env,timeoutMs:120000,signal:controller.signal});console.log(JSON.stringify({scope:'ONE controlled brand focus diagnostic',receipt}));process.exitCode=receipt.exitCode??1;
}finally{
 if(!finished)launcher.kill('SIGINT');const cleanup=await Promise.race([closed,new Promise((_,reject)=>setTimeout(()=>reject(Error('OWNED_LAUNCHER_CLOSE_TIMEOUT')),15000))]);await pending;const ports=[];
 for(const port of [4175,4176])await new Promise((done,reject)=>{const server=createServer();server.once('error',reject);server.listen(port,'127.0.0.1',()=>server.close(error=>{if(error)reject(error);else{ports.push({port,reservation:'succeeded-and-released'});done();}}));});
 await writeFile(join(out,'cleanup.json'),JSON.stringify({launcherPid:launcher.pid,ready,cleanup,ports,scope:'Only exact launcher created by this invocation received SIGINT; it owns runtime/UI shutdown. No deletion, global kill or unrelated service operation.'},null,2));if(cleanup.code!==0||cleanup.signal)throw Error('OWNED_LAUNCHER_CLOSE_FAILED');
}
