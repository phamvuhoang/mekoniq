import json,subprocess,socket,os
from pathlib import Path
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root']);receipt=json.loads((b/'checks/browser-diagnostic.receipt.json').read_text());assert receipt['exitCode']==1 and receipt['signal'] is None
rows=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines();known={23686,23697,23704,23721,23744};found=[]
for row in rows:
 parts=row.strip().split(None,2)
 if len(parts)!=3:continue
 pid,ppid,command=parts
 if int(pid) in known:found.append({'pid':int(pid),'ppid':int(ppid),'command':command,'scope':'previous logged owned diagnostic PID; identity must be assessed if reused'})
ports=[]
for port in [4175,4176]:
 s=socket.socket();s.settimeout(1)
 try:s.bind(('127.0.0.1',port));ports.append({'port':port,'reservation':'succeeded-and-released'})
 except OSError as e:ports.append({'port':port,'reservation':'refused','error':str(e)})
 finally:s.close()
assert not found;assert all(p['reservation']=='succeeded-and-released' for p in ports)
print(json.dumps({'diagnosticOwnExit':receipt['exitCode'],'diagnosticSignal':receipt['signal'],'loggedDiagnosticPidsObserved':found,'ports':ports,'cleanupAction':'none required; no kill, stop or deletion performed','limits':'Read-only logged-PID and port check; not a claim to identify unrelated Chromium processes'},indent=2))
