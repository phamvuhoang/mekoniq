from pathlib import Path
from urllib.parse import urlparse
import json,base64,socket
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root']);rows=[]
def bindings(doc):
 out=[]
 def visit(s):
  for spec in s.get('specs',[]):
   for t in spec.get('tests',[]):
    for r in t['results']:
     for a in r.get('attachments',[]):
      if a['name']=='replay-production-preview':
       data=json.loads(base64.b64decode(a['body'])) if 'body' in a else json.loads(Path(a['path']).read_text());out.append(data)
  for c in s.get('suites',[]):visit(c)
 for s in doc['suites']:visit(s)
 return out
identity=json.loads((root/'b07-external-replay/browser-runtime-identity.json').read_text());assert identity['before']==identity['after'];cleanup=json.loads((root/'b07-external-replay/preview-cleanup.json').read_text());assert cleanup['listening'] is False
for mode,file in [('owned',root/'replay-default.json'),('external',root/'b07-external-replay/result.json')]:
 doc=json.loads(file.read_text());assert doc['stats']['expected']==3 and doc['stats']['unexpected']==0 and doc['stats']['skipped']==0;items=bindings(doc);assert len(items)==3
 for item in items:
  assert item['mode']==mode
  if mode=='owned':assert not Path(item['directory']).exists();assert urlparse(item['url']).port!=4175;assert item['invocationId'] is None
  else:assert item['url']=='http://127.0.0.1:4175/';assert item['invocationId']==identity['invocationId'];assert Path(item['directory']).is_dir()
  rows.append(item)
for port in {urlparse(row['url']).port for row in rows}:
 s=socket.socket()
 try:s.bind(('127.0.0.1',port))
 finally:s.close()
(b/'preview-bindings.json').write_text(json.dumps({'bindings':rows,'ownedTemporaryDirectoriesRemoved':True,'previewPortsAvailableAfterClose':True,'externalBuildIdentityUnchanged':True,'externalInvocationId':identity['invocationId']},indent=2));print(json.dumps({'ownedCases':3,'externalCases':3,'ownedTemporaryDirectoriesRemoved':True,'previewPortsAvailableAfterClose':True,'externalBuildIdentityUnchanged':True},indent=2))
