import {readFileSync,mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {physicalPlan} from '../../../../../../lab/scripts/recorder-options.mjs';
const base=import.meta.dirname,root=join(JSON.parse(readFileSync(join(base,'paths.json'))).root,'broad-browser-final');mkdirSync(root);
const plan=physicalPlan(root);for(const path of plan.dirs)mkdirSync(path,{recursive:true});
const args=['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','-u','LAB_TEST_PAIRING_TOKEN','CI=1','LAB_PW_JSON='+join(root,'result.json'),...Object.entries(plan.browserEnv).map(([key,value])=>key+'='+value),'caffeinate','-dims','perl','-e','alarm 900; exec @ARGV','pnpm','exec','playwright','test'];
const r=spawnSync('python3',[join(base,'run.py'),'lab-broad-browser-final','lab',...args],{stdio:'inherit'});process.exit(r.status??1);
