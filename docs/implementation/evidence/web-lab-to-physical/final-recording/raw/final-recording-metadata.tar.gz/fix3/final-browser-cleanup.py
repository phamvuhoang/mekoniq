from pathlib import Path
from urllib.parse import urlparse
import json,base64,socket
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root']);doc=json.loads((root/'broad-browser-focus-final/result.json').read_text());bindings=[]
def visit(s):
 for spec in s.get('specs',[]):
  for t in spec.get('tests',[]):
   for r in t['results']:
    for a in r.get('attachments',[]):
     if a['name']=='replay-production-preview':bindings.append(json.loads(base64.b64decode(a['body'])) if 'body' in a else json.loads(Path(a['path']).read_text()))
 for child in s.get('suites',[]):visit(child)
for s in doc['suites']:visit(s)
assert len(bindings)==3 and all(row['mode']=='owned' and not Path(row['directory']).exists() for row in bindings)
ports=[]
for port in sorted({4175,4176,*[urlparse(row['url']).port for row in bindings]}):
 s=socket.socket()
 try:s.bind(('127.0.0.1',port));ports.append({'port':port,'reservation':'succeeded-and-released'})
 finally:s.close()
result={'scope':'Current complete broad browser owned previews/ports; no host-wide process claim','broadStats':doc['stats'],'bindings':bindings,'temporaryBuildDirectoriesRemoved':True,'ports':ports,'cleanupAction':'none required; no process signaled or file deleted by this observation'}
(b/'final-browser-cleanup.json').write_text(json.dumps(result,indent=2));print(json.dumps({**result,'bindings':len(bindings)},indent=2))
