import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent
checks=[
('source-corrected-complete','source',['pnpm','exec','vitest','run','tests/integration/lab-v2-native-gateway.test.ts','tests/integration/lab-v2-readiness.test.ts','tests/integration/lab-v2-bv01-sil.test.ts','tests/integration/lab-v2-native-wire-deadline.test.ts','tests/integration/lab-v2-sil-review.test.ts','--reporter=default','--reporter=json','--outputFile=/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/source-corrected-complete.json']),
('source-typecheck','source',['pnpm','typecheck']),
('source-authored-lint','source',['pnpm','exec','eslint','tests/integration/lab-v2-native-gateway.test.ts','tests/integration/lab-v2-readiness.test.ts','tests/integration/lab-v2-bv01-sil.test.ts']),
('lab-discovery-after','lab',['pnpm','exec','playwright','test','--list']),
('lab-affected-unit','lab',['pnpm','exec','vitest','run','tests/unit/controller-report.test.ts','tests/unit/engineering-report.test.ts','tests/unit/report-human-wait.test.ts','tests/unit/report-xss.test.ts','tests/unit/report-evidence.test.ts','tests/unit/physics-report-shape.test.ts','tests/unit/payload-view.test.ts','tests/unit/workspace-navigation-scene.test.ts','tests/unit/semantic-study-view.test.ts','tests/unit/report-replay.test.ts','tests/unit/payload-import-scrub.test.ts','tests/unit/navigation2d-report.test.ts','tests/unit/report-metrics.test.ts','--reporter=default','--reporter=json','--outputFile=/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_/lab-affected-unit.json']),
('lab-typecheck','lab',['pnpm','typecheck']),('lab-build','lab',['pnpm','build'])]
for name,repo,args in checks:
 code=subprocess.call([sys.executable,str(b/'run.py'),name,repo,'env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','caffeinate','-dims','perl','-e','alarm 600; exec @ARGV',*args]);print(name,code,flush=True)
 if code:sys.exit(code)
