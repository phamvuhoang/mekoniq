import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent;root=Path("/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_")
for name in ['replay-default-shots','replay-default-pw','transport-shots','transport-pw']:(root/name).mkdir()
commands=[('replay-default-owned',['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','-u','LAB_BROWSER_INVOCATION','-u','LAB_B07B_EVIDENCE','LAB_PW_JSON='+str(root/'replay-default.json'),'LAB_PW_OUTPUT_DIR='+str(root/'replay-default-pw'),'caffeinate','-dims','perl','-e','alarm 480; exec @ARGV','pnpm','exec','playwright','test','replay-offline.spec.ts']),('transport-owned-complete',['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','LAB_PW_JSON='+str(root/'transport-owned.json'),'LAB_EVIDENCE_DIR='+str(root/'transport-shots'),'LAB_PW_OUTPUT_DIR='+str(root/'transport-pw'),'caffeinate','-dims','perl','-e','alarm 600; exec @ARGV','node','scripts/test-mock-e2e.mjs','twin-transport.spec.ts'])]
for name,args in commands:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'lab',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
