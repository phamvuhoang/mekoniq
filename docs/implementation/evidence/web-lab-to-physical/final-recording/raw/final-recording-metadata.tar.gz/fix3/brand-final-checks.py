import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent;root=Path("/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_")
commands=[('brand-complete',['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','-u','LAB_TEST_PAIRING_TOKEN','CI=1','LAB_PW_JSON='+str(root/'brand-complete.json'),'LAB_PW_OUTPUT_DIR='+str(root/'brand-complete-pw'),'LAB_BRAND_EVIDENCE_DIR='+str(root/'brand-complete-shots'),'caffeinate','-dims','perl','-e','alarm 300; exec @ARGV','pnpm','exec','playwright','test','brand-ui.spec.ts']),('lab-focus-typecheck',['pnpm','typecheck']),('lab-focus-build',['pnpm','build']),('lab-focus-source',['pnpm','check:source'])]
for name,args in commands:
 if args[0]!='env':args=['env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','caffeinate','-dims','perl','-e','alarm 300; exec @ARGV',*args]
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'lab',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
