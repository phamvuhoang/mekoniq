import subprocess,sys
from pathlib import Path
b=Path(__file__).resolve().parent
for name,args in [('lab-browser-fixture-build',['pnpm','build']),('lab-browser-fixture-source',['pnpm','check:source'])]:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'lab','env','-u','MEKONIQ_TEST_SERVICE_RECEIPT','caffeinate','-dims','perl','-e','alarm 300; exec @ARGV',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
