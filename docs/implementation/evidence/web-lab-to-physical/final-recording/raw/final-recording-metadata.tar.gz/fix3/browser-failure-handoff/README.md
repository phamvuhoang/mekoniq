# Actual correction3 broad browser RED

Source229efa7 / Labba1d0e0. lab-pw-browser.json:60expected passed/2unexpected/42skipped, no discovery-global errors. Both actual failure results and raw attachment paths/hashes retained. Selected mock14passed and owned runtime journey1passed are separate scopes. Full recorder still running at this handoff; own final exit/manifest will be retained when it settles.

Offline replay assertion traps ALL EventSource/WebSocket constructors, including observed two same-origin ws://127.0.0.1:4175/?token=... calls. /lab request-attempt assertion already passed; trap identity/protocol/stack was not recorded. These URLs are consistent with Vite HMR, but actual constructor provenance needs a narrow observation before claiming it proved. No generic network exclusion or product behavior change proposed yet.

390px touch test hits unchanged30s timeout without locator stack. Saved DOM and inspected screenshot show shell not in watch mode, runtime popover open showing RUNTIME_UNREACHABLE and covering viewport controls. Test checks isVisible once immediately after goto, conditionally taps runtime chip, then watch. 1024px same touch test passed. Timing/setup race is a hypothesis, not proved exact stalled step. Existing raw logs show expected development proxy refusals because broad UI invocation has no runtime4176; this is distinct from the later owned runtime journey which passed.

Proposed narrow diagnostic after owned recorder settles: real browser observation of constructor URL/protocol/stack and runtime-popover/health/button geometry/event ordering, with step-level timestamps/trace under unchanged timeout. Preserve failures, no blind retry/test timeout/product edits. Root coordinates any scope correction and fresh reviewed tuple.
