from pathlib import Path
import subprocess,json,hashlib,os
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';sdd=source/'.superpowers/sdd';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda cwd,*a:subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
assert not git(source,'status','--porcelain','--untracked-files=all');assert not git(lab,'status','--porcelain','--untracked-files=all')
packages=read(sdd/'README/root-final-prerequisites-3-git-audit-45794aa.json')
for rec in packages:
 cwd=source if rec['repo']=='source' else lab;assert git(cwd,'rev-parse','HEAD')==rec['head'] and git(cwd,'rev-parse','HEAD^{tree}')==rec['tree'];assert sha(rec['diffPath'])==rec['diffSha256'] and Path(rec['diffPath']).stat().st_size==rec['diffBytes']
 for f in rec['files']:
  p=cwd/f['path'];assert sha(p)==f['sha256'] and p.stat().st_size==f['bytes'];assert p.read_bytes()==subprocess.check_output(['git','show',rec['head']+':'+f['path']],cwd=cwd)
out=Path(read(b/'paths.json')['root']);m=read(b/'export-final/manifest.json');pin=read(lab/'config/source-runtime.lock.json');assert m==read(out/'export/manifest.json')==read(lab/'.runtime'/pin['artifactSha256']/'manifest.json');assert not m['dirty'] and not pin['dirty'];assert pin['sourceCommit']==m['sourceCommit']==packages[0]['head'];assert sha(b/'export-final/runtime.mjs')==sha(out/'export/runtime.mjs')==sha(lab/'.runtime'/pin['artifactSha256']/'runtime.mjs')==pin['artifactSha256']
for f in read(b/'export-verification.json')['exportFiles']:
 p=b/'export-final'/f['path'];assert sha(p)==f['sha256'] and p.stat().st_size==f['bytes']
indices=[sdd/'02-r2b-cell-and-web'/p for p in ['root-B10-evidence-file-index.json','root-B10-r1-evidence-file-index.json','root-B10-smoke-27d6be9-file-index.json']]+[sdd/'03-r3-linux-readiness'/p for p in ['root-L06-evidence-file-index.json','root-L06-r1-evidence-file-index.json']]+[sdd/'README/root-final-prerequisites-1-evidence-file-index.json',b.parent/'fix1/initial-evidence-index.json',b.parent/'bab05a5/phase-retention-index.json',b.parent/'bab05a5/external-phase-retention-index.json',sdd/'README/root-final-prerequisites-2-evidence-file-index.json',b.parent/'fix2/external-retention-index.json',b/'previous-phase-bookkeeping-index.json',b/'previous-phase-external-index.json',b.parent/'fix1/external-original-tuple-index.json']
preserved=[]
for p in indices:
 j=read(p)
 for f in j['files']:
  q=Path(j['root'])/f['path'];assert q.stat().st_size==f['bytes'] and sha(q)==f['sha256'],str(p)+':'+f['path']
 preserved.append({'index':str(p),'sha256':sha(p),'files':len(j['files'])})
checks=[]
for p in sorted((b/'checks').glob('*.receipt.json')):
 j=read(p);log=p.with_name(p.name.replace('.receipt.json','.log'));assert sha(log)==j['logSha256'];checks.append({'receipt':p.name,'receiptSha256':sha(p),'logBytes':log.stat().st_size,**j})
(b/'check-index-final-45794aa.json').write_text(json.dumps(checks,indent=2))
mock=read(out/'mock-regression/manifest.json');assert mock['revisions']['source']==packages[0]['head'] and mock['revisions']['lab']=='ba1d0e01b9542dbefe8e21a95a561ea2d0b83f59';assert not mock['revisions']['sourceDirty'] and not mock['revisions']['labDirty'];runs=[]
for rec in mock['runs']:
 p=out/'mock-regression'/rec['file'];assert sha(p)==rec['sha256'];runs.append({k:rec[k] for k in ['id','kind','exitCode','file','sha256','summary']})
for rec in mock['commands']:assert sha(out/'mock-regression'/rec['log'])==rec['logSha256']
assert (source/'.superpowers/sdd/README/task-final-recording-report.md').read_bytes().startswith((b/'report-prefix.txt').read_bytes())
result={'source':packages[0]['head'],'sourceTree':packages[0]['tree'],'lab':packages[1]['head'],'labTree':packages[1]['tree'],'clean':True,'reviewPackages':[{k:r[k] for k in ['repo','base','head','tree','diffPath','diffBytes','diffSha256']} for r in packages],'export':read(b/'export-verification.json'),'checker':read(b/'checks/checker-identity.log'),'previousPreservation':preserved,'preservedFileEntries':sum(r['files'] for r in preserved),'ownChecksBeforeAuditReceipt':len(checks),'mockRecordedSubject':mock['revisions'],'correctiveBroadStats':read(out/'broad-browser-focus-final/result.json')['stats'],'pendingBrandFocusFinding':False,'previousCorrectiveBroadStats':read(out/'broad-browser-final/result.json')['stats'],'brandRegressionRed':read(out/'brand-health-red.json')['stats'],'brandRegressionGreen':read(out/'brand-health-green.json')['stats'],'completeBrand':read(out/'brand-complete.json')['stats'],'healthScope':'Pre-fix controlled diagnostic actual owned runtime200; post-fix deterministic regression/default broad actual default proxy500; no post-fix runtime200 qualification claimed','mockFailures':[r['id'] for r in mock['commands'] if r['exitCode']!=0],'mockNotRun':mock['notRun'],'mockRuns':runs,'limits':['Scoped software regression and provenance checks only','No new native, image, WEB05, physics or production performance qualification','Prior input code hashes describe their recorded Git commits; current snapshots are preserved separately']}
(b/'final-byte-attribution-45794aa.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:result[k] for k in ['source','sourceTree','lab','labTree','clean','preservedFileEntries','ownChecksBeforeAuditReceipt','mockFailures','mockNotRun']},indent=2))
