from pathlib import Path
import json,hashlib,shutil,subprocess
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';out=Path(json.loads((b/'paths.json').read_text())['root'])/'export';read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=read(out/'manifest.json');old=read(b.parent/'fix2/export-final/manifest.json');pin=read(lab/'config/source-runtime.lock.json');assert not m['dirty'] and not pin['dirty'];assert m['sourceCommit']==pin['sourceCommit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert m['nativeTools']==old['nativeTools'];assert m['portableSimulationTools']['closure']==old['portableSimulationTools']['closure'];assert m['schemaHash']==old['schemaHash'] and m['schemas']==old['schemas']
closures={}
for name,c in [('native',m['nativeTools']),('portable',m['portableSimulationTools']['closure'])]:
 for f in c['files']:
  p=source/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256']
 closures[name]={'digest':c['digest'],'files':len(c['files']),'bytes':sum(f['bytes'] for f in c['files']),'exactPreviousFilesAndBytes':True}
h=hashlib.sha256()
for name in sorted(m['schemas']):
 p=out/'schemas'/name;assert p.read_bytes()==(source/'packages/contracts/schemas'/name).read_bytes();h.update((name+'\n').encode());h.update(p.read_bytes())
assert h.hexdigest()==m['schemaHash'];cache=lab/'.runtime'/pin['artifactSha256'];assert read(cache/'manifest.json')==m;assert sha(out/'runtime.mjs')==sha(cache/'runtime.mjs')==pin['artifactSha256']
for file in ['engineering.ts','navigation2d.ts']:
 header=(lab/'src/shared'/file).read_text().splitlines()[0];assert m['sourceCommit'] in header
files=[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file()];assert len(files)==60
shutil.copytree(out,b/'export-final');result={'sourceCommit':m['sourceCommit'],'runtime':m['artifactSha256'],'schemaHash':m['schemaHash'],'schemaCount':len(m['schemas']),'closures':closures,'rawManifestSha256':sha(out/'manifest.json'),'exportFiles':files,'installedManifestMatched':True,'generatedHeadersMatched':True};(b/'export-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps({**result,'exportFiles':len(files)},indent=2))
