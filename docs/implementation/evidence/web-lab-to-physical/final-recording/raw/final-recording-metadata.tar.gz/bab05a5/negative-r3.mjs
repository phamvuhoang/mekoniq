import {cp,mkdir,readFile,writeFile,rm} from 'node:fs/promises';import {join} from 'node:path';import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const root=process.argv[2],original=join(root,'r3-mujoco-linux-amd64-prepared'),out=join(root,'r3-negatives');await mkdir(out);const rows=[];
for(const kind of ['missing-runtime','corrupt-runtime','wrong-subject']){
 const dir=join(out,kind);await cp(original,dir,{recursive:true});
 if(kind==='missing-runtime')await rm(join(dir,'inputs/handoff/runtime/runtime.mjs'));
 if(kind==='corrupt-runtime')await writeFile(join(dir,'inputs/handoff/runtime/runtime.mjs'),'intentional negative input');
 if(kind==='wrong-subject'){const path=join(dir,'qualification.json'),m=JSON.parse(await readFile(path));m.subject.sourceCommit='f'.repeat(40);await writeFile(path,JSON.stringify(m));}
 const args=['scripts/verify-r3.mjs',dir],r=spawnSync(process.execPath,args,{encoding:'utf8',timeout:30000}),stdout=r.stdout??'',stderr=r.stderr??'';await writeFile(join(out,kind+'.stdout.log'),stdout);await writeFile(join(out,kind+'.stderr.log'),stderr);const result=JSON.parse(stdout);if(r.status!==1||result.valid!==false)throw Error('NEGATIVE_NOT_REFUSED:'+kind);if(kind==='wrong-subject'&&!result.issues.includes('R3_SUBJECT_BINDING'))throw Error('WRONG_SUBJECT_NOT_REACHED');rows.push({kind,args,exit:r.status,signal:r.signal,result,stdoutSha256:createHash('sha256').update(stdout).digest('hex')});
}
await writeFile(join(out,'negative-results.json'),JSON.stringify(rows,null,2));console.log(JSON.stringify(rows));
