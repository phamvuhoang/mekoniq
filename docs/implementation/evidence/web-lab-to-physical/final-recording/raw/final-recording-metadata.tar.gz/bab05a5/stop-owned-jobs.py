import subprocess,os,signal,time,json,shutil
from pathlib import Path
roots={75855:'node ../lab/scripts/record-regression.mjs --suite physical-robot-lab --out /var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-bab05a5-wnbyr2rt/mock-regression',75751:'sh deploy/lab-runtime/build.sh mekoniq-final:bab05a5-web05 --platform linux/arm64'}
rows={}
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
 p=line.strip().split(None,2)
 if len(p)==3:rows[int(p[0])]={'pid':int(p[0]),'ppid':int(p[1]),'command':p[2]}
for pid,command in roots.items():
 if pid in rows and rows[pid]['command']!=command:raise SystemExit('OWNERSHIP_NOT_PROVED:'+str(pid))
owned=[pid for pid in roots if pid in rows]
for pid in owned:os.kill(pid,signal.SIGSTOP)
for pid in owned:owned.extend(r['pid'] for r in rows.values() if r['ppid']==pid and r['pid'] not in owned)
proof=[rows[pid] for pid in owned]
context=Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/tmp.UldkCvaeSC')
if any(r['command'].startswith('docker build --platform linux/arm64 --build-arg SOURCE_COMMIT=bab05a5311a9db3be447519b3b9ac48eb0e4a90d ') and r['command'].endswith(str(context)) for r in proof) and context.exists():
 shutil.copytree(context,Path('/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-bab05a5-wnbyr2rt/current-image-build-context'))
print(json.dumps({'proof':proof,'contextPreserved':str(context),'cleanup':'only proved roots and descendant snapshot'},indent=2),flush=True)
for pid in reversed(owned):
 try:os.kill(pid,signal.SIGINT)
 except ProcessLookupError:pass
for pid in roots:
 if pid in rows:
  try:os.kill(pid,signal.SIGCONT)
  except ProcessLookupError:pass
time.sleep(2)
left=[]
for pid in owned:
 try:os.kill(pid,0);left.append(pid)
 except ProcessLookupError:pass
for pid in left:
 try:os.kill(pid,signal.SIGTERM)
 except ProcessLookupError:pass
print(json.dumps({'remainingAfterINT':left,'termOnlyTheseOwnedPids':left}),flush=True)
