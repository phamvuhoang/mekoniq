# Final B10/L06 recording — append-only work log

Producer entry Source `6e5eee9d7d504b0365422eb0ef7096e74e72e210`, tree `34929dcd892b595530e0cc583a48385706541acb`; Lab `283696be56bdaea1d310a1e56182f49792cf3b2c`, tree `d1446e526398b5922d00475958986e0b01291754`. Both clean. Runtime `17bbdc1a92569f8fcb2de02b25e55ba3c774a515ca4f70ae917bd6e97964e3af`. No publication commit yet. All actual outputs use fresh external root `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-6e5eee9-aricgzue`.

Own-exit wrappers, exact argv/cwd/environment/Git snapshots and raw logs are in `README/evidence-final-recording/checks/`. The copied L06 wrapper was extended to record commissioning/acceptance selectors. Failed attempts are retained separately. No helper/reviewer agent, original-main mutation, physical action, push/merge/deploy/outreach/spend/provision.

Initial inventory confirms Node24.22.2/pnpm10.32.1, Darwin arm64. Existing OrbStack listeners occupy57421/57422/57424; those services are unrelated and untouched. Docker's one bounded prerequisite observation succeeded in0.337s, Docker29.8.2, server Linux arm64. That is neither native assignment nor a current image build. Current reviewed local OCI build is being attempted under its existing-builder rules.

`owned-source-ci-prerequisite` was bounded30s and ended SIGALRM with an empty output log. No owned-ci directory or surviving child existed afterward. This is a failed prerequisite attempt, not a passing service check. Root was notified of the likely port-reservation cleanup hang; no code was changed. Cloud integration is not_run absent compatible owned services. Contracts, typecheck and reviewed whole authored-tree lint passed at the entry tuple. Build/remaining recordings in progress.

## Corrected prerequisite diagnosis and root hold

The initial no-directory statement was wrong: Node tmpdir is `/var/folders/.../T`, while `/tmp` resolves separately. The actual owned-CI temp workdir is `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-owned-ci-OCrXns`; it contains copied config/migrations and an empty logs directory. The bounded copied port loop binds and closes all six ports successfully, despite OrbStack's published ports. Therefore the reservation/finally loop is NOT established as the hang cause. The30s SIGALRM occurred after preparation and before synchronous start returned (its built-in timeout is300s). The exact stall cause is unestablished. A read-only owned-resource inventory confirms only eight old unrelated Supabase containers and no new owned-ci container; no unrelated resource was stopped/reset/pruned.

Root requested a hold on new final campaigns for a coordinated correction. The already-started mock regression remains on the original tuple and has retained the actual source-lint failure (1647problems). Its source-lint command omits the reviewed internal evidence exclusion. Current OCI attempt failed `LOCAL_BUILDER_REQUIRED`: existing OrbStack builder uses driver `docker`; reviewed OCI path requires existing running `docker-container`. No builder was provisioned. Separate current arm64 WEB05 image build passed, exact config image `sha256:1b2bcbc1eb37fb1dd0606922df85ab6e9869fd7aedff6acc02d05d04935eb941`, tag `mekoniq-final:6e5eee9-web05`. This image is built from the original entry tuple, not a later corrected producer and not native readiness.

Root received proposed narrow fixes (not yet authored): Docker published-port conflict guard before service preparation, plus explicit Lab recorder lint argv excluding only internal `.superpowers/**`. All initial logs, temp artifacts and image identity remain under their actual tuple. Source build passed with retained inherited nested-npm environment warnings. No performance capture has started.

## Final prerequisite correction 1 — scoped handoff ready for independent review

**DONE_WITH_CONCERNS, correction tooling only.** Root authorized `README/fix-final-prerequisites-1-dispatch.md`, including its test-only addendum, after reading the actual failures. This is a separate final-triage correction; the L06 I1–I3 loop remains CLOSED. No new final campaign, production browser measurement, R3 recording, native collection, physical operation or public publication ran during the correction. Parent B10/L06 and full final recording remain pending.

### Exact fixed tuple and packages

FIX_BASE Source `6e5eee9d7d504b0365422eb0ef7096e74e72e210` / Lab `283696be56bdaea1d310a1e56182f49792cf3b2c`.

- Final source: `bab05a5311a9db3be447519b3b9ac48eb0e4a90d`, tree `86ced26c4a071704d0e7296387fd08fe2055f768`, clean. Complete package `evidence-final-recording/fix1/source-fix-base.patch`: 28,374 bytes, SHA256 `886dea1ecb334fa13dec5151ba188b0b334c12cd6a4eaa25d78ddaad8af7f0bc`; 9 changed files.
- Final lab: `1f9b48d6d2767bdcd623f08cfa45ba0f9af33d1d`, tree `e6225d8fb666aab04a00ec5e124a7521c7a3c402`, clean. Complete package `evidence-final-recording/fix1/lab-fix-base.patch`: 6,860 bytes, SHA256 `aee5c540198311a6929a53eac3b75e55906aaa9ac6899fc9a38535cdf12b6f19`; 5 changed files.

Source commit is `fix: guard final recording prerequisites and retain native blockers`; Lab is `chore: pin source runtime bab05a5 and correct regression lint`. These are reviewed-correction candidates, not evidence-publication commits. Source changes only the bounded prerequisite guard, arm64 blocker diagnosis, assigned regression expectations/tests and directly related runbooks. Lab changes only recorder lint, its behavioral test, pin and two generated Source headers. Generated schema bodies are unchanged.

Runtime artifact `e280572231e51db029dc3db7a9c67dfd1b63a1417d0527ccbd20786683a45ba0`; raw export manifest `98924033c8a47ea533e80f0c1f54e4235e429000c71bfb128c436acc67fa9f04`. Schema `c2bdaca0b5ce9b03ee52a8c497719f4ea83b2cbb0e23c4e18365099fd163fa12` / 58 files; native `35aebff4ba065eae48c088a91c94fd7a08af6fd723560e0fdb68cbdc112cce0b` / 226 files; portable `778c336cd3bcffa975cbea2967915f27fd5f94124ec986e75f2dac031d55df93` / 238 files. Native/portable objects and schema bytes match the predecessor. Checker Source `bab05a5311a9db3be447519b3b9ac48eb0e4a90d`, graph `a71ce7c0419047b59a4b2a853d09df0f2efaa06c23c216cb506d9788eaaffa28`.

Fresh clean export: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix1-bab05a5-export`; exact retained copy `evidence-final-recording/fix1/export-final/`. Import preserved the previous runtime cache and rollback pin. The installed Lab manifest/runtime and new lock match the clean export. The unused fresh scratch root `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix1-bab05a5-3i7ilbr7` is not a campaign or evidence result.

### Correction dispositions

1. **CI published-port admission: implemented, pending scoped review.** The missing boundary was confirmed by actual Docker/lsof occupancy plus a copied Node loop that still bound all six ports. The later portable regression runs the real CLI under exclusive owned Docker/PNPM stubs and demonstrates that old code invokes start and stop despite the published conflict. It does not diagnose the real start's unknown delay. New read-only `docker ps --quiet --no-trunc` and structured inspect output are each bounded to5seconds/1MiB, at most1000full IDs. IDs, cardinality, port keys, binding objects, IPs and decimal port values must be readable and coherent; timeout/failure/truncation/ambiguity refuses before workdir or Supabase operations. Existing host binds/cleanup remain, with an owned listener regression. The two checks are sampled, not an atomic global lock. No automatic port changes or unrelated service cleanup were added.
2. **Integrated recorder lint: implemented, pending scoped review.** The real recorder now records `pnpm -s exec eslint . --ignore-pattern .superpowers/**`. No caller-selected ignore list or product-path waiver exists. The Lab regression extracts this actual call site and executes it against a scratch project: generated ignored `.superpowers/generated.js` contains a real no-debugger violation and is excluded; adding the same violation to `authored.js` still exits1 and names only the authored file. Raw fixture files and separate generated-only own-exit0 / authored-violation own-exit1 receipts/logs are retained under `fix1/lint-invocations/recorder-lint-qbqJzI`. The test's `node_modules` symlink is an explicit scratch dependency reference, not a portable tool closure or archived dependency copy. The test source retains the initial clean authored input and full recipe; final scratch authored.js intentionally retains the failing input.
3. **L06-R1-M1 final triage: implemented, pending scoped review.** Arm64 DEP-MJ-01 now has category `tooling_and_observation` and reason `ASSIGNED_HOST_CASE_ARTIFACTS_MISSING; MUJOCO_ARM64_CAMPAIGN_ADAPTER_NOT_IMPLEMENTED`. Derived blockedNativeCases and native-gate blockers expose both prerequisites. A coherent prepared arm64 fixture first passes public directory verification, then checks the case, blocked row and gate together. Fixed cases/scopes remain; no adapter was implemented and no native result was promoted. Host assignment alone is still insufficient. This is separate from the already resolved L06 Important findings.
4. **Four stale legacy expectations: corrected at root's authorized test-only scope.** Both denial cases now capture/assert the exact startup ownership baseline `.runtime-owner.sqlite` and require no additional root entry after all denials. The successful idempotent path requires exactly one new run directory, reads its run.json to bind the returned runId, and preserves that exact directory set through all repeated/conflicting/stale/other-session actions. The explicit registry list adds MJ-FD01 and MJ-CELL-BV01 in the actual registered order. Network, backend denial, session, idempotency and health-filtering assertions remain. No production authority changed.

### RED/GREEN and verification scope

All checks use Node24.22.2/pnpm10.32.1 and preserve exact argv/cwd/relevant environment/Git/changed-file hashes, own exit or signal and log hash. Workers retain bytecode-free Python settings; no engine/native worker campaign was launched. Counts below overlap and are not summed.

- Initial scratch `ci-conflict-red` is a quoting SyntaxError, preserved with its invalid helper; it is NOT behavioral evidence. Corrected `ci-conflict-red2` throws `PORT_CONFLICT_REACHED_SUPABASE_START` against real old CLI under owned stubs. No real Supabase command ran in that reproducer.
- `fix1/source-red`:8failed/1passed/47filtered. Seven initial CLI conflict/unreadable variants fail the expected early-refusal assertion against old code; the coherent arm64 case passes upstream public admission and fails the case/blocker/gate comparison. Filtered tests are not_run.
- `fix1/lab-lint-red`:1failed because the integrated old command reports the generated debugger violation. This is a genuine behavioral RED, not a missing helper/import.
- `source-green1`:9passed/47filtered. `source-port-broad`:2files/18passed, including added malformed/duplicate ID/container/null/invalid-binding variants, bounded timeout/output overflow, valid nonconflicting start boundary and owned host-bind cleanup.
- `source-combined`:all5files/104passed on final committed Source code/test bytes: owned-ci-ports, owned-ci-config, sim-extension-qualification, r3-native-readback, r2b-readback. Existing historical recorder-plan tests use their owned fake Docker executable, not installed Docker. Synthetic R3/ROS bags remain protocol/readback evidence, not native execution.
- `legacy-green`:29passed/1failed, because my first explicit registry update placed the two entries in the wrong order. That failed attempt is preserved. `legacy-green2` runs both complete corrected files and passes30/30.
- `lab-lint-green`:both requested files/16passed; this includes the integrated invocation's successful and deliberate failing lint outcomes, not a full mock-chain rerun.
- Actual changed prerequisite `actual-owned-ci-refusal`:own exit2 in under1second, `CI_PORT_INVENTORY_NOT_RUN`, `CI_PORT_INVENTORY_CONFLICT:57424`, `servicesStarted:false`. This is the required local service refusal, not a full-CI pass or another availability probe. Existing unrelated Supabase services remain untouched.
- Source contracts, full typecheck, scoped lint of all changed code/test files and staged diff-check exit0. Lab typecheck, final-pin typecheck and check:source exit0. Clean export/import/sync, checker identity, both commits and final byte audit have their own exit0. No full Source build/test/browser chain was rerun during this narrow correction. The initial successful build belongs only to6e5eee9.

### Original failed mock and cleanup

The already-started original-tuple mock invocation was stopped after its failures were known, before product edits. `stop-owned-failed-mock` records a verified root PID63988 with the exact external --out argv and its3descendants; the recorder was frozen before signaling the snapshot hierarchy leaf-first with SIGINT, then resumed to deliver its pending SIGINT. No PID remained after2seconds; no TERM was needed. No pattern kill or unrelated process cleanup occurred. The wrapper's own receipt is `exitCode:null, signal:SIGINT`, not a completed mock result.

Partial original mock results: Source typecheck/contracts exit0; unexcluded lint exit1 with1647problems; referenced suite exit1 with282passed/4failed/1skipped of287. The skip is the explicit LAB_V2_MEASURE telemetry/memory opt-in and remains not_run. Source unit was interrupted with no complete result; every later contracts/engineering/Python/Lab/browser/offline/performance step is not_run for this invocation. No manifest was fabricated for the partial chain. The production web capture remains a separate pending measurement.

Original actual outputs remain at `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-6e5eee9-aricgzue`: refused OCI attempt plus partial mock. `fix1/external-original-tuple-index.json` hashes all14files. Earlier successful current arm64 image remains ONLY the6e5eee9producer, tag `mekoniq-final:6e5eee9-web05`, config `sha256:1b2bcbc1eb37fb1dd0606922df85ab6e9869fd7aedff6acc02d05d04935eb941`. It is not the bab05a5image and cannot be reused as current-tuple qualification. OCI remains unbuilt/refused due `LOCAL_BUILDER_REQUIRED`; no builder was provisioned/changed. Linux host assignment remains absent.

### Retention, byte attribution and reproduction

`fix1/final-byte-attribution.json` verifies9Source/5Lab committed file bytes, clean exact heads/trees, full patches, installed/exported pin/runtime, all58schemas and226native/238portable references. It verifies1040indexed predecessor file entries across five retained B10/L06 indexes; these are file-entry counts, not distinct execution runs. The original3778byte report prefix is preserved, SHA256 `808ad562c50e65353737c5ee71d299f08b281be0a2606fa062c250f5c76782ef`. No original SQLite database was opened; byte hashing does not execute a database engine.

`fix1/check-index.json` has22checks; `check-index-complete.json` adds final audit's own receipt as the23rd. `checked-file-attribution.json` maps each final file to exact same-byte receipts, without claiming every check behaviorally covers each file. It also confirms42initial evidence files unchanged. Raw logs include intentional failures and corrective attempts. The final retention inventory excludes only itself and records scratch symlink metadata separately; no historical log/report/candidate was rewritten.

Reproduce scoped checks from the fixed commits with frozen dependencies:

```sh
# Source, Node24.22.2/pnpm10.32.1; no native/Docker availability probe required by unit tests.
PYTHONDONTWRITEBYTECODE=1 PYTEST_ADDOPTS='-p no:cacheprovider' pnpm exec vitest run tests/unit/owned-ci-ports.test.ts tests/unit/owned-ci-config.test.ts tests/unit/sim-extension-qualification.test.ts tests/unit/r3-native-readback.test.ts tests/unit/r2b-readback.test.ts
pnpm exec vitest run tests/integration/lab-v2-contracts.test.ts tests/integration/lab-v2-mock.test.ts
pnpm contracts:check
pnpm typecheck
# Lab sibling checkout at1f9b48d, matching clean pin:
pnpm exec vitest run tests/unit/recorder-lint.test.ts tests/unit/regression-recorder.test.ts
pnpm check:source
pnpm typecheck
```

Exact bounded argv/environment/receipts are in the complete check index; historical retained tests still require both digest-bound corpus selectors. Reproduction of historical L01/native evidence must use its exact recorded clean checker checkout and graph, not this later commit. Subject, checker, installed-host and later publication identities remain separate.

**Next:** root audits this complete correction and dispatches fresh scoped review. No final recording resumes until PASS at this replacement tuple. Full owned-service CI remains not_run with occupied fixed ports; actual final mock/IR-SIM/R1/R1.1/R2a/payload/cell/study/web/WEB05/R2b/R3prepared chain, performance/390px observation, versioned final design/GTM/ruling/review retention, link audits and the ONE whole-branch review remain pending. Native collector gaps, physical/calibration/human acceptance, `accepted:false` and `not_calibrated` remain unchanged.

## Resumed final recording at reviewed bab05a5 / 1f9b48d

Read the full19,633B scoped review PASS/APPROVE and complete updated final dispatch. The prior17,250B report prefix remains byte-identical. Fresh outputs: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-bab05a5-wnbyr2rt`; new own-exit receipts under `evidence-final-recording/bab05a5/checks`. Contracts/typecheck/reviewed lint/build pass at the clean current tuple. Owned Source CI refused with `CI_PORT_INVENTORY_COMMAND_FAILED`, servicesStarted:false; this is not a free inventory or full CI pass. No availability or incompatible OCI retry occurred. The authorized new current-tuple arm64 WEB05 image build is still pending. Full fresh mock regression is active; its Source referenced selection has286passed/0failed/1opt-in measurement skipped,287total. That skip remains not_run for this invocation.

Five actual profile-scoped prepared R3 records now exist (MuJoCoamd64/arm64, engineeringamd64/arm64, xArm), each made from current clean Source/export/Lab bytes, missing native inventory and a newly empty native-records directory. Every record passed the production recorder, public directory CLI and all12acceptance tests. R3.0tested only; R3.1/R3.2not_run, accepted:false, not_calibrated. `profile-records-before-puma-finding.json` binds their exact qualification hashes and paths. These are real preparation/readback invocations, not native execution; profiles retain absent-host/tooling/package/source/image prerequisites separately.

PUMA handoff assembly failed the public L00 verifier before any PUMA qualification candidate was recorded. Required selected native closure contains99-byte `robotics/manipulation/vendor-source/.gitattributes`, SHA25637991456045b2f43a9a624e14f2af90c33645175a0a3eabc14b19c4da83359fc. Its exact package and source reference paths fail HandoffRef schema; the matching safePath reader also forbids leading-dot segments. Full native closure membership cannot be dropped or relabeled. Failed actual assembly and verifier output are retained; root received the concrete incompatibility before any code or output edit. The metadata source is current committed files, no fabricated native inventory or supplied-host claim. The unresolved source/package fields are explicit preparation placeholders. Further coordination is pending; no product correction has been made.

## Prerequisite correction 2 — PUMA closure and three unit integration fixes

**DONE_WITH_CONCERNS — narrow correction ready for independent scoped review.** Root authorized the complete `README/fix-final-prerequisites-2-dispatch.md` before product edits. No helper/reviewer, broad final campaign, new image build, Docker availability/OCI retry, native/controller/physical execution, merge/push/deploy/spend/outreach or original-main change occurred during this correction. The ONE whole-branch review and final recording remain pending.

### Disposition of the interrupted bab05a5 phase

The five prepared records and the failed386-ref PUMA assembly remain unchanged at their recorded bab05a5/1f9b48d tuple. Public negative readbacks on new copies rejected missing runtime, corrupt runtime and wrong subject; the wrong-subject copy reached R3_SUBJECT_BINDING with original artifact bytes intact. The corruption/missing tests also hit inventory/integrity boundaries and are not claimed as broader semantic refusals.

Root authorized stopping the known-failed mock and pending image because a new schema/closure tuple would invalidate reuse. `bab05a5/checks/stop-owned-failed-jobs` records exact recorderPID75855 and image-shellPID75751 argv plus four descendants (86386,75805,86671,75808), freezes the proved roots, then signals only that enumerated hierarchy. No enumerated PID remained after2seconds; noTERMtarget existed. No pattern/global kill or unrelated resource stop/prune occurred. This is a recorded hierarchy cleanup, not a system-wide process proof.

Mock's own receipt: SIGINT/exit:null at2026-11-15T12:57:23.291Z after starting12:47:18.345Z. Completed steps: Source typecheck/lint/contracts-check0; referenced286passed/0failed/1opt-in skipped of287; unit1031passed/3failed/0skipped of1034; contracts105passed. Engineering was interrupted; all subsequent Python/Lab/browser/offline/performance steps are not_run. No completed mock manifest was fabricated. The optional LAB_V2_MEASURE case was not executed and remains not_run, separately from pending production performance.

Image's own receipt: exit1, no signal,12:47:05.797Z–12:57:23.351Z. Its actual log says the Docker socket connection was interrupted and forced shutdown. No new image/config identity or successful build is inferred. Generated package/bundle/context bytes were copied before owned shell cleanup to the fresh external `current-image-build-context/`; they are unbuilt inputs, not an image. The original6e5eee9successful image stays separate. Service inventory failure remains no-proof-of-free-ports, not permission to use unrelated Supabase services. No more expensive campaign was started after root's hold.

### Exact fixed tuple and complete packages

FIX_BASE: Source `bab05a5311a9db3be447519b3b9ac48eb0e4a90d` / Lab `1f9b48d6d2767bdcd623f08cfa45ba0f9af33d1d`.

- Final source: `2bd66e679aba431a84736eb10e04717dc4d32ce7`, tree `a2304bf4040ca84e8c3df25537e078049d8709b8`, clean. Package `evidence-final-recording/fix2/source-fix-base.patch`: 14,488bytes, SHA256 `262a085b8ea22fa291af4e6438bf618a874177cf02136cc9087b6a542353a047`; 5changed files.
- Final lab: `111ed9a763a5fea24ab3180834c83c1db97417dd`, tree `d43ad1dfb26cb8255004459dcefb5d0de17c3eb5`, clean. Package `evidence-final-recording/fix2/lab-fix-base.patch`: 2,794bytes, SHA256 `3777cf8a7614d993e033793dc1037bbb0d1979b43e63b596c601b856f4a70f47`; 3changed files.

Source commit: `fix: admit pinned vendor metadata in native handoffs`; Lab commit: `chore: pin source runtime 2bd66e6`. No evidence-publication commit has been made. Source changes exactly the schema, matching native-handoff reader and three affected unit files (one new). Lab changes only its pin and two generated Source-commit headers. Generated contract shapes did not change.

### Production path policy and legacy test changes

The HandoffRef path/sourcePath schema and reader now admit `.gitattributes` only as an exact final file leaf, directly or below ordinary admitted components. No hidden directories or other hidden files are admitted; `.gitattributes/child` remains refused. The full-match negative lookahead, ASCII components and existing length bound reject terminal newline/control, empty/dot/dot-dot, absolute and backslash paths. Hash/size/aggregate, secret-content/path, symlink/nonregular/change, collision and complete closure/subject checks remain. The99-byte vendor file is unchanged at SHA256 `37991456045b2f43a9a624e14f2af90c33645175a0a3eabc14b19c4da83359fc`.

The new PUMA regression constructs a coherent handoff with the complete actual current native closure, not a one-file synthetic list or standalone regex. It derives the real production native inventory, supplies every member with its exact Source bytes and uses the real PUMA document adapter. Its outer protocol fixture/runtime is test data, not a claim of installed-host execution. It checks public validator/export and every exported native member, direct-leaf admission, baseline-admitted removal/corruption/symlink/secret/collision refusals, both schema fields and complete reader path refusals. Full clean actual producer/export/readback evidence below separately replaces the unit fixture scope.

The capability test keeps its exact historical BEFORE snapshot and explicitly accounts for the three known MuJoCo additions. The exact arm-provider set list names arm-only and cell sets; a new complete expected cell object checks simulation/simulated, exact backends/providers, MJ-CELL-BV01-only and single_world. Existing arm-only scenario/refusal/mock/disabled/oracle assertions remain. No production catalog/authority changed.

The doctor scratch fixture copies actual native-inventory.mjs and its actual schema and declares a scratch symlink to the pinned installed Node dependency tree for Ajv. It does not mock doctor results. Both complete old unit files preserve the expected doctor prerequisite exit2, successful actual Python compiler import, no native image lock/stack, and absence of __pycache__/.pyc. The dependency symlink is a test-only resolution reference, not an archived dependency closure or native proof.

### RED/GREEN and required checks

- `puma-red`:20tests,7failed/13passed. Both valid full-closure/direct-leaf positives fail admission; five corruption/security variants fail their valid-baseline assertion first. Those five REDs do not demonstrate unsafe admission. Existing path refusals already passed. The earlier actual public PUMA schema failure remains the independent clean-producer reproducer.
- `puma-green`:all3files/32passed, including both complete legacy files and initial20PUMA cases. `focused-combined`:all8files/227passed, including native-handoff unit/security/checker, R3 qualification/native readback and complete capability/doctor files. Historical recorder-plan cases retain their owned fake Docker; no installed Docker probe is inferred.
- First Source typecheck failed only an unused @ts-expect-error in the new typed closure import. That failure remains. After removing the annotation, full `source-type2` passes. This comment-only adjustment postdates227; `puma-final` reruns all22PUMA tests on exact final test bytes, and `final-test-lint` checks those final bytes. Other seven focused files and all product/schema bytes are unchanged from227. Counts overlap and are not summed.
- Contracts regenerate/check pass; regeneration produces no generated TypeScript shape diff. Scoped Source lint of all changed code/test files and staged diff-check pass. Source commit precedes a normal clean export; no dirty/identity bypass exists.
- Lab import/sync/check:source/typecheck pass. Five relevant Lab files/33tests pass after the new pin (runtime artifact, both engine-launcher admission readers, recorder and actual lint behavior). This is not a broad browser/engine campaign. Lab pin/header commit is clean.
- Every command has its own argv/cwd/environment/timing/exit-or-signal/log hash and checked-byte state. `check-index.json` has27entries before final audit writes its own receipt; `check-index-complete.json` has28including it. `checked-file-attribution.json` maps all5Source/3Lab final file hashes to matching checked bytes, without claiming each command behaviorally covers each file.

### Clean export, schema and closure identities

Runtime `5678c2f0cc62713b61790cd2b1847b38219c1b1d1882f6a33463bcb36ad2d2d9`; raw manifest `a9423c2c6ade10a66530d98481229bbbe9509a4db166ed05f83f3b62ea75eb5f`. Schema `0d4ae124258123d27a21b67a8441dee13d703fd5ab7596ad298bcab9233a31e5` / 58files. Native `79018e0a2601d8a27d3739751910bb392c86c2857cc39ad5fb451a977de78634` / 226files; portable `30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b` / 238files. Full audited checker `4598c7ab2b4d7fc7e991ca5af8f485982197140b0108cdbb240052f5d7a808f2` at Source `2bd66e679aba431a84736eb10e04717dc4d32ce7`.

Both closures were recomputed from actual bytes; their complete path lists/counts are preserved and their only changed entry is native-handoff-v1.schema.json. All58schema bytes were compared to the export and their aggregate recomputed. The new runtime and installed Lab manifest/lock match. All prior runtime caches/exports remain; the previous pin is retained by the importer. A changed schema/closure invalidates transferring any bab05a5 execution or five prepared records to this tuple.

Fresh actual outputs: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix2-gj0p2i0a/`. Its clean `export/` has an exact retained60-file copy at `fix2/export-final/`.

### Actual complete PUMA public validation

At the clean final Source/Lab tuple, a new `puma-input/` was assembled from all current portable/native/schema bytes, exact PUMA reference inputs, the clean export and Lab pin. It declares unresolved package/source locks and has no inventory; no native facts were invented. The complete386refs include every226native member and unchanged99-byte .gitattributes.

Actual commands, each separately receipted and exit0:

```sh
node scripts/native-handoff.mjs verify --input <fresh-root>/puma-input
node scripts/native-handoff.mjs export --input <fresh-root>/puma-input --out <fresh-root>/puma-export
node scripts/native-handoff.mjs verify --input <fresh-root>/puma-export
node scripts/record-sim-extension.mjs --release r3 --handoff <fresh-root>/puma-export --native-records <fresh-root>/native-empty --profile puma560-linuxcnc-sim --scope prepared --out <fresh-root>/r3-puma-prepared --candidate-id r3-puma-fix2-2bd66e6
node scripts/verify-r3.mjs <fresh-root>/r3-puma-prepared
LAB_SIMEXT_EVIDENCE_DIR=<fresh-root>/r3-puma-prepared pnpm test:acceptance -- sim-extension
```

L00 verify/export/readback returns prepared:true/nativeReady:false with PACKAGE_LOCK_UNRESOLVED, SOURCE_LOCK_UNRESOLVED, HOST_INVENTORY_MISSING. Its smaller static CLI graph is `d346b48d8c0af721dcfbdd3fcac6153b869d161552df9e85da197d568a28d2f3`, separate from the full R3 checker graph above. R3 production recording, mandatory public readback and all12acceptance tests pass at prepared scope only: R3.0tested, R3.1/R3.2not_run, every native/PHYS case not_run, accepted:false/not_calibrated. No signature sidecar was supplied. PUMA controller/GUI/install/trust/timing/Cartesian/fencing/security observations remain missing; assigning a host alone does not implement them.

Exact qualification SHA256 `88c1642227e841e1312b73bd743ec6a88d50aad27cd5d9eb029c9c77964d8130`. `puma-export-ref-index.json` binds all386ref bytes; `external-retention-index.json` binds all1222fresh external files/38,097,855bytes. Public record is immutable; no outcome/hash/case/acceptance field was edited.

### Preservation and index history

The audit verifies1040B10/L06 predecessor indexed file entries,130fix1entries,42initial entries,111bab05a5phase entries and3733bab05a5external entries. Counts describe indexed file entries, not distinct execution runs. Original failed PUMA manifest/hash/index, all five completed old prepared records, failed unit JSON, raw logs and unbuilt image context remain unchanged. Hashing files is not opening original SQLite with an engine. Root's separate defect audit also binds all11original PUMA inputs and386refs.

Index bookkeeping explicitly: I initially appended the three unit/job dispositions to the PUMA handoff README after creating its original11-input index. To preserve that original indexed README, its exact original bytes were restored; the complete appended intermediate was retained as `README-appended-intermediate.md`, and the new content is separately `supplement.md`. Original `input-hashes.json` again describes its original11files byte-for-byte. `supplement-input-hashes.json` and the identical `supplement-input-hashes-before-readme-restoration.json` describe the intermediate pre-restoration snapshot; they are historical, not current-byte validators. `supplement-complete-input-hashes.json` is the current complete PUMA supplement index, SHA256 `6135bcc08f4a5a4fb490f6cb98c84648a4b5463b4507ac3ac4a46fe559b7ac07`. The later phase-retention index binds the actual current file bytes, including those historical indexes. No failed result or evidence identity was rewritten by this bookkeeping restoration.

The original17,250-byte report prefix SHA256 `a88ec210dae676cebc0e03d44638827f146602f4c0ea6874068e27c2d277efe8` remains unchanged, as does the19,627-byte pre-fix2 prefix saved locally. Exact full Source/Lab patches, all receipts, final byte attribution and retention indexes are in `fix2/`. Source self-review covered all five scoped files and actual schema/reader/fixture boundaries; Lab self-review covered the complete pin/header diff. No independent reviewer was dispatched by this agent.

**Next:** root reads/audits this correction and dispatches fresh scoped review. After PASS, front-load complete available local regression and six-profile prepared/readback at the replacement tuple before any long image/engine campaign, as directed. Full Source service CI, fresh complete mock/IR-SIM/R1/R1.1/R2a/payload/cell/study/web/WEB05/R2b, final performance/390px observation, final design/GTM/decision/review retention/link publication and the ONE whole-branch review remain pending. Native/hardware/calibration/human acceptance and installed-host authenticity remain open. No final parent-completion claim is made.


## Resumption after correction2 — current-tuple front-loaded regression and third prerequisite handoff

The full33938-byte report prefix above remains byte-identical (SHA256e9e94faa374c794ffc77c1ad68af563c4be2bedcc3a344b28177035f481ee7f7). This phase uses reviewed Source2bd66e679aba431a84736eb10e04717dc4d32ce7/treea2304bf4040ca84e8c3df25537e078049d8709b8 and Lab111ed9a763a5fea24ab3180834c83c1db97417dd/treed43ad1dfb26cb8255004459dcefb5d0de17c3eb5. Fresh external root: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-2bd66e6-z_x0yu_o`. Every own receipt/log is under `README/evidence-final-recording/2bd66e6/checks/`; source/lab before/after identity is recorded there. Product trees stayed clean throughout these executions.

Contracts/typecheck/reviewed whole authored lint/build passed. The one allowed actual owned-CI admission exited2 with CI_PORT_INVENTORY_NOT_RUN/CI_PORT_INVENTORY_COMMAND_FAILED and servicesStarted:false. This is not proof of free ports; service suites/full Source CI remain not_run. Latest relevant Docker prerequisite remains unreachable, so no current image/WEB05/OCI retry or unrelated Supabase operation occurred. Old6e5 image cannot qualify this tuple. R93 now authorizes a genuine partial R2a --skip-suites after current R1/R1.1 qualify, separate unchanged-table non-container supplementary runs, and full R2b with derived REG04failed/R2A_GATE_NOT_TESTED preserved. No such new engine/candidate campaign started before resolving this front-loaded regression.

All five newly prepared scopes—mujoco-linux-amd64, mujoco-linux-arm64, engineering-amd64, engineering-arm64, xarm6-jazzy-sim—completed actual L00 assembly/verification, R3 prepared recording/public readback and12acceptance tests each (25own0 checks). Directories are handoff-PROFILE and r3-PROFILE-prepared under the fresh root. Their schema/native/portable/checker/runtime identities bind2bd66e6/111ed9a, all accepted:false/not_calibrated and native/physicalnot_run. The driver inherited opaque candidate-id strings ending `final-bab05a5`; these literal strings are retained unchanged and are not producer commit fields. No old record was relabeled; fresh directories and identity bindings establish the current preparation scope. Future driver arguments will use the actual new tuple spelling. Reuse the already-current reviewed correction2PUMA preparation (`r3-puma-prepared` under the fix2external root), qualificationSHA88c1642227e841e1312b73bd743ec6a88d50aad27cd5d9eb029c9c77964d8130; no pointless re-record. Six profile preparations do not assign a native host or close native/controller/hardware gates.

The full physical-robot-lab mock recorder completed naturally with own1 and final immutable manifest. Actual failed steps: source-unit1055passed/2failed/0skipped of1057; source-engineering669passed/9failed/43skipped of721; broad Lab browser discovery0executed with a global missing-JSON-attribute error; runtime browser discovery0executed with that error plusNoTestsFound. Empty recorder notRun does not erase skips/global errors. Source referenced286passed/1opt-in skip; contracts105passed; Python simulation217total/216passed/1ROS/rclpy collectionskip; Lab unit/integration593passed/1opt-in skip. Selected mock browser14passed and offline browser3passed. Lab check:source/type/build/offline-build passed. The60s UI-only measurement passed its desktop3D/emulatedtablet2D buffer/paint targets (render framep9516.7ms, paintp952.5/3ms); this is not the185s shared-cell production capture. Separate Python agent/commissioning/schema baseline178passed.

The Source unit failures are preserved with original complete JSON/log and exact timestamps. One xArm fixture failed before its wrong-hash mutation: spawnSync status:null/empty stderr, original child error/signal unavailable,906081ms despite15000ms timeout. Actual host Sleep20:28:22→DarkWake20:43:30 (908sec) overlaps file20:28:13.788→20:43:30.533. This establishes the host event and overlap, not exact child termination provenance. The replay failure was20:23:47.920→20:24:18.571, predating sleep, with30070ms assertion duration at an unchanged30000ms limit; JSON reporter gave STACK_TRACE_ERROR.

Root authorized a serialized no-world-spawn diagnostic on a digest-verified fresh owned copy. It passed: both10851records, export/reportH10850, opens0, original82-file inventory unchanged. Separate epoch/monotonic stage times: copy.055s/open.070s/concurrentcaptures12.454s and13.391s/export5.845s/report6.270s/close0s. Roughly25.6s pipeline leaves little30s test margin but does not prove the original timeout cause. ONE complete unchanged caffeinated rerun passed39tests (native37/replay2); replay23.278s. It does not promote the full1055/2run to green. No timeout or replay code edit was made. A transient owned `caffeinate -dims -w97360` PID5249/session6377 covered the remaining mock lifetime and exited0 naturally; future long invocations use transient owned caffeinate from the start, with no settings change/unlock.

Three engineering assertions still count legitimate startup `.runtime-owner.sqlite` as run allocation (native-gateway1/readiness2). Four wire-deadline and two SIL-review errors used absent hardcoded `.venv/bin/python`; BV01-SIL setup also failed there, leaving37pending cases. Other pending engineering cases include optional collision/Pythonbridge, clean-export opt-in, two container cases and stream measurement. Root authorized a real new ignored `.venv/` with absent-path/ignore guards; exact requirements-dev SHA991eb183d7e1f299632f8cc4eded3c6ae82e0332161266c0ef4dda0cd63f11b3 installed into that owned environment. Python3.11.15; pytest9.2.0/rfc8785.1.4/jsonschema4.26.0/rfc3339-validator.1.4/PyYAML6.0.2; pipcheck and actual compiler/arm-controller bridge imports passed, origins all recorded. No existing venv was changed. Dependency installation used package metadata/downloads plus cache as raw pip log records; no native ROS/Gazebo install. The earlier read-only existing environments had PyYAML6.0.3, so were not an exact pin match.

After environment repair the three complete unchanged Python-dependent engineering files gave60passed/2failed/1skipped. Wire-deadline7pass and SIL-review19pass. BV01-SIL34pass/2fail/1clean-source runIf skip: scratch copies omit robotics/manipulation, and nativeToolClosure throwsENOENT before both intended worker/import mutation refusals. This was reported before extending correction3; proposed minimum is current complete closure fixture roots, preserving explicit mutated paths and both admission refusals. No production authority change is indicated.

Lab discovery's actual metrics-transitive graph reaches16JSON imports without attributes in4modules, with5already-correct attributed imports. Actual raw errors and a static corroboration graph are retained; discovery is not browser execution. Root issued `fix-final-prerequisites-3-dispatch.md`: scoped test expectation/import corrections, exact environment provenance, clean export/pin and ONE new full owned mock validation before scoped review; no new qualification/physics/image/performance campaigns until approved. All remaining opt-in measurements/adapters/security scheduled after the failed mock remain not_run at this point; no intention is counted as execution.

Complete narrow handoff: `README/evidence-final-recording/2bd66e6/unit-failure-handoff/` (original inputs/failure assertions, timestamps, exact importer graph, diagnostic results and hashes). Raw external mock/diagnostic outputs remain unchanged. Root's original28-entry audit is `root-final-2bd-mock-failure-audit.json`. Later addenda/index versions will explicitly identify their scope rather than pretending a superseded index covers new bytes. Final docs/GTM/retention/publication and actual production/browser/campaign recording remain outstanding after correction3review; Lab README shared-cell/replay walkthrough is tracked for post-recording publication only.

Own-exit index (all output SHA256/full argv/cwd/env/checked bytes in each receipt):

| Check | Own exit | Signal |
|---|---:|---|
| `acceptance-r3-engineering-amd64` | 0 | none |
| `acceptance-r3-engineering-arm64` | 0 | none |
| `acceptance-r3-mujoco-linux-amd64` | 0 | none |
| `acceptance-r3-mujoco-linux-arm64` | 0 | none |
| `acceptance-r3-xarm6-jazzy-sim` | 0 | none |
| `entry-inventory` | 0 | none |
| `focused-two-unit-files` | 0 | none |
| `handoff-engineering-amd64` | 0 | none |
| `handoff-engineering-arm64` | 0 | none |
| `handoff-mujoco-linux-amd64` | 0 | none |
| `handoff-mujoco-linux-arm64` | 0 | none |
| `handoff-xarm6-jazzy-sim` | 0 | none |
| `host-sleep-observation-recent` | 0 | none |
| `host-sleep-observation` | 0 | none |
| `legacy-python-environment-inventory` | 0 | none |
| `mock-regression` | 1 | none |
| `owned-source-ci` | 2 | none |
| `prepare-engineering-amd64` | 0 | none |
| `prepare-engineering-arm64` | 0 | none |
| `prepare-legacy-python` | 0 | none |
| `prepare-mujoco-linux-amd64` | 0 | none |
| `prepare-mujoco-linux-arm64` | 0 | none |
| `prepare-xarm6-jazzy-sim` | 0 | none |
| `python-dependency-imports` | 0 | none |
| `python-wire-bridge-import` | 0 | none |
| `readback-r3-engineering-amd64` | 0 | none |
| `readback-r3-engineering-arm64` | 0 | none |
| `readback-r3-mujoco-linux-amd64` | 0 | none |
| `readback-r3-mujoco-linux-arm64` | 0 | none |
| `readback-r3-xarm6-jazzy-sim` | 0 | none |
| `record-r3-engineering-amd64` | 0 | none |
| `record-r3-engineering-arm64` | 0 | none |
| `record-r3-mujoco-linux-amd64` | 0 | none |
| `record-r3-mujoco-linux-arm64` | 0 | none |
| `record-r3-xarm6-jazzy-sim` | 0 | none |
| `replay-timing-diagnostic` | 0 | none |
| `source-build` | 0 | none |
| `source-contracts` | 0 | none |
| `source-lint` | 0 | none |
| `source-python-baseline` | 0 | none |
| `source-type` | 0 | none |
| `unchanged-python-dependent-engineering` | 1 | none |


## Correction3 committed scope and complete validation — new browser failures retained

The preceding 43,826-byte interim report and its original 33,938-byte prefix are preserved. This appendix clarifies the earlier compact version strings: rfc8785 is **0.1.4** and rfc3339-validator is **0.1.4**, as the original pip/import receipts already record. The BV01 dirty-checkout guard is skipped/not_run on a clean tree; its earlier shorthand is not a clean-source passing case. The old UI microbenchmark reports synthetic 10 Hz telemetry, frameIntervals (RAF-style intervals) and workspacePaint on desktop 3D and an emulated tablet 2D viewport. It has no runtime execution, shared-cell worker/actual-draw/1× or physical-tablet scope. No new measurement of that old result was requested or performed.

The complete correction3 dispatch, including the BV01 fixture and three additional import-edge addenda, was read before edits. Source commit `229efa7f565876f8f9d69634f8fbc24b9196ed3f`, tree `9e603c2766f2f468203a8a722fc23f54fef4c49f`, changes only three test files. Native-gateway failure preserves status 500 and binds its one actual attempt directory to the production factory-provided path, against the explicit `.runtime-owner.sqlite` startup baseline. Readiness retains the exact baseline after refused create/probe, including 422/WORLD_REVISION_MISMATCH, CSRF 403 and blocked-world checks. BV01 scratch fixtures keep all eight original roots plus the five authorized missing roots and verify full closure equality before the two concrete worker/import mutations. Successful pre-mutation provider admission, both pin/identity refusals and zero bridge sends remain. Production authority, closure and timeout policy were not changed.

Lab commit `ba1d0e01b9542dbefe8e21a95a561ea2d0b83f59`, tree `ca7b80ffa988d378a239efc1b9dedae5fd4e36f0`, adds 19 JSON import attributes in six demonstrated modules and updates the pin/two generated headers (nine changed files total). Real Node24 discovery changed from own exit 1/zero tests/global JSON-attribute error to 104 discovered tests in 28 files. The first corrected build's three attribute-consistency warnings remain in its original log; the explicitly authorized adjacent three edges resolved all three in the subsequent build. No import sweep, loader, validator stub or discovery exclusion was introduced.

Fresh external correction root: `/var/folders/92/wsfpj2x14hd3690cwlp639900000gp/T/mekoniq-final-fix3-n4t809l_`. The clean 60-file export, installed manifest/runtime, current source bytes and generated headers were checked. Runtime artifact is `2b7ab594467fcbcb0a68fc370ee839cedacd9ea977d26859761b341cc77e613c`; raw manifest SHA256 `a84105bbd94b63e50c08de4b74bad6b3fdcfede0c9df13cb3854767b47fa5b59`. Schema digest stays `0d4ae124258123d27a21b67a8441dee13d703fd5ab7596ad298bcab9233a31e5` (58). Native `79018e0a2601d8a27d3739751910bb392c86c2857cc39ad5fb451a977de78634` (226 / 1,578,397 bytes) and portable `30dc0de3e034b14593ae3629a1f247724392d950578913cacc1dd2e9ca9bc69b` (238 / 8,116,001 bytes) exactly match prior path lists and bytes. Full R3 checker is unchanged `4598c7ab2b4d7fc7e991ca5af8f485982197140b0108cdbb240052f5d7a808f2`, checked at the new Source commit. Prior 2bd prepared records remain prior-tuple records, not this new tuple's preparations.

Focused correction checks passed: 78 Source tests across five complete files (the dirty-tree guard actually executed before commit), Source typecheck/authored lint; 92 Lab tests across 13 complete files, then 49 additional archive/model tests across seven complete files after the small consistency addendum; Lab typecheck/build/final discovery/check:source. These overlapping scopes are not added into a unique total. Full outputs and own receipts are in `evidence-final-recording/fix3/checks/`. Exact complete patches and commit/stat companions were generated independently by root and are referenced without rewriting: `review-final-prerequisites-3-source.diff` (18,776 bytes, SHA256 `984e82073c351fc413fcf1f63a7941ca0f1048146bf95ba84cfe4f000be9079f`) and Lab diff (15,795 bytes, SHA256 `dd8f9b7632fd248de66ab40030a661e2fe357dc5d0a936f18da549e96c495abf`), with `root-final-prerequisites-3-git-audit.json` covering exact final Git bytes.

The ONE authorized new complete owned mock used the new declared `.venv`, explicit retained-input manifest/digest, an unset service receipt and transient caffeinate from the start. It completed naturally with own exit **1**. Only `lab-e2e-browser` failed; recorder manifest and raw outputs remain immutable.

| Complete new mock scope | Actual result |
|---|---|
| Source referenced | 286 passed, 1 opt-in skipped |
| Source unit | 1,057 passed, 0 failed, 0 skipped |
| Source contracts | 105 passed |
| Source engineering | 716 passed, 0 failed, 5 skipped |
| Python simulation | 216 passed, 1 ROS/rclpy collection skip |
| Lab unit/integration | 593 passed, 1 opt-in skipped |
| Broad browser | 60 passed, **2 failed**, 42 skipped; no global discovery errors |
| Selected mock browser | 14 passed |
| Owned runtime journey | 1 passed, 0 skipped |
| Offline browser | 3 passed |

The five engineering skips are the clean-export opt-in, two container cases, dirty-checkout guard on the clean tree, and opt-in Source stream measurement. Lab's TwinStore measurement is separately opt-in. These remain not_run. The synthetic UI microbenchmark also completed own 0 with its explicitly limited frameIntervals/workspacePaint scope; it does not qualify the unstarted shared-cell production capture. No service fixture, Docker availability/image/OCI probe, native host, physics campaign or production performance recording was started.

The actual broad browser failures were immediately reported: (1) replay-offline's blanket EventSource/WebSocket trap sees two same-origin development WebSockets, and (2) normal touch entry to watch at 390 px times out under the unchanged 30-second limit. Original JSON/default log, screenshots and DOM are indexed under `fix3/browser-failure-handoff/`. Selected/runtime/offline passes do not erase those two failures.

Root authorized ONE serialized bounded instrumented-copy diagnostic after the recorder settled. It used current unchanged Source/Lab product bytes, normal touch and original assertions/30-second touch limit, with no reused server and one worker. The external copy diff, observer/config, raw results, complete replay/1024 traces, screenshots/DOM and declared dependency symlinks are retained. Own exit **1**: 3 passed, 2 failed, 5 token-dependent skipped. This is explicitly diagnostic, not an unchanged-test pass.

Constructor provenance is now proved: both blocked WebSockets use `vite-hmr` and stacks enter the actual `/@vite/client` at lines 745/755 and connect at 823. The blanket trap and /lab/hash/replay assertions remain. Root prefers a real owned production-preview fixture/entrypoint for that strict offline scope; no HMR filtering, stubbing or assumption that server.hmr:false removes constructor calls is authorized.

The 390 px JSON reporter preserves `goto-twin` completed in 35 ms, followed by `tap-enter-watch` unfinished (duration -1) until timeout. No `tap-runtime-chip` step occurs: the immediate initial visibility conditional did not dismiss the subsequently mounted unpaired popover. Failure DOM/PNG show the open Runtime/RUNTIME_UNREACHABLE panel over the viewport controls and no watch class. The 1024 px diagnostic recorded initial visibility false but its different geometry allowed ordinary touch entry/exit. Minimum proposed setup correction is an explicit wait for the known initial unpaired popover before normal-tap dismissal, preserving all watch/44px/ARIA/shell assertions and the 30-second limit.

Diagnostic limit: the timed-out 390 px worker did not finish its finally save, so its final geometry/action JSON and manual trace are absent. Do not claim complete trace coverage for that case. The precise unfinished step, both original/diagnostic DOM and screenshots are retained. Three replay traces and the 1024 touch trace are complete. No second diagnostic or product/test/config fix followed without root scope. Full diagnostic handoff is `fix3/browser-diagnostic-handoff/` (24 indexed files, two declared external dependency symlinks). Further correction/validation and the fresh scoped review are root-coordinated; correction3 is not presented as a green complete mock or release qualification.

Preservation work completed so far: `fix3/previous-phase-bookkeeping-index.json` covers 106 unchanged 2bd metadata files (746,429 bytes), and `previous-phase-external-index.json` covers 2,680 files (170,607,196 bytes). The seven original Git file snapshots are retained separately. Historical code-input hashes describe their original recorded Git commits and are not claimed to match edited current paths. Final new indices/own full preservation audit and complete handoff remain to be finalized after the narrow browser correction decision. Original native/hardware/controller/human acceptance limitations remain open.


## Correction3 final browser, focus and retained handoff — ready for scoped review

The complete 52,888-byte prefix above remains byte-identical, SHA256 `045883e6e4817032989dd56f3ddb7a52b5c7e7c82df7be4c91f19405a5e3a811`; the earlier 43,826/33,938-byte prefixes are also preserved. No failed result, candidate, screenshot or previous index was edited to obtain a pass. Sections 4 and 5 of the root-authorized correction3 dispatch were read and implemented as the same sole implementer, without helpers or reviewers. This is the correction handoff, not completion of B10/L06 or the full final recording phase.

The browser fixture correction first committed Lab `7d38565f91acbb3060dbee7d4d3560f61fa4b64c`. The strict replay spec now uses a small worker fixture that builds current Lab sources into a fresh external temporary directory and serves a real owned production preview on an ephemeral loopback port. It checks served production index, entry JS/CSS and pin bytes against that build/current pin, retains the original blanket EventSource/WebSocket and /lab denial plus all three complete replay tests, and closes only its own server/removes only its own generated directory in finally. It does not filter HMR constructors, stub application networking, reuse stale dist or skip the test.

The existing B07 external production entrypoint uses an explicit fixture option. In that mode the fixture verifies and uses the caller's actual preview/dist rather than creating, replacing, closing or deleting them; supplied browser invocation metadata is checked against served build/pin bytes. Existing B07 metadata and separately started preview requirements remain. The complete strict replay spec passed 3/3 in default owned mode and 3/3 through an actual owned B07 external preview at Lab7d38565. External invocation `c083b0cf-7843-4cc4-8126-0d1a7d3b3230` retained identical before/after full productionBuildIdentity. Six actual case bindings were decoded and checked: owned directories removed/ports released, external cases used caller4175/dist/invocation, caller build stayed unchanged and its exact server later closed. These are entrypoint/fixture checks at that earlier Lab tuple, not the final long production performance/browser qualification.

Fresh unpaired touch contexts now explicitly await the initial runtime popover, dismiss it by an ordinary runtime-chip tap and verify hidden before ordinary watch entry. All original 390/1024 viewports, actual touch, 30-second bound, watch class, visible exit, aria-pressed, minimum44px and restored shell assertions remain. The complete transport file ran through the existing owned mock launcher: 7/7 passed, including all five token-dependent serial cases. Default replay3, token transport7, type/build/check:source and the unchanged B07 cell discovery all retain their own logs/receipts. The initial helper typecheck error concerning the HTTP server union is retained; the guarded existing closeAllConnections method resolved it and subsequent full typechecks passed.

The first complete corrective broad run at Lab7d38565 remained RED: 61 passed, one unchanged brand-focus failure, 42 skipped. It and the earlier full mock at Labba1d0e0 (60/2/42 broad, overall own1) remain immutable. Root read the exact original brand failure/PNG/DOM and all six hashed inputs; the original failing run did not record its exact focus chronology. No claim is made that its precise ordering was captured.

The ONE authorized controlled brand diagnostic established a real product mechanism in two fresh contexts on unchanged Source229efa7/Lab7d38565. It held only the first startup GET /lab/v1/health, obtained the actual owned runtime's HTTP200 response (536 bytes, SHA256 `998c4876d1301244666c8c7df2b5fb170287b517d9c1f6e0bf09bd5d7fd24549`), and forwarded it unchanged after ordinary Tab focus. Old skip2 or brand3 was active with document.hasFocus true; after health completion both old nodes disconnected, new skip4/brand5 appeared, and activeElement moved to BODY while document.hasFocus stayed true. The skip context's next Tab restarted at skip; the brand context passed the original two-Tab/outline checks before release and then lost focus. Incremental focusin/out/keydown/node identities, raw response/status/timing, phase screenshots/DOM and both complete automatic traces are retained. Own diagnostic1 has two expected behavioral failures; exact launcher shutdown0 and4175/4176 release are recorded. This is controlled causal evidence, not an unchanged full brand pass. Root's independently read/hash-verified navigation audit is `root-final-fix3-brand-diagnostic-audit.json` (374 bytes, SHA256 `feeea00b1a92348076651aac7b31e3d462006569c4c71a74eaa8375a8a59964c`).

Root authorized only two stable unique header anchor IDs and a deterministic RED/GREEN regression. The product change adds `app-skip-link` and `app-brand-link` to the existing anchors, reusing render's existing by-id focus restoration. Their hrefs, classes, translations, native activation, tab order and outlines remain; no data-action route, general render refactor or forced test focus was added. A uniqueness search found no previous occurrences and exactly the two intended current source locations.

Two new delayed-health keyboard cases ran RED before product edits, failing precisely at post-replacement focus preservation. After the two IDs, both ran GREEN. They confirm old-node replacement, focus survival, onward ordinary Tab/Shift+Tab, original href/outline and native Enter behavior (skip activates/focuses workspace; brand navigates restaurant→design and retains focus). Existing canonical brand assertions were preserved. The complete seven-case brand file, full Lab typecheck/build/check:source passed.

Health-status scope is deliberately separate: the pre-fix controlled diagnostic used actual owned runtime **HTTP200**. The deterministic RED/GREEN regression and default broad browser used the real default owned-loopback proxy with runtime absent; exact annotations are **HTTP500**, with ECONNREFUSED retained in logs, explicitly labeled test-response scheduling input. Both reach health-completion rendering, but the post-fix tests are not advertised as actual-runtime200 qualification. No extra runtime200 rerun was requested or performed.

Final paired producer/code identities:

| Repository | Commit | Tree |
|---|---|---|
| Source | `229efa7f565876f8f9d69634f8fbc24b9196ed3f` | `9e603c2766f2f468203a8a722fc23f54fef4c49f` |
| Lab | `45794aa8ec7eb8a19214a6e16786455f7c948bb1` | `20fe836cc4e6bd1267a9a2e5cd62827b2e4df11a` |

Both are clean. Source/export/runtime2b7ab594 remain unchanged by these Lab-only fixes; no unnecessary Source commit/export/suite repeat was made. Schema58, native226 and portable238 paths/digests/bytes, the60-file clean export/installed copy and checker4598c7ab retain the exact identities already recorded in the preceding appendix and final-byte-attribution file. Source changes from correction3 FIX_BASE are three test files; final Lab changes from original111ed9a are fifteen files.

The ONE complete amended broad browser run on clean final Lab45794aa finished **own0/signalnull:64 passed,0 failed,42 skipped,106 total**, including the two new deterministic regressions. No global errors. Before/after commit/status/changed bytes are identical. The42 skipped cases remain not_run; the separate token-owned transport checks do not alter that immutable broad result. No green complete full mock is claimed at this final Lab tuple: the prior ba1 full mock remains failed and the final recording phase still needs any required complete current-tuple regression after independent review.

The final broad's three owned production-preview case bindings and cleanup were checked: generated build directories are gone,4175/4176 and the exact ephemeral53236 reservation succeeded/released. The observation signaled no process and deleted no file; it makes no host-wide Chromium ownership claim. Original recorded artifacts were retained. Browser logs still contain their inherited NO_COLOR/FORCE_COLOR warnings and expected absent-runtime proxy errors at stated scopes; they are not erased or converted into product failures.

Complete final base-to-head review packages are root-generated and retained separately from the earlier ba1/7d packages: Source `review-final-prerequisites-3-source-229efa7.diff`18,776 bytes/SHA256 `984e82073c351fc413fcf1f63a7941ca0f1048146bf95ba84cfe4f000be9079f`; Lab `review-final-prerequisites-3-lab-45794aa.diff`33,637 bytes/SHA256 `beb678fb44a69389c363dd9870fed59e2c64d6ddc12fc0e7fa27779b3b9efdbd`; commit/stat companion `review-final-prerequisites-3-commits-45794aa.txt` and exact Git byte audit `root-final-prerequisites-3-git-audit-45794aa.json`. The complete new brand diff was read. `root-final-fix3-preview-bindings-audit.json` provides independent navigation for both replay entrypoints/six bindings.

Own final byte/preservation audit completed0: `fix3/final-byte-attribution-45794aa.json` confirms final heads/trees/cleanliness, exact Git/package/export/pin/log bytes, historical full mock identity rather than relabeling it, final broad64/0/42 and original RED/GREEN distinctions. It verified **9,210 historical indexed file entries across14 input indices**, including the14 original external entries separately absent from the earlier9196-entry interim audit. The interim audit remains true at its named narrower scope and is not overwritten. File-entry counts may overlap across historical indices; they are not unique-test or unique-file totals. Original code-input hash lists keep their recorded Git scope; snapshots are retained and they are not claimed to describe edited current paths.

New final metadata/external retention indices and a completion receipt are retained under `fix3/`; each excludes its own impossible recursive hash and records declared diagnostic dependency symlinks separately, without copying third-party node_modules. New producer outputs remain in the fresh external correction root; no old file was removed or rewritten. Indexes are navigation/byte evidence, not host/execution authenticity or a replacement for full reports/findings.

Remaining final-phase scopes are unchanged: no assigned native/controller hosts, calibration, physical motion or human acceptance; current image/WEB05/OCI remain blocked/not_run under the latest Docker observation, with no repeated probe. Owned-service CI remains unavailable and unrelated Supabase/trial/web/operational ports were untouched. Native/R3 preparations, full remaining current-tuple regression, IR-SIM/Webots/MuJoCo campaigns, shared-cell long production capture plus390px live report case, full R2b/R3 readback, final design/GTM/review/deferred/decision/evidence publication and normal-clone link/reproduction audit remain for resumption after the first independent correction3 scoped review. No merge/push/deploy/outreach/spend/provision or publication was performed here. Root retains B10/L06 completion, final audit and the ONE whole-branch review decision.

All fix3 own checks at handoff (exact argv/cwd/env/checked bytes/output hashes in each retained receipt; overlapping scopes are not summed):

| Check | Own exit | Signal |
|---|---:|---|
| `b07-cell-discovery` | 0 | none |
| `brand-complete` | 0 | none |
| `brand-focus-controlled-diagnostic` | 1 | none |
| `brand-health-regression-green` | 0 | none |
| `brand-health-regression-red` | 1 | none |
| `browser-diagnostic-cleanup` | 0 | none |
| `browser-diagnostic` | 1 | none |
| `checker-identity` | 0 | none |
| `commit-lab-browser` | 0 | none |
| `commit-lab-focus` | 0 | none |
| `commit-lab` | 0 | none |
| `commit-source` | 0 | none |
| `export-clean` | 0 | none |
| `final-browser-cleanup` | 0 | none |
| `final-preservation-audit` | 0 | none |
| `import-runtime` | 0 | none |
| `lab-affected-unit` | 0 | none |
| `lab-archive-model-tests` | 0 | none |
| `lab-broad-browser-final` | 1 | none |
| `lab-broad-browser-focus-final` | 0 | none |
| `lab-browser-fixture-build` | 0 | none |
| `lab-browser-fixture-source` | 0 | none |
| `lab-browser-fixture-typecheck-2` | 0 | none |
| `lab-browser-fixture-typecheck` | 2 | none |
| `lab-build` | 0 | none |
| `lab-check-source` | 0 | none |
| `lab-consistency-build` | 0 | none |
| `lab-consistency-typecheck` | 0 | none |
| `lab-discovery-after` | 0 | none |
| `lab-discovery-before` | 1 | none |
| `lab-final-discovery` | 0 | none |
| `lab-focus-build` | 0 | none |
| `lab-focus-source` | 0 | none |
| `lab-focus-typecheck` | 0 | none |
| `lab-typecheck` | 0 | none |
| `mock-regression` | 1 | none |
| `preservation-audit-7d38565` | 0 | none |
| `preservation-initial-external-14` | 0 | none |
| `replay-b07-external` | 0 | none |
| `replay-default-owned` | 0 | none |
| `source-authored-lint` | 0 | none |
| `source-corrected-complete` | 0 | none |
| `source-typecheck` | 0 | none |
| `sync-contracts` | 0 | none |
| `transport-owned-complete` | 0 | none |
| `verify-export` | 0 | none |
| `verify-preview-bindings` | 0 | none |
