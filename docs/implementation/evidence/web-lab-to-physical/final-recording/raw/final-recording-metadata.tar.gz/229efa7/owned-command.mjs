import {runOwnedProcess} from '../../../../../scripts/native-sim/owned-process.mjs';
import {mkdir} from 'node:fs/promises';
const [out,timeout,...argv]=process.argv.slice(2);
await mkdir(out,{recursive:false});const abort=new AbortController();for(const signal of ['SIGINT','SIGTERM','SIGHUP'])process.once(signal,()=>abort.abort());
const result=await runOwnedProcess(argv[0],argv.slice(1),{out,cwd:process.cwd(),env:process.env,timeoutMs:Number(timeout),signal:abort.signal});console.log(JSON.stringify(result));process.exitCode=result.exitCode??1;
