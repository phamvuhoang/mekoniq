from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root'])
commands=[('source-contracts-final','source',['pnpm','contracts:check'],120),('source-type-final','source',['pnpm','typecheck'],300),('source-lint-final','source',['pnpm','exec','eslint','.','--ignore-pattern','.superpowers/**'],300),('source-build-final','source',['pnpm','build'],900),('mock-regression','source',['env','LAB_PYTHON='+str(b.parents[4]/'.venv-commissioning/bin/python'),'node','../lab/scripts/record-regression.mjs','--suite','physical-robot-lab','--out',str(root/'mock-regression')],14400)]
for name,repo,args,bound in commands:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,repo,'caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*args]);print(name,r,flush=True)
 if r:print('FAILED_REQUIRES_INSPECTION',flush=True);sys.exit(r)
