from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent;root=Path(json.loads((b/'paths.json').read_text())['root'])
commands=[('payload-campaign',['node','scripts/lab-mujoco.mjs','run','--campaign','payload-v1','--out',str(root/'payload-campaign')],7200000),('verify-payload-campaign',['node','scripts/lab-mujoco.mjs','verify','--input',str(root/'payload-campaign')],300000),('cell-campaign',['node','scripts/lab-mujoco.mjs','run','--campaign','mj-cell-bv01-v1','--out',str(root/'cell-campaign')],50000000),('verify-cell-campaign',['node','scripts/lab-mujoco.mjs','verify','--input',str(root/'cell-campaign')],1800000),('semantic-study',['env','MEKONIQ_WEBOTS_HOME=/Applications/Webots.app','SIMULATION_STUDY_OUT='+str(root/'semantic-study'),'pnpm','exec','vitest','run','tests/integration/cross-engine-fd01.test.ts','--reporter=default','--reporter=json','--outputFile='+str(root/'semantic-study-tests.json')],1300000)]
for name,args,bound in commands:
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str((bound//1000)+120)+'; exec @ARGV','node',str(b/'owned-command.mjs'),str(root/(name+'-process')),str(bound),*args]);print(name,r,flush=True)
 if r:print('FAILED_REQUIRES_INSPECTION',flush=True);sys.exit(r)
