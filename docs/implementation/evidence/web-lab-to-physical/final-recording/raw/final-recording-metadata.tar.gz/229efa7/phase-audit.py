from pathlib import Path
import subprocess,json,hashlib,os
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';sdd=source/'.superpowers/sdd';read=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();git=lambda cwd,*a:subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
assert not git(source,'status','--porcelain','--untracked-files=all');assert not git(lab,'status','--porcelain','--untracked-files=all')
assert git(source,'rev-parse','HEAD')=='229efa7f565876f8f9d69634f8fbc24b9196ed3f' and git(lab,'rev-parse','HEAD')=='45794aa8ec7eb8a19214a6e16786455f7c948bb1'
report=source/'.superpowers/sdd/README/task-final-recording-report.md';prefix=(b/'report-prefix-65925.md').read_bytes();assert len(prefix)==65925 and hashlib.sha256(prefix).hexdigest()=='0bff66551f78c0d41e0527a2c0772f8cd59c152c7d83e75199ee5e348320d7d8' and report.read_bytes().startswith(prefix)
indices=[sdd/'02-r2b-cell-and-web'/p for p in ['root-B10-evidence-file-index.json','root-B10-r1-evidence-file-index.json','root-B10-smoke-27d6be9-file-index.json']]+[sdd/'03-r3-linux-readiness'/p for p in ['root-L06-evidence-file-index.json','root-L06-r1-evidence-file-index.json']]+[sdd/'README/root-final-prerequisites-1-evidence-file-index.json',b.parent/'fix1/initial-evidence-index.json',b.parent/'bab05a5/phase-retention-index.json',b.parent/'bab05a5/external-phase-retention-index.json',sdd/'README/root-final-prerequisites-2-evidence-file-index.json',b.parent/'fix2/external-retention-index.json',b.parent/'fix3/previous-phase-bookkeeping-index.json',b.parent/'fix3/previous-phase-external-index.json',b.parent/'fix1/external-original-tuple-index.json']
preserved=[]
for p in indices:
 j=read(p)
 for f in j['files']:
  q=Path(j['root'])/f['path'];assert q.stat().st_size==f['bytes'] and sha(q)==f['sha256'],str(p)+':'+f['path']
 preserved.append({'index':str(p),'sha256':sha(p),'files':len(j['files'])})

for index in [b.parent/'fix3/metadata-retention-index-final-45794aa.json',b.parent/'fix3/external-retention-index-final-45794aa.json']:
 j=read(index)
 for f in j['files']:
  p=Path(j['root'])/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],str(p)
 preserved.append({'index':str(index),'sha256':sha(index),'files':len(j['files'])})
 for x in j.get('symlinks',[]):
  p=Path(j['root'])/x['path'];assert p.is_symlink()
checks=[]
for p in sorted((b/'checks').glob('*.receipt.json')):
 j=read(p);log=p.with_name(p.name.replace('.receipt.json','.log'));assert sha(log)==j['logSha256'];assert not j['before']['status'] and not j['after']['status'];checks.append({'receipt':p.name,'receiptSha256':sha(p),'exitCode':j['exitCode'],'signal':j['signal'],'logSha256':sha(log)})
assert len(checks)==48
root=Path(read(b/'paths.json')['root']);mock=read(root/'mock-regression/manifest.json');assert mock['revisions']['source']==git(source,'rev-parse','HEAD') and mock['revisions']['lab']==git(lab,'rev-parse','HEAD')
for x in mock['commands']:assert x['exitCode']==0 and sha(root/'mock-regression'/x['log'])==x['logSha256']
for x in mock['runs']:assert sha(root/'mock-regression'/x['file'])==x['sha256']
r3=[]
for p in sorted(root.glob('r3-*-prepared/qualification.json')):
 q=read(p);assert q['identity']['before']['sourceCommit']==git(source,'rev-parse','HEAD') and q['lab']['commit']==git(lab,'rev-parse','HEAD') and q['accepted'] is False;r3.append({'path':str(p),'sha256':sha(p),'profile':q['profile']})
assert len(r3)==6
result={'cleanSource':git(source,'rev-parse','HEAD'),'sourceTree':git(source,'rev-parse','HEAD^{tree}'),'cleanLab':git(lab,'rev-parse','HEAD'),'labTree':git(lab,'rev-parse','HEAD^{tree}'),'preserved':preserved,'preservedFileEntries':sum(x['files'] for x in preserved),'ownReceiptsBeforeAudit':checks,'sixPreparedRecords':r3,'mock':read(b/'mock-summary.json'),'reportPrefixBytes':65925,'reportPrefixSha256':hashlib.sha256(prefix).hexdigest(),'executionFreeze':'Root correction4; no new tests/campaigns/product edits','limits':['Overlapping indices are file entries, not unique files/tests','Local hashes/receipts are not independent host authenticity','Later correction4 runtime changes will require appropriate new subject recordings; no retagging']}
(b/'phase-preservation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'preservedFileEntries':result['preservedFileEntries'],'priorIndices':len(preserved),'currentOwnReceiptsBeforeAudit':len(checks),'r3PreparedRecords':len(r3),'mockOwnExit':result['mock']['ownExit'],'source':result['cleanSource'],'lab':result['cleanLab']}))
