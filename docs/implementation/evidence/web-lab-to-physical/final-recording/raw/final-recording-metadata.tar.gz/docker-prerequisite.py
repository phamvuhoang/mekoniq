import subprocess,time,os,signal,json
start=time.time()
p=subprocess.Popen(['docker','version','--format','{{json .}}'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
timed_out=False
try: out,err=p.communicate(timeout=15)
except subprocess.TimeoutExpired:
 timed_out=True
 os.killpg(p.pid,signal.SIGTERM)
 try: out,err=p.communicate(timeout=3)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL)
  out,err=p.communicate()
print(json.dumps(dict(argv=p.args,pid=p.pid,ownExit=p.returncode,timedOut=timed_out,elapsedSeconds=time.time()-start,stdout=out.decode(),stderr=err.decode(),image=None,cleanup='own detached child group only')))
raise SystemExit(2 if timed_out else p.returncode)
