from pathlib import Path
import subprocess,json,sys,datetime,os
b=Path(__file__).resolve().parent;source=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);old=Path(json.loads((b.parent/'981e234/paths.json').read_text())['root']);lab=Path(json.loads((b/'isolated-producer-boundary.json').read_text())['lab']).resolve()
assert (b/'gui-lineage-continued-completed.json').is_file(),'GUI_LINEAGE_REQUIRED'
for n in ['record-r1','record-r11','record-r2a-partial']:
 r=json.loads((b/'checks'/(n+'.receipt.json')).read_text());assert r['exitCode']==(1 if n=='record-r2a-partial' else 0) and r['signal'] is None,(n,r['exitCode'])
assert (e/'offline-vite-diagnostic-api/cleanup.json').is_file(),'CONTROLLER_AUTHORIZED_DIAGNOSTIC_MUST_SETTLE_FIRST'
def run(name,argv,bound=3600,allowed=(0,),cwd='source'):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,str(cwd),'caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,argv)]);print('DEPENDENT_R2B',name,r,flush=True);assert r in allowed,(name,r);return r
(b/'dependent-r2b-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Serialized unchangedR2a/R2b supplemental rows, real three-engine study, fullR2b with realpartial/currentweb/Source-only981physics inputs and publicreadback; no Docker reprobe/image/override'},indent=2)+'\n')
run('mock-acceptance-d4',['env','LAB_V2_REGRESSION_DIR='+str(e/'mock-regression'),'LAB_V2_REQUIRE_LAB_FIXTURES=1','LAB_V2_MOCK_EVIDENCE='+str(e/'mock-acceptance-evidence.json'),'pnpm','exec','vitest','run','tests/acceptance/lab-v2-mock.acceptance.test.ts','--reporter=default','--reporter=json','--outputFile='+str(e/'mock-acceptance-tests.json')],600)
run('r2a-supplemental-current-gui',['node',b/'supplement-tables-current-gui.mjs','r2a'],18000)
run('r2b-supplemental-current-gui',['node',b/'supplement-tables-current-gui.mjs','r2b'],18000)
run('semantic-study',['node',b/'owned-command.mjs',e/'semantic-study-process','1300000','env','MEKONIQ_WEBOTS_HOME=/Applications/Webots.app','SIMULATION_STUDY_OUT='+str(e/'semantic-study'),'pnpm','exec','vitest','run','tests/integration/cross-engine-fd01.test.ts','--reporter=default','--reporter=json','--outputFile='+str(e/'semantic-study-tests.json')],1420,(0,1))
assert (e/'semantic-study/study-input.json').is_file(),'NO_REAL_STUDY_INPUT: preserve actual failure; fullR2b cannot be fabricated'
run('record-r2b-full',['node','scripts/record-sim-extension.mjs','--release','r2b','--scope','full','--out',e/'r2b','--candidate-id','r2b-final-981e234-d4c3032','--r2a-record',e/'r2a-partial','--physics-campaign',old/'payload-campaign','--cell-campaign',old/'cell-campaign','--semantic-study',e/'semantic-study/study-input.json','--web-record',e/'web-record','--lab',lab],18000,(1,))
assert (e/'r2b/qualification.json').is_file(),'R2B_NO_RECORD'
code="import {verifyR2bDirectory} from './scripts/r2b-readback.mjs'; const issues=await verifyR2bDirectory(process.argv[1]); console.log(JSON.stringify(issues)); process.exit(issues.length?1:0);"
run('readback-r2b-full',['node','--input-type=module','-e',code,e/'r2b'],600,(1,))
run('acceptance-r2b-full',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(e/'r2b'),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/'acceptance-r2b-full.json')],600,(1,))
(b/'dependent-r2b-completed.json').write_text(json.dumps({'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All planned independent supplemental/study/normalfullR2b invocations settled; actual expected qualification failures remain. No status splicing or accepted/hardware claim.'},indent=2)+'\n')
