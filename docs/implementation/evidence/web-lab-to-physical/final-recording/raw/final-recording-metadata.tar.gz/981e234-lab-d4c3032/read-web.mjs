import {readFileSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {assessCapture,checkCaptureClock} from '../../../../../scripts/browser-capture-clock.mjs';
import {verifyBrowserArtifacts} from '../../../../../scripts/browser-evidence-readback.mjs';
const b=import.meta.dirname,paths=JSON.parse(readFileSync(join(b,'paths.json'))),root=join(paths.root,'web-record'),capture=JSON.parse(readFileSync(join(root,'actual-cell-production.json'))),tuple={sourceCommit:paths.producerSource,labCommit:paths.producerLab,artifactSha256:capture.runtimeArtifact,schemaHash:capture.buildIdentity.schemaHash};
const result={scope:'Actual unchanged public capture and mandatory browser readers, not a fabricated R2b qualification',tuple,captureClock:checkCaptureClock(capture),capture:assessCapture(capture),browser:verifyBrowserArtifacts(p=>readFileSync(join(root,p)),capture,tuple)};writeFileSync(join(b,'web-readback.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));process.exit(result.capture.valid&&result.capture.meetsTargets&&!result.browser.length?0:1);
