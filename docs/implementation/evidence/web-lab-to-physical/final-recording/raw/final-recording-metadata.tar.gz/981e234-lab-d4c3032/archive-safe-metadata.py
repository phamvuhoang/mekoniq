from pathlib import Path
import json,subprocess,sys,shutil,hashlib,os,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';assert (b/'root-publication-freeze-ready.json').is_file();source=b.parent;dest=stage/'safe-final-recording-metadata';assert not dest.exists();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();excluded={str(b/'takeover-owned-state-and-path.json'),str(b/'r1-invocation-boundary.json'),str(source/'2bd66e6/checks/host-sleep-observation.log')};mapping=[];exclusions=[]
for directory,dirs,files in os.walk(source,followlinks=False):
 out=dest/Path(directory).relative_to(source);out.mkdir(parents=True,exist_ok=True)
 for name in list(dirs):
  p=Path(directory)/name
  if p.is_symlink():(out/name).symlink_to(os.readlink(p),target_is_directory=True);dirs.remove(name)
 for name in files:
  p=Path(directory)/name;q=out/name
  if str(p) in excluded:exclusions.append({'original':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'disposition':'External private original retained; marked derivative/exclusion descriptor only is public'});continue
  if p.is_symlink():q.symlink_to(os.readlink(p));continue
  assert p.name!='.runtime-owner.sqlite',p
  shutil.copy2(p,q);assert sha(p)==sha(q);mapping.append({'original':str(p),'path':str(q.relative_to(dest)),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(exclusions)==3
(stage/'archive-receipts/final-metadata-copy-map.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Metadata snapshot before archive invocation; later publication checks retained separately. Three host-context originals excluded here; private ownerDB is separately excluded from fix3 raw archive. Original receipt log hashes remain attribution to excluded originals.','files':mapping,'exclusions':exclusions},indent=2)+'\n')
r=subprocess.call([sys.executable,str(b/'archive-add-record.py'),'final-recording-metadata',str(dest)]);assert r==0
for root in sorted((active/'.superpowers/sdd/README').iterdir()):
 if root.is_dir() and (root.name.startswith('root-') or root.name.startswith('review-final-prerequisites-')):
  r=subprocess.call([sys.executable,str(b/'archive-add-record.py'),'sdd-'+root.name,str(root)]);assert r==0
