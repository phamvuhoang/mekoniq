from pathlib import Path
import json,subprocess,sys,os,hashlib,shutil,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';dest=stage/'raw';extracted=stage/'extracted';meta=stage/'archive-receipts';[p.mkdir(exist_ok=True,parents=True) for p in [dest,extracted,meta]]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ops=[]
def cmd(args):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,text=True,capture_output=True,timeout=1800,cwd=active);row={'argv':args,'cwd':str(active),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};ops.append(row);(meta/'archive-invocations.json').write_text(json.dumps(ops,indent=2)+'\n');assert r.returncode==0,row
plans=[]
for label,rel in [('original-6e5eee9','paths.json'),('bab05a5','bab05a5/paths.json'),('2bd66e6','2bd66e6/paths.json'),('fix2','fix2/paths.json'),('fix3','fix3/paths.json'),('229efa7','229efa7/paths.json'),('fix4','fix4/paths.json'),('fix5','fix5/paths.json')]:
 data=json.loads((b.parent/rel).read_text());root=Path(data.get('root',data.get('raw','')))
 if label=='fix3':
  safeRoot=stage/'safe-fix3';assert not safeRoot.exists();excluded=[];copies=[]
  for directory,dirs,files in os.walk(root,followlinks=False):
   out=safeRoot/Path(directory).relative_to(root);out.mkdir(parents=True,exist_ok=True)
   for name in list(dirs):
    p=Path(directory)/name
    if p.is_symlink():(out/name).symlink_to(os.readlink(p),target_is_directory=True);dirs.remove(name)
   for name in files:
    p=Path(directory)/name;relpath=p.relative_to(root).as_posix()
    if relpath=='brand-focus-diagnostic/owned-runtime/.runtime-owner.sqlite':excluded.append({'path':relpath,'bytes':p.stat().st_size,'sha256':sha(p),'reason':'Private runtime authority. Original externally retained and untouched; bytes never in public archive.'});continue
    q=out/name
    if p.is_symlink():q.symlink_to(os.readlink(p))
    else:shutil.copy2(p,q);assert sha(q)==sha(p);copies.append({'path':relpath,'bytes':p.stat().st_size,'sha256':sha(p)})
  (meta/'fix3-public-copy-map.json').write_text(json.dumps({'original':str(root),'staging':str(safeRoot),'byteIdenticalFiles':copies,'excludedPrivate':excluded,'policy':'Original never edited; ordinary copied member bytes and paths unchanged; dependency links descriptor-only at archive time'},indent=2)+'\n');root=safeRoot
 plans.append((label,root))
old=Path(json.loads((b.parent/'981e234/paths.json').read_text())['root'])
for p in sorted(old.iterdir()):
 if p.is_dir():plans.append(('981-b0-'+p.name,p))
# Retain loose files of the historical981 phase through a byte-identical own staging record.
loose=stage/'981-b0-loose';loose.mkdir()
for p in old.iterdir():
 if p.is_file():shutil.copy2(p,loose/p.name);assert sha(p)==sha(loose/p.name)
plans.append(('981-b0-loose',loose))
for p in sorted(e.iterdir()):
 if p.is_dir() and p.name not in ['r1','publication-staging']:plans.append(('981-d4-'+p.name,p))
results=[]
for label,root in plans:
 archive=dest/(label+'.tar.gz');index=dest/(label+'.members.json');out=extracted/label;receipt=meta/(label+'.extract.json')
 assert not archive.exists() and not index.exists();cmd([sys.executable,str(b/'record-archive.py'),'pack',str(root),str(archive),str(index)]);assert archive.stat().st_size<90*1024*1024,(label,archive.stat().st_size)
 cmd([sys.executable,str(b/'record-archive.py'),'extract',str(archive),str(index),str(out),str(receipt)])
 j=json.loads(index.read_text());results.append({'id':label,'source':str(root),'archive':archive.name,'archiveBytes':j['archiveBytes'],'archiveSha256':j['archiveSha256'],'memberIndex':index.name,'memberIndexSha256':sha(index),'memberCount':j['memberCount'],'memberBytes':j['memberBytes'],'safeExtractionReceipt':str(receipt),'safeExtractionReceiptSha256':sha(receipt),'extracted':str(out),'publicReadback':'Pending supported reader mapping; incomplete/failed/unbuilt/intermediate records retain actual no-qualification status'})
 (meta/'settled-archive-index.json').write_text(json.dumps({'scope':'All planned settled earlier phases + settled currentd4 records. r1 and any future outputs excluded until their own settlement. Metadata/readable SDD snapshot freezes later.','records':results},indent=2)+'\n');print(label,j['memberCount'],j['archiveBytes'],flush=True)
print('ARCHIVE_SETTLED_COMPLETE',len(results),flush=True)
