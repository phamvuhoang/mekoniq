from pathlib import Path
import json,subprocess,sys,time,datetime,os
b=Path(__file__).resolve().parent;active=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);deadline=time.monotonic()+21600
while not (b/'dependent-r2b-completed.json').is_file():
 if time.monotonic()>deadline:raise RuntimeError('DEPENDENT_NOT_SETTLED_NO_STOCK_ADMISSION')
 time.sleep(10)
owner=json.loads((b/'dependent-r2b-owner.json').read_text())['pid']
for _ in range(60):
 r=subprocess.run(['ps','-p',str(owner),'-o','pid=,command='],text=True,capture_output=True)
 if r.returncode==1 and not r.stdout.strip():break
 time.sleep(1)
else:raise RuntimeError('DEPENDENT_OWNER_STILL_PRESENT')
def settlement(label):
 rows=[]
 for port in [4175,4176]:
  r=subprocess.run(['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN'],text=True,capture_output=True);rows.append({'port':port,'argv':['lsof','-nP','-iTCP:'+str(port),'-sTCP:LISTEN'],'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==1 and not r.stdout.strip(),rows[-1]
 states=[]
 for repo in [active,Path(paths['lab'])]:
  r=subprocess.run(['git','status','--porcelain'],cwd=repo,text=True,capture_output=True);states.append({'repository':str(repo),'exitCode':r.returncode,'status':r.stdout});assert r.returncode==0 and not r.stdout
 (b/(label+'.json')).write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dependentOwnerAbsent':owner,'ports':rows,'repositories':states,'scope':'Actual known owner gone and relevant ports free; no unknown process stopped or hardware action'},indent=2)+'\n')
def run(name,args,bound=3600,allowed=(0,)):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);assert r in allowed,(name,r);return r
settlement('before-active-stock-settlement')
run('stock-launcher-active',['node',b/'stock-launcher-browser-active.mjs'],600,(0,1))
settlement('after-active-stock-settlement')
run('archive-remaining-settled',[sys.executable,b/'archive-remaining-settled.py'],7200)
run('archive-full-r2b-split',[sys.executable,b/'archive-split-r2b.py'],7200)
assembly=e/'publication-staging/extracted/981-d4-r2b-reassembled'
code="import {verifyR2bDirectory} from './scripts/r2b-readback.mjs'; const issues=await verifyR2bDirectory(process.argv[1]); console.log(JSON.stringify(issues)); process.exit(issues.length?1:0);"
run('extracted-readback-r2b-full',['node','--input-type=module','-e',code,assembly],600,(1,))
run('extracted-acceptance-r2b-full',['env','LAB_SIMEXT_EVIDENCE_DIR='+str(assembly),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/'extracted-acceptance-r2b-full.json')],600,(1,))
(b/'stock-retention-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Authorized single active-pair stock run, remaining settled archives, fullR2b safe split/extraction and actual expected failing public guards settled; no qualification inferred.'},indent=2)+'\n')
