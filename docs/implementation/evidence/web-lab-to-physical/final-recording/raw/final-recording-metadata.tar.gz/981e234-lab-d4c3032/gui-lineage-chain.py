from pathlib import Path
import subprocess,json,sys,time,hashlib,shutil,datetime,os
b=Path(__file__).resolve().parent;active=b.parents[4];paths=json.loads((b/'paths.json').read_text());e=Path(paths['root']);boundary=json.loads((b/'isolated-producer-boundary.json').read_text());lab=Path(boundary['lab']).resolve();legacy=e/'publication-staging/current-legacy-readback/source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,bound=600,cwd='source',allowed=(0,)):
 code=subprocess.call([sys.executable,str(b/'run.py'),name,str(cwd),'caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*map(str,args)]);print('GUI_LINEAGE',name,code,flush=True);assert code in allowed,(name,code);return code
def acceptance(name,record,cwd,allowed):return run(name,['env','LAB_SIMEXT_EVIDENCE_DIR='+str(e/record),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/(name+'.json'))],300,cwd,allowed)
def preserve(owner):
 default=lab/'test-results'
 if not default.exists():return
 def inv(root):
  rows=[]
  for p in sorted(root.rglob('*')):
   assert not p.is_symlink(),p
   if p.is_file():rows.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p),'mtimeNs':p.stat().st_mtime_ns})
  return rows
 files=inv(default);copy=e/(owner+'-default-results-copy');original=e/(owner+'-default-results-original');assert not copy.exists() and not original.exists();shutil.copytree(default,copy,copy_function=shutil.copy2);assert inv(default)==files==inv(copy);default.rename(original);assert inv(original)==files and not default.exists();(b/(owner+'-default-output-map.json')).write_text(json.dumps({'originalPath':str(default),'copy':str(copy),'retainedOriginal':str(original),'files':files,'policy':'After official owned recorder own receipt settled; only newly owned isolated default output moved; active defaults untouched by this helper; raw original attachment paths preserved'},indent=2)+'\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat();(b/'gui-lineage-owner.json').write_text(json.dumps({'pid':os.getpid(),'startedAt':started,'waitsOnlyFor':'checks/record-r1.receipt.json','chain':'Actual completed freshR1→rawguard/stagedguard→ordinary fullR11→rawguard/stagedguard→genuineR93partialR2a→both unchangedguards; stop on unexpected producer/staged prerequisite failure','lab':str(lab)},indent=2)+'\n')
receipt=b/'checks/record-r1.receipt.json';deadline=time.monotonic()+21600
while not receipt.exists():
 assert time.monotonic()<deadline,'R1_RECEIPT_WAIT_BOUND';time.sleep(2)
r=json.loads(receipt.read_text());assert r['exitCode']==0 and r['signal'] is None,('R1_NOT_COMPLETE',r['exitCode'],r['signal']);preserve('r1')
acceptance('acceptance-r1-external','r1','source',(1,))
raw=json.loads((e/'acceptance-r1-external.json').read_text());assert raw['numFailedTests']==1 and any('the IR-SIM record it builds on is the one in the tree' in a['title'] and a['status']=='failed' for t in raw['testResults'] for a in t['assertionResults']),'UNEXPECTED_R1_GUARD_FAILURE'
run('stage-current-legacy-r1',['python3',b/'stage-current-legacy.py','r1']);acceptance('acceptance-r1-staged','r1',legacy,(0,))
run('record-r11',['node','scripts/record-sim-extension.mjs','--release','r1.1','--out',e/'r11','--candidate-id','r11-final-981e234-d4c3032','--r1-record',e/'r1','--mock-regression',e/'mock-regression','--lab',lab,'--webots-home','/Applications/Webots.app','--webots-python',active/'.venv-webots/bin/python'],21600);preserve('r11')
acceptance('acceptance-r11-external','r11','source',(1,));raw=json.loads((e/'acceptance-r11-external.json').read_text());assert raw['numFailedTests']==1 and any('R1.1: the R1 record it carries' in a['title'] and a['status']=='failed' for t in raw['testResults'] for a in t['assertionResults']),'UNEXPECTED_R11_GUARD_FAILURE'
run('stage-current-legacy-r11',['python3',b/'stage-current-legacy.py','r11']);acceptance('acceptance-r11-staged','r11',legacy,(0,))
run('record-r2a-partial',['node','scripts/record-sim-extension.mjs','--release','r2a','--skip-suites','--out',e/'r2a-partial','--candidate-id','r2a-partial-final-981e234-d4c3032','--r11-record',e/'r11','--mock-regression',e/'mock-regression','--lab',lab],600)
acceptance('acceptance-r2a-partial-external','r2a-partial','source',(1,));run('stage-current-legacy-r2a',['python3',b/'stage-current-legacy.py','r2a']);acceptance('acceptance-r2a-partial-staged','r2a-partial',legacy,(1,))
(b/'gui-lineage-completed.json').write_text(json.dumps({'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Fresh actualR1/R11 and realR93partialR2a settled; all raw/staged outcomes preserved. Partial acceptance remains failed; supplemental/study/fullR2b remain separate.'},indent=2)+'\n')
