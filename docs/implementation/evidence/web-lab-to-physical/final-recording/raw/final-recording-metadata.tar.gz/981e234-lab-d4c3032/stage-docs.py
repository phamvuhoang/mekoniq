from pathlib import Path
import json,hashlib,re,os
b=Path(__file__).resolve().parent;active=b.parents[4];workspace=active.parents[2];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';virtual=Path('/workspace');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();index=[]
# Only external stable document sources are read. Virtual normal sibling layout controls relative links.
design=workspace/'docs/2026-11-13-web-lab-to-physical';gtm=workspace/'docs/2026-11-14-web-simulation-gtm';pairs=[(design,Path('source/docs/implementation/web-lab-to-physical/design')),(gtm,Path('source/docs/gtm/2026-11-14-web-simulation'))]
maps=[(design,virtual/pairs[0][1]),(gtm,virtual/pairs[1][1]),(workspace/'source',virtual/'source'),(workspace/'lab',virtual/'lab'),(workspace/'web',virtual/'web'),(workspace/'trial',virtual/'trial')]
def mapped(p):
 for old,new in maps:
  if p.is_relative_to(old):return new/p.relative_to(old)
 return p
for origin,target in pairs:
 for p in sorted(origin.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=target/p.relative_to(origin);q=stage/rel;q.parent.mkdir(parents=True,exist_ok=True);data=p.read_bytes();original=data
  if p.suffix=='.md':
   def link(m):
    href=m[1];parts=href.split('#',1)
    if re.match(r'^[a-z]+:',href) or not parts[0]:return m[0]
    old=(p.parent/parts[0]).resolve();new=mapped(old);return ']('+os.path.relpath(new,(virtual/rel).parent)+(('#'+parts[1]) if len(parts)>1 else '')+')'
   data=re.sub(r'\]\(([^\s)]+)\)',link,data.decode()).encode()
  q.write_bytes(data);index.append({'original':str(p),'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),'destination':str(rel),'destinationBytes':len(data),'destinationSha256':sha(q),'role':'normal-sibling-rebased' if data!=original else 'exact-snapshot'})
(stage/'stable-design-gtm-copy-map.json').write_text(json.dumps({'scope':'Stable external sources copied/rebased in staging only; final engineering-status overlay and actual published clone audit follow settled records','virtualLayout':'workspace/{source,lab,web,trial}','files':index},indent=2)+'\n');print(json.dumps({'files':len(index),'stage':str(stage)}))
