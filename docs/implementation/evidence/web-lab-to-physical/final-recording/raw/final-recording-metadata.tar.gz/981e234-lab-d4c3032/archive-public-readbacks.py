from pathlib import Path
import subprocess,json,sys,hashlib,os,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';extract=stage/'extracted';out=stage/'public-readbacks';out.mkdir();checkouts=stage/'exact-reader-checkouts';checkouts.mkdir();sources={};records=[];preparation=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prep(args,cwd):
 r=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=240);preparation.append({'argv':args,'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,(args,r.stdout,r.stderr);return r.stdout.strip()
def source(commit):
 if commit in sources:return sources[commit]
 p=checkouts/commit;prep(['git','clone','--shared','--no-checkout',str(active),str(p)],checkouts);prep(['git','checkout','--detach',commit],p);(p/'node_modules').symlink_to(active/'node_modules',target_is_directory=True);assert not prep(['git','status','--porcelain','--untracked-files=all'],p);assert sha(p/'pnpm-lock.yaml')==sha(active/'pnpm-lock.yaml');sources[commit]=p;(out/'reader-preparation.json').write_text(json.dumps({'policy':'Exact detached recorded checker/producer code; explicit existingNode dependency reuse with equal lock bytes, no installation/download/fresh-host claim','operations':preparation},indent=2)+'\n');return p
def run(label,cwd,args,expected=None):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider'};r=subprocess.run(['caffeinate','-dims','perl','-e','alarm 600; exec @ARGV',*args],cwd=cwd,env=env,text=True,capture_output=True,timeout=660);log=out/(label+'.log');log.write_text(r.stdout+r.stderr);receipt={'argv':['caffeinate','-dims','perl','-e','alarm 600; exec @ARGV',*args],'cwd':str(cwd),'sourceCommit':prep(['git','rev-parse','HEAD'],cwd),'sourceStatus':prep(['git','status','--porcelain','--untracked-files=all'],cwd),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode if r.returncode>=0 else None,'signal':-r.returncode if r.returncode<0 else None,'log':log.name,'logBytes':log.stat().st_size,'logSha256':sha(log),'expectedHistoricalDisposition':expected,'scope':'Public retained-data readback only, extracted copies; no campaign/native/engine execution or status rewriting'};(out/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');records.append(receipt);(out/'index.json').write_text(json.dumps({'records':records},indent=2)+'\n');print(label,r.returncode,flush=True)
quals=sorted(extract.rglob('qualification.json'))
for i,p in enumerate(quals):
 try:j=json.loads(p.read_text())
 except Exception:continue
 commit=j.get('checker',{}).get('sourceCommit') or j.get('identity',{}).get('before',{}).get('sourceCommit')
 if not commit or len(commit)!=40:continue
 cwd=source(commit);label=f'{i:03d}-'+p.parent.name
 if j.get('release')=='r3':args=['node','scripts/verify-r3.mjs',str(p.parent)]
 elif j.get('documentType')=='linkforge-irsim-qualification':
  code="import {readFileSync,existsSync} from 'node:fs';import {join} from 'node:path';import {checkQualification} from './scripts/irsim-qualification.mjs';const d=process.argv[1],p=checkQualification(JSON.parse(readFileSync(join(d,'qualification.json'))),f=>existsSync(join(d,f))?readFileSync(join(d,f)):null);console.log(JSON.stringify(p));process.exit(p.length?1:0);";args=['node','--input-type=module','-e',code,str(p.parent)]
 else:
  code="import {readFileSync,existsSync} from 'node:fs';import {join} from 'node:path';import {checkQualification} from './scripts/sim-extension-qualification.mjs';const d=process.argv[1],p=checkQualification(JSON.parse(readFileSync(join(d,'qualification.json'))),f=>existsSync(join(d,f))?readFileSync(join(d,f)):null);console.log(JSON.stringify(p));process.exit(p.length?1:0);";args=['node','--input-type=module','-e',code,str(p.parent)]
 run(label,cwd,args,'Original subject/status preserved; malformed/negative or partial candidates may correctly refuse')
 if (p.parent/'campaign/summary.json').exists():run(label+'-campaign',cwd,['node','scripts/lab-irsim.mjs','verify','--input',str(p.parent/'campaign')])
for label,sub in [('payload','981-b0-payload-campaign'),('cell','981-b0-cell-campaign')]:run('source981-'+label,source('981e234b1a0da8c72d220445daaf780b3bf65ae4'),['node','scripts/lab-mujoco.mjs','verify','--input',str(extract/sub)])
# Native handoff roots not nested inside already-read R3 inputs; original failed preparation is allowed to refuse.
for i,p in enumerate(sorted(extract.rglob('profile.json'))):
 if 'inputs' in p.relative_to(extract).parts:continue
 manifest=p.parent/'manifest.json'
 if not manifest.is_file():continue
 try:j=json.loads(manifest.read_text());commit=j.get('checker',{}).get('sourceCommit')
 except Exception:continue
 if not commit or len(commit)!=40:continue
 run(f'handoff-{i:03d}-'+p.parent.name,source(commit),['node','scripts/native-handoff.mjs','verify','--input',str(p.parent)],'prepared-only, nativeReady:false or retained explicit preparation failure')
print('PUBLIC_READBACKS_COMPLETE',len(records),flush=True)
