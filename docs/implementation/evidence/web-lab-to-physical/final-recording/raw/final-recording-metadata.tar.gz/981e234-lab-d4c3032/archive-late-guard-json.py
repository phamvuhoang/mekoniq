from pathlib import Path
import json,subprocess,sys,shutil,hashlib
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';assert (b/'stock-retention-completed.json').is_file();prior=stage/'981-d4-loose-final';out=stage/'981-d4-loose-after-readback';assert not out.exists();out.mkdir();rows=[]
for p in sorted(e.iterdir()):
 if not p.is_file():continue
 old=prior/p.name
 if old.exists():assert p.read_bytes()==old.read_bytes();continue
 shutil.copy2(p,out/p.name);assert p.read_bytes()==(out/p.name).read_bytes();rows.append(p.name)
assert 'extracted-acceptance-r2b-full.json' in rows
r=subprocess.call([sys.executable,str(b/'archive-add-record.py'),'981-d4-loose-after-readback',str(out)]);assert r==0;print(json.dumps({'newLateFiles':rows}))
