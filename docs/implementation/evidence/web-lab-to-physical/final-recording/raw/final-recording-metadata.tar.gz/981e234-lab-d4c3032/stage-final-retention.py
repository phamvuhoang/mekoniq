from pathlib import Path
import json,hashlib,shutil,re,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];sdd=active/'.superpowers/sdd';e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';dest=stage/'source/docs/implementation/web-lab-to-physical/retention';dest.mkdir(parents=True,exist_ok=True);assert (b/'root-publication-freeze-ready.json').is_file(),'ROOT_LEDGER_FREEZE_COORDINATION_REQUIRED';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();selected=[];large=[];mapping=[]
for root in [sdd,*[sdd/name for name in ['README','01-r2b-mobility','02-r2b-cell-and-web','03-r3-linux-readiness']]]:
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink() and p.name!='.gitignore':
   if p.stat().st_size>5*1024*1024:
    assert p.name=='review-3c917ce..d0f3074.diff',('UNDECLARED_LARGE_STATIC_RECORD',p);large.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'disposition':'Retained local original with exact generator/ref/argv descriptor; see giant-review-envelope-descriptor.json'});continue
   selected.append(p)
# Root scoped packages: readable metadata here; complete code snapshots in separately indexed safe archives.
for root in sorted((sdd/'README').iterdir()):
 if not root.is_dir() or not (root.name.startswith('root-') or root.name.startswith('review-final-prerequisites-')):continue
 for p in sorted(root.rglob('*')):
  if p.is_symlink():raise AssertionError(('UNDECLARED_ROOT_PACKAGE_SYMLINK',p))
  if not p.is_file():continue
  assert '.git' not in p.parts and 'node_modules' not in p.parts and not any(x.startswith('.venv') for x in p.parts),p
  assert p.name not in ['.runtime-owner.sqlite','context.json','authority.json','pairing.json'],p
  assert p.stat().st_size<=5*1024*1024,('UNDECLARED_LARGE_ROOT_PACKAGE',p)
  if p.suffix.lower() in ['.md','.json','.py','.diff','.txt'] or not p.suffix:selected.append(p)
for p in sorted(set(selected)):
 rel=p.relative_to(sdd);q=dest/'sdd'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(p)==sha(q);mapping.append({'original':str(p),'destination':str(q.relative_to(stage/'source')),'bytes':p.stat().st_size,'sha256':sha(p),'role':'Exact readable original report/review/brief/ruling/rootaudit snapshot; no rebase or text edit'})
reviews=[x for x in mapping if Path(x['original']).name.startswith('task-') and '-review' in Path(x['original']).name and Path(x['original']).suffix=='.md'];reports=[x for x in mapping if Path(x['original']).name.startswith('task-') and Path(x['original']).name.endswith('-report.md')]
ledgers=['README/progress.md','01-r2b-mobility/progress.md','02-r2b-cell-and-web/progress.md','03-r3-linux-readiness/progress.md'];rulings=[]
for name in ledgers:
 for line,text in enumerate((sdd/name).read_text().splitlines(),1):
  if 'Ruling:' in text or 'Sequencing ruling for final evidence:' in text:rulings.append({'ledger':name,'lineAtSnapshot':line,'text':text,'explicitClauses':text.count('Ruling:')+text.count('Sequencing ruling for final evidence:')})
(dest/'full-readable-copy-map.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':mapping,'largeStaticDescriptors':large,'reportCount':len(reports),'reportBytes':sum(x['bytes'] for x in reports),'reviewCount':len(reviews),'reviewBytes':sum(x['bytes'] for x in reviews),'legacyReviewLimitation':'B00/B01 have ledger-only standalone review records; no reports invented. Full net code goes to final reviewer.'},indent=2)+'\n')
(dest/'review-index.json').write_text(json.dumps({'scope':'All complete task review files retained at this snapshot, including nonnumbered B02b Lab review. Final wholebranch review has not run and is not invented.','records':reviews,'count':len(reviews),'bytes':sum(x['bytes'] for x in reviews)},indent=2)+'\n')
(dest/'rulings-whole-lines.json').write_text(json.dumps({'scope':'Every whole physical literal Ruling/Sequencing-ruling line from four active ledgers; intentional duplicates and all clauses on multi-ruling lines preserved. Index does not replace original full ledgers.','records':rulings,'physicalLines':len(rulings),'explicitClauses':sum(x['explicitClauses'] for x in rulings)},indent=2,ensure_ascii=False)+'\n')
lines=['# Whole literal ruling lines\n\nAll source ledger bytes remain readable beside this navigation index. Intentional duplicates are retained.\n']
for r in rulings:lines.append('\n## '+r['ledger']+':'+str(r['lineAtSnapshot'])+'\n\n```text\n'+r['text']+'\n```\n')
(dest/'rulings-whole-lines.md').write_text(''.join(lines));print(json.dumps({'readableFiles':len(mapping),'fullReports':len(reports),'fullReviews':len(reviews),'reviewBytes':sum(x['bytes'] for x in reviews),'wholeRulingLines':len(rulings),'explicitRulingClauses':sum(x['explicitClauses'] for x in rulings)}))
