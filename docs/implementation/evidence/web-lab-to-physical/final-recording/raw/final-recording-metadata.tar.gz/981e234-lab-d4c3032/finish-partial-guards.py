from pathlib import Path
import subprocess,json,sys,datetime
b=Path(__file__).resolve().parent;e=Path(json.loads((b/'paths.json').read_text())['root']);legacy=e/'publication-staging/current-legacy-readback/source'
for n,expected in [('record-r1',0),('record-r11',0),('record-r2a-partial',1),('gui-lineage-chain',1)]:
 r=json.loads((b/'checks'/(n+'.receipt.json')).read_text());assert r['exitCode']==expected and r['signal'] is None,(n,r['exitCode'])
q=json.loads((e/'r2a-partial/qualification.json').read_text());assert q['identity']['identityStable'] and q['accepted'] is False and q['image'] is None and q['suites']==[];assert q['gates']['G-REG3']['status']=='tested' and q['gates']['G-RT2']['status']=='not_run'
def run(name,args,cwd='source',expected=0):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,str(cwd),'caffeinate','-dims','perl','-e','alarm 600; exec @ARGV',*map(str,args)]);print(name,r,flush=True);assert r==expected,(name,r)
def guard(name,cwd):run(name,['env','LAB_SIMEXT_EVIDENCE_DIR='+str(e/'r2a-partial'),'pnpm','test:acceptance','--','sim-extension','--reporter=default','--reporter=json','--outputFile='+str(e/(name+'.json'))],cwd,1)
guard('acceptance-r2a-partial-external','source');run('stage-current-legacy-r2a',['python3',b/'stage-current-legacy.py','r2a']);guard('acceptance-r2a-partial-staged',legacy)
(b/'gui-lineage-continued-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'originalGuiChainExit':1,'reason':'Original metadata driver incorrectly expected0 from genuine partial producer. Actual partial1/SUITE_MISSING is preserved and consumed, never rerun/edited.','scope':'FreshR1/R11 and genuineR93partial plus raw/staged guard outcomes now settled. Partial remains failed/not_run; independent supplemental/study/fullR2b still follow.'},indent=2)+'\n')
