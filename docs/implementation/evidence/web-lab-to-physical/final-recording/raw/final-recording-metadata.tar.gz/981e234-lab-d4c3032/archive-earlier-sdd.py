from pathlib import Path
import json,subprocess,sys,os,hashlib,shutil,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];sdd=active/'.superpowers/sdd';e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';dest=stage/'raw';meta=stage/'archive-receipts';extracted=stage/'extracted';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plans=[];maps=[];excluded=[];ops=[]
for family in ['01-r2b-mobility','02-r2b-cell-and-web','03-r3-linux-readiness']:
 for root in sorted((sdd/family).glob('evidence-*')):
  if not root.is_dir():continue
  label='sdd-'+family[:2]+'-'+root.name
  if root.name=='evidence-B00R2':
   safe=stage/'safe-sdd-B00R2';assert not safe.exists();safe.mkdir();copied=[]
   for p in sorted(root.rglob('*')):
    assert not p.is_symlink(),p
    rel=p.relative_to(root);q=safe/rel
    if p.is_dir():q.mkdir(exist_ok=True,parents=True);continue
    if p.name in ['source-original-base.diff','lab-original-base.diff']:
     excluded.append({'original':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'policy':'Large reproducible upstream-import binary diff retained locally, not duplicated in archive. Full authored netchanges and exact frozenGit objects remain final-review inputs.','repo':'source' if p.name.startswith('source') else 'lab','argv':['git','diff','--binary','--full-index','--no-renames',*(['3c917ceee6a92c6b087f0bd37baaa4e0740d44a8','d0f30749c0ddb474f0844c68be63a6f0fa4b1933'] if p.name.startswith('source') else ['538ba452c81005010a479f337aab0edbad6e5159','176bf348b6a839037473cc6d87413093ed17ff54'])],'reproductionStatus':'Unexecuted at publication; exact original byte/hash identity retained from original file, original report and root audit'});continue
    q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(q)==sha(p);copied.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
   maps.append({'original':str(root),'staging':str(safe),'files':copied});root=safe
  plans.append((label,root))
plans.append(('historical-retained-inputs',Path('/tmp/b10-fix1-inputs')))
results=[]
for label,root in plans:
 archive=dest/(label+'.tar.gz');index=dest/(label+'.members.json');out=extracted/label;receipt=meta/(label+'.extract.json')
 for args in [[sys.executable,str(b/'record-archive.py'),'pack',str(root),str(archive),str(index)],[sys.executable,str(b/'record-archive.py'),'extract',str(archive),str(index),str(out),str(receipt)]]:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,cwd=active,text=True,capture_output=True,timeout=1800);ops.append({'argv':args,'cwd':str(active),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(meta/'earlier-sdd-archive-invocations.json').write_text(json.dumps(ops,indent=2)+'\n');assert r.returncode==0,ops[-1]
 j=json.loads(index.read_text());assert j['archiveBytes']<90*1024*1024;results.append({'id':label,'source':str(root),'archive':archive.name,'archiveBytes':j['archiveBytes'],'archiveSha256':j['archiveSha256'],'memberIndex':index.name,'memberIndexSha256':sha(index),'memberCount':j['memberCount'],'memberBytes':j['memberBytes'],'safeExtractionReceipt':str(receipt),'safeExtractionReceiptSha256':sha(receipt),'extracted':str(out),'publicReadback':'Historical tooling inputs and raw checks retain their original attribution; archive hash/extract readback is byte scope, no requalification'});(meta/'earlier-sdd-archive-index.json').write_text(json.dumps({'records':results,'sourceCopies':maps,'largeUpstreamPatchExclusions':excluded},indent=2)+'\n');print(label,j['memberCount'],j['archiveBytes'],flush=True)
print('EARLIER_SDD_ARCHIVE_COMPLETE',len(results),flush=True)
