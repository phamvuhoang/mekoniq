// Owned documentation proof through the unchanged public launcher; distinct from production capture.
import {spawn,execFileSync} from 'node:child_process';
import {readFileSync,realpathSync} from 'node:fs';
import {mkdtemp,mkdir,readFile,writeFile,appendFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {runOwnedProcess} from '../../../../../scripts/native-sim/owned-process.mjs';
const base=import.meta.dirname,boundary=JSON.parse(await readFile(join(base,'isolated-producer-boundary.json'),'utf8')),paths=JSON.parse(await readFile(join(base,'paths.json'),'utf8')),source=realpathSync(paths.source),lab=realpathSync(paths.lab),out=join(paths.root,'stock-launcher-web-active');await mkdir(out);
const privateRoot=await mkdtemp(join(tmpdir(),'mekoniq-final-981-stock-private-')),dataDir=join(privateRoot,'runs'),args=[join(lab,'scripts/start-irsim.mjs'),'--provider','mujoco','--mujoco-mobile','--ui-port','4175','--runtime-port','4176','--data-dir',dataDir],startedAtEpochMs=Date.now();
const git=(cwd,...a)=>execFileSync('git',a,{cwd,encoding:'utf8'}).trim();
const identity=()=>({sourceCommit:git(source,'rev-parse','HEAD'),labCommit:git(lab,'rev-parse','HEAD'),sourceStatus:git(source,'status','--porcelain'),labStatus:git(lab,'status','--porcelain'),lock:JSON.parse(readFileSync(join(lab,'config/source-runtime.lock.json'),'utf8'))});
const before=identity();if(before.sourceCommit!==paths.producerSource||before.labCommit!==paths.producerLab||before.sourceStatus||before.labStatus)throw Error('STOCK_PRODUCER_CHANGED');
await writeFile(join(out,'invocation.json'),JSON.stringify({version:1,startedAtEpochMs,command:process.execPath,args,cwd:lab,before,scope:'Actual public stock launcher/dev UI and complete unchanged mujoco-cell browser spec; no production performance/native/hardware claim',privateOperationalRoot:{path:privateRoot,policy:'Retained outside versioned/public evidence; contains runtime authority/context and is not an archive input'},packageAlias:'pnpm lab:mujoco -- --mujoco-mobile maps to this public Node entrypoint'},null,2));
const {pairingOutput}=await import(pathToFileURL(join(lab,'scripts/launcher-output.mjs')).href),controller=new AbortController();let launcher,runnerResult,launcherExit,outputWrites=Promise.resolve(),stderrWrites=Promise.resolve();let raw='';
const queue=(file,text)=>{outputWrites=outputWrites.then(()=>appendFile(join(out,file),text));};
for(const signal of ['SIGINT','SIGTERM','SIGALRM'])process.once(signal,()=>{controller.abort();launcher?.kill('SIGINT');});
try{
 launcher=spawn(process.execPath,args,{cwd:lab,env:process.env,stdio:['ignore','pipe','pipe']});const child=launcher;
 launcherExit=new Promise((ok,fail)=>{child.once('error',fail);child.once('exit',(code,signal)=>ok({pid:child.pid,code,signal,atEpochMs:Date.now()}));});
 const redacted=pairingOutput(text=>queue('launcher-stdout.log',text));child.stdout.on('data',c=>redacted.write(c));child.stdout.once('end',()=>redacted.end());child.stderr.on('data',c=>{stderrWrites=stderrWrites.then(()=>appendFile(join(out,'launcher-stderr.log'),c));});
 const token=await new Promise((ok,fail)=>{const timeout=setTimeout(()=>fail(Error('OWNED_STOCK_READY_TIMEOUT')),180000);child.stdout.on('data',c=>{raw+=c.toString();const match=/one-use pairing code \(expires in 5 minutes\): (\S+)[\s\S]*Ready in/.exec(raw);if(match){clearTimeout(timeout);ok(match[1]);raw='';}});void launcherExit.then(r=>{clearTimeout(timeout);fail(Error('STOCK_EXIT_BEFORE_READY:'+JSON.stringify(r)));},fail);});
 const requestedAtEpochMs=Date.now(),url='http://127.0.0.1:4176/lab/v2/health',response=await fetch(url,{signal:AbortSignal.timeout(10000)}),body=await response.text(),receivedAtEpochMs=Date.now();await writeFile(join(out,'health-body.json'),body);await writeFile(join(out,'health-http.json'),JSON.stringify({method:'GET',url,status:response.status,requestedAtEpochMs,receivedAtEpochMs,bodySha256:createHash('sha256').update(body).digest('hex')},null,2));if(response.status!==200)throw Error('STOCK_HEALTH_HTTP_'+response.status);
 const health=JSON.parse(body);if(health.sourceCommit!==before.lock.sourceCommit||health.schemaHash!==before.lock.schemaHash)throw Error('STOCK_HEALTH_IDENTITY');
 await mkdir(join(out,'browser-process'));
 runnerResult=await runOwnedProcess('pnpm',['exec','playwright','test','--config','playwright.irsim.config.ts','mujoco-cell.spec.ts','--output',join(out,'playwright')],{out:join(out,'browser-process'),cwd:lab,env:{...process.env,LAB_TEST_PAIRING_TOKEN:token,LAB_PW_JSON:join(out,'browser-result.json'),LAB_B07B_EVIDENCE:out,LAB_IRSIM_SCREENSHOTS:out},timeoutMs:360000,signal:controller.signal});
 const after=identity();await writeFile(join(out,'completion.json'),JSON.stringify({before,after,runnerResult,finishedAtEpochMs:Date.now(),scope:'Stock public launcher/dev UI proof; separate from production build/browser identity and benchmark'},null,2));if(JSON.stringify(before)!==JSON.stringify(after))throw Error('STOCK_PRODUCER_CHANGED');process.exitCode=runnerResult.exitCode??1;
}catch(e){await writeFile(join(out,'error.txt'),String(e.stack??e));throw e;}
finally{
 const stopStartedAtEpochMs=Date.now();if(launcher&&launcher.exitCode===null&&launcher.signalCode===null)launcher.kill('SIGINT');
 let closeTimer;const exit=launcherExit?await Promise.race([launcherExit,new Promise((_,reject)=>{closeTimer=setTimeout(()=>reject(Error('OWNED_STOCK_LAUNCHER_CLOSE_TIMEOUT')),30000);})]).finally(()=>clearTimeout(closeTimer)):null;await outputWrites;await stderrWrites;
 await writeFile(join(out,'cleanup.json'),JSON.stringify({stopStartedAtEpochMs,finishedAtEpochMs:Date.now(),launcher:exit,ownership:'SIGINT exact child handle created here; unchanged launcher owns and drains its runtime/UI groups',privateOperationalRoot:privateRoot,deleted:false,otherProcessesStopped:false},null,2));if(exit?.code!==0)process.exitCode=process.exitCode||1;
}
