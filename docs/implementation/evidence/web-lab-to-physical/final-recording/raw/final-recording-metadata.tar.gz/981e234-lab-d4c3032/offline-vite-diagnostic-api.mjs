// One controller-authorized diagnostic only; no runtime engine, qualification, assertion or product change.
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {realpathSync} from 'node:fs';
import {join} from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
const b=import.meta.dirname,paths=JSON.parse(await readFile(join(b,'paths.json'),'utf8')),boundary=JSON.parse(await readFile(join(b,'isolated-producer-boundary.json'),'utf8')),lab=realpathSync(boundary.lab),source=realpathSync(boundary.source),out=join(paths.root,'offline-vite-diagnostic-api');await mkdir(out);
const require=createRequire(join(lab,'package.json')),{createServer}=await import(pathToFileURL(require.resolve('vite')).href),{chromium}=await import(pathToFileURL(require.resolve('@playwright/test')).href),git=(cwd,...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const before={sourceHead:git(source,'rev-parse','HEAD'),labHead:git(lab,'rev-parse','HEAD'),sourceStatus:git(source,'status','--porcelain'),labStatus:git(lab,'status','--porcelain')};if(before.sourceStatus||before.labStatus)throw Error('DIAGNOSTIC_CHECKOUT_DIRTY');
await writeFile(join(out,'invocation.json'),JSON.stringify({startedAt:new Date().toISOString(),lab,source,before,scope:'One offline-only same-isolated-Vite diagnostic: exact original blanket route and separately labeled API-path-only control. No runtime/qualification/native action.'},null,2));
let server,browser;const results=[];
try{
 server=await createServer({root:lab,configFile:join(lab,'vite.config.ts'),server:{host:'127.0.0.1',port:4175,strictPort:true}});await server.listen();browser=await chromium.launch({headless:true});
 for(const mode of ['original-blanket','api-path-control']){
  const context=await browser.newContext({viewport:{width:1280,height:720}}),page=await context.newPage(),events=[],aborted=[];const record=(kind,value)=>events.push({atEpochMs:Date.now(),kind,...value});
  page.on('console',m=>record('console',{type:m.type(),text:m.text()}));page.on('pageerror',e=>record('pageerror',{message:e.message}));page.on('request',r=>record('request',{url:r.url(),method:r.method(),resourceType:r.resourceType()}));page.on('requestfailed',r=>record('requestfailed',{url:r.url(),failure:r.failure()}));page.on('response',r=>record('response',{url:r.url(),status:r.status()}));
  if(mode==='original-blanket')await page.route('**/lab/**',r=>{aborted.push(r.request().url());return r.abort();});
  else await page.route('**/*',r=>new URL(r.request().url()).pathname.startsWith('/lab/')?(aborted.push(r.request().url()),r.abort()):r.continue());
  let error=null;try{await page.goto('http://127.0.0.1:4175/#replay',{timeout:15000});await page.locator('.replay-files>summary').waitFor({timeout:15000});}catch(e){error=String(e);}
  const dom=await page.content(),state=await page.evaluate(()=>({url:location.href,hash:location.hash,replaySummaryCount:document.querySelectorAll('.replay-files>summary').length,bodyText:document.body.textContent}));await writeFile(join(out,mode+'.html'),dom);await page.screenshot({path:join(out,mode+'.png')});const result={mode,error,state,aborted,events};results.push(result);await writeFile(join(out,mode+'.json'),JSON.stringify(result,null,2));await context.close();
 }
 const after={sourceHead:git(source,'rev-parse','HEAD'),labHead:git(lab,'rev-parse','HEAD'),sourceStatus:git(source,'status','--porcelain'),labStatus:git(lab,'status','--porcelain')};await writeFile(join(out,'result.json'),JSON.stringify({before,after,results,conclusion:'Diagnostic observations only; any cause assignment requires exact URL/control interpretation. No original test/outcome edited.'},null,2));console.log(JSON.stringify(results.map(({mode,error,state,aborted})=>({mode,error,state,aborted}))));
}finally{if(browser)await browser.close();if(server)await server.close();await writeFile(join(out,'cleanup.json'),JSON.stringify({finishedAt:new Date().toISOString(),browserClosed:!!browser,serverClosed:!!server,ownedResourcesOnly:true,runtimeStarted:false},null,2));}
