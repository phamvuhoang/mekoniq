from pathlib import Path
import subprocess,sys,json,datetime
b=Path(__file__).resolve().parent;source=b.parents[4]
mock=json.loads((b/'checks/mock-regression.receipt.json').read_text())
assert mock['exitCode']==0 and mock['signal'] is None,'COMPLETE_MOCK_NOT_GREEN'
def run(name,argv,bound,repo='source'):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,repo,'caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*argv]);print('REMAINING',name,r,flush=True)
 if r:raise SystemExit(r)
run('irsim-chain',['python3',str(b/'irsim-chain.py')],18000)
run('r3-chain',['python3',str(b/'r3-chain.py')],1800)
profiles=['mujoco-linux-amd64','mujoco-linux-arm64','engineering-amd64','engineering-arm64','xarm6-jazzy-sim','puma560-linuxcnc-sim']
for profile in profiles:
 for prefix in ['prepare-','export-handoff-','handoff-','record-r3-','readback-r3-','acceptance-r3-']:
  p=b/'checks'/(prefix+profile+'.receipt.json');assert p.is_file(),str(p)
  receipt=json.loads(p.read_text());assert receipt['exitCode']==0 and receipt['signal'] is None,(p,receipt['exitCode'],receipt['signal'])
run('stock-launcher',['node',str(b/'stock-launcher-browser.mjs')],600)
run('r2a-supplemental',['node',str(b/'supplement-tables.mjs'),'r2a'],18000)
run('r2b-supplemental',['node',str(b/'supplement-tables.mjs'),'r2b'],18000)
(b/'available-chain-completed.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Available independent chain completed; individual skipped tests/hooks and unavailable Webots/Docker/R1/R11/R2a/R2b lineage remain not_run or failed, not a whole qualification pass'},indent=2)+'\n')
