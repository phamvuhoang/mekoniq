from pathlib import Path
import subprocess,sys,json
b=Path(__file__).resolve().parent;source=b.parents[4];root=Path(json.loads((b/'paths.json').read_text())['root'])
def run(name,args,bound=14400):
 r=subprocess.call([sys.executable,str(b/'run.py'),name,'source','caffeinate','-dims','perl','-e','alarm '+str(bound)+'; exec @ARGV',*args]);print(name,r,flush=True)
 if r:sys.exit(r)
run('record-irsim',['node','scripts/record-irsim.mjs','--campaign','c02-qualification','--out',str(root/'irsim'),'--candidate-id','irsim-final-981e234-labd4c3032','--irsim-python',str(source/'.venv-irsim/bin/python')])
run('verify-irsim-campaign',['node','scripts/lab-irsim.mjs','verify','--input',str(root/'irsim/campaign')],300)
run('acceptance-irsim',['env','LAB_IRSIM_EVIDENCE_DIR='+str(root/'irsim'),'pnpm','test:acceptance','--','linkforge-irsim'],300)
