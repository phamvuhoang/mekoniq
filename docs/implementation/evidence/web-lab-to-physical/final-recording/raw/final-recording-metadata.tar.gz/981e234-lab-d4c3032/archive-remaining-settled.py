from pathlib import Path
import json,subprocess,sys,shutil,hashlib,datetime,os
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';assert (b/'dependent-r2b-completed.json').is_file();assert (b/'checks/stock-launcher-active.receipt.json').is_file();records=[]
for p in (stage/'archive-receipts').glob('*.json'):
 try:j=json.loads(p.read_text())
 except:continue
 if not isinstance(j,dict):continue
 a=j.get('records',[])
 if 'archive' in j and 'source' in j:a=[j]
 records += [x for x in a if isinstance(x,dict) and 'archive' in x]
seen={Path(x['source']).resolve() for x in records if x.get('source')}
for p in sorted(e.iterdir()):
 if not p.is_dir() or p.name in ['publication-staging','r2b'] or p.resolve() in seen:continue
 r=subprocess.run([sys.executable,str(b/'archive-add-record.py'),'981-d4-'+p.name,str(p)],text=True,capture_output=True);print(p.name,r.returncode,r.stdout,r.stderr,flush=True);assert r.returncode==0
loose=stage/'981-d4-loose-final';assert not loose.exists();loose.mkdir()
for p in e.iterdir():
 if p.is_file():shutil.copy2(p,loose/p.name);assert p.read_bytes()==(loose/p.name).read_bytes()
r=subprocess.call([sys.executable,str(b/'archive-add-record.py'),'981-d4-loose-final',str(loose)]);assert r==0
