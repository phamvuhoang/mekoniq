from pathlib import Path
from urllib.parse import urlsplit,unquote
import json,re,sys,subprocess
stage=Path(sys.argv[1]);output=Path(sys.argv[2]);assert not output.exists();repos={'phamvuhoang/mekoniq':'source','phamvuhoang/mekoniq-lab':'lab','phamvuhoang/mekoniq-web':'web','phamvuhoang/mekoniq-trial':'trial'};refs={}
def add(repo,ref,origin):
 key=(repo,ref);refs.setdefault(key,{'repository':repo,'ref':ref,'origins':[]})['origins'].append(origin)
for repo in ['source','lab']:
 for p in sorted((stage/repo).rglob('*.md')):
  for line,text in enumerate(p.read_text().splitlines(),1):
   for url in re.findall(r'https://github\.com/[^\s)<>`]+',text):
    parts=[unquote(x) for x in urlsplit(url.rstrip('.,')).path.strip('/').split('/')];key='/'.join(parts[:2]);target=repos.get(key)
    if target and len(parts)>=4 and parts[2] in ['blob','tree','commit'] and re.fullmatch('[0-9a-f]{40}',parts[3]):add(target,parts[3],{'path':str(p.relative_to(stage)),'line':line,'url':url})
for filename in ['giant-review-envelope-descriptor.json','earlier-sdd-archive-index.json']:
 p=stage/'source/docs/implementation/evidence/web-lab-to-physical/final-recording/archive-receipts'/filename;j=json.loads(p.read_text())
 if filename.startswith('giant'):
  for k in ['base','frozenHead']:add('source',j[k],{'descriptor':str(p.relative_to(stage)),'field':k})
 else:
  for record in j['largeUpstreamPatchExclusions']:
   for ref in record['argv']:
    if re.fullmatch('[0-9a-f]{40}',ref):add(record['repo'],ref,{'descriptor':str(p.relative_to(stage)),'field':'largeUpstreamPatchExclusions.argv'})
# Explicit exact historical subject/checker identities named in reproduction prose.
for repo,ref,role in [('source','874d05aedfbf573496994fd73016f19ef19e6932','L01 checker'),('source','4f893ac','L01 subject'),('lab','a6ec316','L01 subject')]:add(repo,ref,{'descriptor':'reproduce-final-recording.md','role':role})
output.write_text(json.dumps({'scope':'Every owned exact Git URL found across all staged Markdown, including exact retained historical reports, plus all exact commits in the published giant-patch/envelope reproduction descriptors and explicit historical L01 subject/checker. Relative links in immutable historical reports are provenance and audited separately from maintained navigation.','refs':list(refs.values())},indent=2)+'\n');print(json.dumps({'refs':len(refs)}))
