from pathlib import Path
import json,sys,subprocess,hashlib,shutil,os,datetime
b=Path(__file__).resolve().parent;active=b.parents[4];e=Path(json.loads((b/'paths.json').read_text())['root']);stage=e/'publication-staging';root=e/'r2b';assert (root/'qualification.json').is_file();meta=stage/'archive-receipts';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();components=['inputs/physics','inputs/cell','inputs/web'];outer=stage/'r2b-outer-byte-copy';assert not outer.exists();outer.mkdir();ops=[];maps=[]
def inventory(root):
 files=[];dirs=[]
 for p in sorted(root.rglob('*')):
  assert not p.is_symlink(),p
  rel=p.relative_to(root).as_posix()
  if p.is_file():files.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode & 0o777),'mtimeNs':p.stat().st_mtime_ns})
  elif p.is_dir():dirs.append(rel)
  else:raise AssertionError(str(p))
 return {'files':files,'directories':dirs}
original=inventory(root);copied=[]
for p in sorted(root.rglob('*')):
 rel=p.relative_to(root).as_posix()
 if any(rel==c or rel.startswith(c+'/') for c in components):continue
 q=outer/rel
 if p.is_dir():q.mkdir(exist_ok=True,parents=True)
 else:q.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,q);assert sha(p)==sha(q);copied.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
records=[]
for label,source,destination in [('981-d4-r2b-outer',outer,''),*[(('981-d4-r2b-'+c.split('/')[-1]),root/c,c) for c in components]]:
 archive=stage/'raw'/(label+'.tar.gz');index=stage/'raw'/(label+'.members.json');out=stage/'extracted'/label;receipt=meta/(label+'.extract.json')
 for argv in [[sys.executable,str(b/'record-archive.py'),'pack',str(source),str(archive),str(index)],[sys.executable,str(b/'record-archive.py'),'extract',str(archive),str(index),str(out),str(receipt)]]:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=active,text=True,capture_output=True,timeout=1800);ops.append({'argv':argv,'cwd':str(active),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr});(meta/'r2b-split-invocations.json').write_text(json.dumps(ops,indent=2)+'\n');assert r.returncode==0,ops[-1]
 j=json.loads(index.read_text());assert j['archiveBytes']<90*1024*1024;records.append({'id':label,'source':str(source),'archive':archive.name,'archiveBytes':j['archiveBytes'],'archiveSha256':j['archiveSha256'],'memberIndex':index.name,'memberIndexSha256':sha(index),'memberCount':j['memberCount'],'memberBytes':j['memberBytes'],'safeExtractionReceipt':str(receipt),'safeExtractionReceiptSha256':sha(receipt),'extracted':str(out),'assemblyDestination':destination,'publicReadback':'Whole reassembled directory is read separately; components never change raw member/status bytes'})
assembly=stage/'extracted/981-d4-r2b-reassembled';assert not assembly.exists();shutil.copytree(Path(records[0]['extracted']),assembly)
for r in records[1:]:
 target=assembly/r['assemblyDestination'];assert not target.exists();target.parent.mkdir(exist_ok=True,parents=True);shutil.copytree(Path(r['extracted']),target)
reassembled=inventory(assembly);key=lambda d:[(r['path'],r['bytes'],r['sha256'],r['mode']) for r in d['files']];assert key(original)==key(reassembled) and original['directories']==reassembled['directories'];assert inventory(root)==original
result={'scope':'Whole original R2b directory split by bulk input component to avoid oversized Git blobs; no raw content/path/outcome/hash edits. Outer metadata is byte-identical staging; every original file restored at identical relative path before public readback. Original mtimes indexed; tar neutral time metadata is intentional.','original':str(root),'originalInventory':original,'outerCopy':{'source':str(root),'staging':str(outer),'files':copied},'records':records,'assembly':str(assembly),'assembledVerifiedFiles':len(original['files']),'assembledVerifiedBytes':sum(r['bytes'] for r in original['files']),'assembledByteAndModeIdentity':True};(meta/'r2b-split-assembly.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'assembly':str(assembly),'verifiedFiles':result['assembledVerifiedFiles'],'verifiedBytes':result['assembledVerifiedBytes'],'archives':[(r['id'],r['archiveBytes']) for r in records]}))
