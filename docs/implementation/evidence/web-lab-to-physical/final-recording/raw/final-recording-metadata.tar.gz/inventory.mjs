import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
for (const [cmd,args] of [['uname',['-a']],['node',['--version']],['pnpm',['--version']],['lsof',['-nP','-iTCP:4175','-iTCP:4176','-iTCP:57421','-iTCP:57422','-iTCP:57423','-iTCP:57424','-sTCP:LISTEN']],['git',['rev-parse','HEAD','HEAD^{tree}']],['git',['status','--porcelain']],['git',['-C','../lab','rev-parse','HEAD','HEAD^{tree}']],['git',['-C','../lab','status','--porcelain']]]) {const r=spawnSync(cmd,args,{encoding:'utf8'});console.log(JSON.stringify({cmd,args,exit:r.status,stdout:r.stdout,stderr:r.stderr}));}
console.log(readFileSync('../lab/config/source-runtime.lock.json','utf8'));
