from pathlib import Path
import subprocess,json,hashlib
b=Path(__file__).resolve().parent;source=b.parents[4];lab=source.parent/'lab';sha=lambda data:hashlib.sha256(data).hexdigest();git=lambda cwd,*args:subprocess.check_output(['git',*args],cwd=cwd,text=True).strip();read=lambda p:json.loads(Path(p).read_text());trees=[]
for name,cwd,base in [('source',source,'bab05a5311a9db3be447519b3b9ac48eb0e4a90d'),('lab',lab,'1f9b48d6d2767bdcd623f08cfa45ba0f9af33d1d')]:
 assert not git(cwd,'status','--porcelain','--untracked-files=all');head=git(cwd,'rev-parse','HEAD');patch=subprocess.check_output(['git','diff','--binary','--no-renames',base,head],cwd=cwd);(b/(name+'-fix-base.patch')).write_bytes(patch);files=[]
 for path in git(cwd,'diff','--name-only',base,head).splitlines():
  data=(cwd/path).read_bytes();assert data==subprocess.check_output(['git','show',head+':'+path],cwd=cwd);files.append({'path':path,'bytes':len(data),'sha256':sha(data)})
 trees.append({'name':name,'base':base,'head':head,'tree':git(cwd,'rev-parse','HEAD^{tree}'),'files':files,'patchBytes':len(patch),'patchSha256':sha(patch)})
m=read(b/'export-final/manifest.json');pin=read(lab/'config/source-runtime.lock.json');assert m==read(lab/'.runtime'/pin['artifactSha256']/'manifest.json');assert not m['dirty'] and not pin['dirty'];assert pin['sourceCommit']==m['sourceCommit']==trees[0]['head'];assert pin['schemaHash']==m['schemaHash'];assert pin['portableToolsDigest']==m['portableSimulationTools']['closure']['digest']
for p in [b/'export-final/runtime.mjs',lab/'.runtime'/pin['artifactSha256']/'runtime.mjs']:assert sha(p.read_bytes())==pin['artifactSha256']
schemahash=hashlib.sha256()
for name in sorted(m['schemas']):
 data=(source/'packages/contracts/schemas'/name).read_bytes();assert data==(b/'export-final/schemas'/name).read_bytes();schemahash.update((name+'\n').encode());schemahash.update(data)
assert schemahash.hexdigest()==m['schemaHash']
old=read(b.parent/'fix1/export-final/manifest.json');closures={}
for name,current,previous in [('native',m['nativeTools'],old['nativeTools']),('portable',m['portableSimulationTools']['closure'],old['portableSimulationTools']['closure'])]:
 assert sha(json.dumps(current['files'],separators=(',',':'),ensure_ascii=False).encode())==current['digest'];assert [x['path'] for x in current['files']]==[x['path'] for x in previous['files']];changed=[]
 for f,o in zip(current['files'],previous['files']):
  data=(source/f['path']).read_bytes();assert len(data)==f['bytes'] and sha(data)==f['sha256'];
  if f!=o:changed.append(f['path'])
 assert changed==['packages/contracts/schemas/native-handoff-v1.schema.json'];closures[name]={'digest':current['digest'],'files':len(current['files']),'changedEntries':changed}
indices=[source/'.superpowers/sdd/02-r2b-cell-and-web'/p for p in ['root-B10-evidence-file-index.json','root-B10-r1-evidence-file-index.json','root-B10-smoke-27d6be9-file-index.json']]+[source/'.superpowers/sdd/03-r3-linux-readiness'/p for p in ['root-L06-evidence-file-index.json','root-L06-r1-evidence-file-index.json']]+[source/'.superpowers/sdd/README/root-final-prerequisites-1-evidence-file-index.json',b.parent/'fix1/initial-evidence-index.json',b.parent/'bab05a5/phase-retention-index.json',b.parent/'bab05a5/external-phase-retention-index.json'];preserved=[]
for p in indices:
 index=read(p)
 for f in index['files']:
  data=(Path(index['root'])/f['path']).read_bytes();assert len(data)==f['bytes'] and sha(data)==f['sha256'],str(p)+':'+f['path']
 preserved.append({'index':str(p),'files':len(index['files'])})
external=Path(read(b/'paths.json')['root']);handoff=read(external/'puma-export/manifest.json');inputmanifest=read(external/'puma-input/manifest.json');assert handoff==inputmanifest;refs=[]
for role,rows in handoff['refs'].items():
 for f in rows:
  data=(external/'puma-export'/f['path']).read_bytes();assert len(data)==f['bytes'] and sha(data)==f['sha256'];refs.append({'role':role,**f})
assert handoff['subject']['sourceCommit']==trees[0]['head'] and handoff['subject']['labCommit']==trees[1]['head'];assert handoff['subject']['nativeClosureHash']==m['nativeTools']['digest'];attr=[f for f in refs if f['sourcePath']=='robotics/manipulation/vendor-source/.gitattributes'];assert len(attr)==1 and attr[0]['bytes']==99 and attr[0]['sha256']=='37991456045b2f43a9a624e14f2af90c33645175a0a3eabc14b19c4da83359fc';(b/'puma-export-ref-index.json').write_text(json.dumps({'root':str(external/'puma-export'),'refs':refs},indent=2))
q=read(external/'r3-puma-prepared/qualification.json');assert q['accepted']==False and q['levels']=={'R3.0':'tested','R3.1':'not_run','R3.2':'not_run'};assert all(v['status']=='not_run' for k,v in q['cases'].items() if k!='DEP-PREP-01');checks=[]
for p in sorted((b/'checks').glob('*.receipt.json')):
 r=read(p);data=p.with_name(p.name.replace('.receipt.json','.log')).read_bytes();assert sha(data)==r['logSha256'];checks.append({'name':p.stem,'receiptSha256':sha(p.read_bytes()),'logBytes':len(data),**r})
(b/'check-index.json').write_text(json.dumps(checks,indent=2));checker=json.loads((b/'checks/checker-identity.log').read_text());result={'trees':trees,'pin':pin,'schemaHash':m['schemaHash'],'schemaCount':len(m['schemas']),'runtimeArtifactSha256':m['artifactSha256'],'rawManifestSha256':sha((b/'export-final/manifest.json').read_bytes()),'closures':closures,'checker':checker,'pumaRefs':len(refs),'pumaNativeMembers':len(m['nativeTools']['files']),'pumaQualificationSha256':sha((external/'r3-puma-prepared/qualification.json').read_bytes()),'preserved':preserved,'checkCountBeforeAuditReceipt':len(checks),'limits':['Byte consistency is not host/execution authenticity','Only narrow PUMA preparation/readback, no native or broad final campaign']}
assert Path(source/'.superpowers/sdd/README/task-final-recording-report.md').read_bytes().startswith((b/'report-prefix.txt').read_bytes());(b/'final-byte-attribution.json').write_text(json.dumps(result,indent=2));print(json.dumps({**result,'trees':[{**t,'files':len(t['files'])} for t in trees]},indent=2))
