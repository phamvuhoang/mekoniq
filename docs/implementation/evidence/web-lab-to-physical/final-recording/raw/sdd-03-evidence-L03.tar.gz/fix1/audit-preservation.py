from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();sdd=root/'.superpowers/sdd/03-r3-linux-readiness';e=sdd/'evidence-L03/fix1'
sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['root-L03-evidence-file-index.json','root-L02-evidence-file-index.json','root-L02-r1-evidence-file-index.json']:
 index=json.loads((sdd/name).read_text())
 for f in index['files']:
  b=(Path(index['root'])/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes'],f['path']
 print('PRESERVED',name,len(index['files']))
identity=json.loads((e/'pre-fix1-report.identity.json').read_text());original=(e/'pre-fix1-report.md').read_bytes();assert sha(original)==identity['sha256'] and len(original)==identity['bytes'];assert Path(identity['path']).read_bytes().startswith(original)
subprocess.run(['python3',str(sdd/'evidence-L03/audit-preservation.py')],check=True)
old=json.loads((sdd/'evidence-L03/identities.json').read_text());export=Path(old['export']);assert sha((export/'manifest.json').read_bytes())==old['manifestSha256'];cache=root.parent/'lab/.runtime'/old['runtimeArtifactSha256'];assert sha((cache/'runtime.mjs').read_bytes())==old['runtimeArtifactSha256']
lock=json.loads((root/'robotics/manipulation/native-vendor.lock.json').read_text());tree=json.loads((e/'upstream-tree.json').read_text());blobs={x['path']:x['sha'] for x in tree['tree']}
for f in lock['files']:assert f['gitBlobSha']==blobs[f['path']]
print('PRESERVED original report/export/cache; all',len(lock['files']),'snapshots match official pinned Git tree; canonical model unchanged')
