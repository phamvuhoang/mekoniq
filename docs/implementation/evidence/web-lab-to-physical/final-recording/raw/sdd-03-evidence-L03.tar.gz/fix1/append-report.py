from pathlib import Path
import json,hashlib,shlex,subprocess
root=Path.cwd();sdd=root/'.superpowers/sdd/03-r3-linux-readiness';e=sdd/'evidence-L03/fix1';report=sdd/'task-L03-report.md';original=(e/'pre-fix1-report.md').read_bytes();assert report.read_bytes()==original
identity=json.loads((e/'identities-final.json').read_text());previous=json.loads((e/'identities.json').read_text());lock=json.loads((root/'robotics/manipulation/native-vendor.lock.json').read_text());target=json.loads((root/'robotics/manipulation/profiles/xarm6-native-mapping.json').read_text());oldlock=json.loads(subprocess.check_output(['git','show','2a7ec9c:robotics/manipulation/native-vendor.lock.json']));oldpaths={x['path'] for x in oldlock['files']}
text='''

---

# L03 fix round 1/5 — prepared-code corrections (2026-11-15)

Status: **DONE_WITH_CONCERNS for the authorized portable fix work; independent prepared-code re-review pending. L03 native qualification remains incomplete/not_run.** This append addresses code findings L03-R1-01 through L03-R1-04. **L03-R1-05 is NOT ADDRESSED**, per R88: no assigned native Linux host, no X1/X2 native execution or X3 contact trial; required qualification is neither waived nor passed. No helpers/reviewers, ROS/Gazebo launch, xacro expansion, cloud, Docker, hardware or deployment were used in this fix round.

The original report remains an unchanged 31,609-byte prefix (SHA-256 `e1286018bb57fd1e6a771bda5c322c79008229609e4d6b935852c157aa058884`). `evidence-L03/fix1/pre-fix1-report.md` and its identity preserve it. Original task bases remain Source `00d41e7f25ec1294b9bc8e8c81de3d8e1a869316` / Lab `82b5f92005673c99ba0d1f434ae4c512800fa75e`. Fix review bases are Source `2a7ec9c89935649835fc08eee4ebe81fc6190cf0` / Lab `020b818b6ce0b813c22b8826945a917fe4017816`. Scoped review must include **both** new Source commits and both Lab pins from these fix bases, not HEAD~1.

## Finding disposition and final behavior

| Finding | Prepared-code disposition | Evidence and remaining limit |
| --- | --- | --- |
| R1-01 visual transforms/scales | Fixed in Python producer and independent TS consumer | Every canonical visual mesh has identity xyz/rpy and unit scale, with legal omitted URDF defaults equivalent to explicit values. Duplicate origins, extra geometry, altered scale/translation/rotation fail. Native-kind records with coherently recomputed raw hashes still fail semantics. No actual expansion or collision/contact qualification asserted. |
| R1-02 invalid graph/tool link | Fixed in both readers and positive protocol fixture | Exact connected acyclic native graph, unique nodes/children, declared endpoints, pinned world attachment and end-effector alias. Missing TCP/eef/world, extra/disconnected link, extra/cyclic/dangling/altered joint fail. Canonical R2a bytes remain unchanged. |
| R1-03 open control/plugin semantics | Fixed in both readers | Exact mode-specific arm and G2 control blocks, joint/interface/limit bindings, seven transmissions, G2 URDF mimic relations and five plugin bindings, Gazebo selfCollide declarations, X2-only Harmonic control plugin. Extra hardware parameters, wrong/extra/nested plugins, wrong interfaces/joints/mimics and parameter-path substitutions fail even with resealed native-kind records. Static declaration validation does not validate external parameter-file contents or installed behavior. |
| R1-04 lost ACK mislabeled not_run | Fixed at public CLI lifecycle implementation | Durable startup/command-attempt state is separate from successful ACK. Lost ACK, rejected action, thrown transport and startup uncertainty are `executed/fail` (attempted case, not proof of actual motion). Explicit preflight refusal alone is `not_run/blocked_external`. Receipts are durable before dispatch; original failure survives failed cleanup. Tests use doubles and retain `protocol_double`. Actual preflight receipts remain legitimate not_run. |
| R1-05 native completion | **NOT ADDRESSED — external qualification incomplete** | Actual X1/X2 provenance, installed package/plugin/parameter identity, real expansion/readback, motion/fault/stop/controller-restart evidence and X3 ten trials or observed unsupported outcome are absent. 0/10 contact trials; unobserved G2 is not proven unsupported. Same-run reopen refusal is not controller restart evidence. Direct FollowJointTrajectory is not collision-planned motion. |

## Implementation and APIs

- `packages/lab-runtime/src/v2/sil/xarm-mapping.ts` and `robotics/manipulation/native_xarm/mapping.py`: retain existing validator/producer APIs and metadata binding; enforce graph, geometry, mimic and complete control-extension semantics. The XML parser remains bounded, and generated mapping refs still cannot satisfy immutable closure entries. Existing handoff schema/model/tool role semantics are unchanged.
- `robotics/manipulation/profiles/xarm6-native-mapping.json`: adds expected identity visual transforms/unit scales, exact pinned native graph and canonical-to-native alias explanation. `link6 → joint_eef → link_eef` is an identity transform; vendor `gripper_fix` attaches to `link_eef`. `world_joint` fixes world→link_base at identity. This corrects the old collapsed native projection without changing R2a canonical data or TCP endpoint equivalence.
- `profiles/xarm6-sim-extensions.json`: static XML semantic expectation manually projected from the pinned vendor macros; **not xacro output or native evidence**. The arm control block is named for the mode hardware plugin; the G2 block is XArmGripperSystem. Arm joints1–6 and drive_joint expose position/velocity command and state interfaces; arm position/velocity and gripper velocity limits match upstream. Transmissions and five G2 mimic plugin declarations are checked, including drive_joint bindings and numeric fields. Both modes retain the upstream G2 mimic declarations; accepting their names is not asserting Harmonic support.
- X1 uses package://xarm_description mesh URIs; X2 uses file:///opt/mekoniq/xarm_ws/install/xarm_description/share/xarm_description. Existing fixed install/root/hash checks remain. X2 declares gz_ros2_control-system / gz_ros2_control::GazeboSimROS2ControlPlugin and `/tmp/launch_params_<suffix>` generated by the pinned uf_robot_utils helper. `native_xarm/worker.py` fixes TMPDIR to `/tmp` for this declared profile. Target data explicitly labels parameter contents `unresolved_separate_from_raw_declaration_mapping`; no reader opens/authenticates that external YAML. Installed content and native behavior are separate unresolved gates.
- `packages/lab-runtime/src/v2/sil/xarm-cli.ts`: keeps `runXarmCase` and public CLI options unchanged. New fsynced/renamed `source-lifecycle.json` records provider_start_requested → provider_ready → command_attempted or preflight_refused, startup disposition, command ACK disposition and shutdown errors. Command bytes with ack:null are synced before dispatch; received ACK replaces that record. Case `executed/fail` means attempted, not a claim of observed movement. Exit1 versus exit2 follows that distinction. Source unknown/no-resend protections are unchanged.
- `tests/fixtures/xarm-native-protocol.urdf` is now structurally valid, with the complete graph/control/transmission/mimic declarations. It remains a synthetic protocol fixture. Both mode positives and malformed/coherently resealed negatives are covered by `tests/integration/xarm-native-contract.test.ts` and `robotics/manipulation/tests/test_native_xarm.py`. New `tests/integration/xarm-native-cli.test.ts` tests lost ACK, rejection, startup/preflight, pre-dispatch durability and cleanup failure using explicitly labeled lifecycle doubles.
- `docs/operations/xarm-native-sim.md` records corrected aliases, closed raw declaration scope, external YAML/native limitations, attempted-case semantics and R88. `native-vendor.lock.json` adds ten exact pinned source snapshots, with license/NOTICE retained. Lab changes are only runtime pin and generated provenance headers (three files).

## Pinned upstream inspection and projection

The fixed upstream commit remains `d837f2e17f7f36043103b367fca3af8172626245`, tree `716c810e5cf34dcef317454dd601bcb6826bea9b`; SDK pin and old R2a asset lock are unchanged. Fix inspection fetched the official recursive Git tree and exact raw files, verified SHA-1 using the Git blob header, retained the raw inputs under `fix1/upstream/`, then pinned the necessary additional files below. This is **source inspection**, not installed closure, expansion or native qualification. Existing common.link.xacro defines identity visual origin defaults and no scale; common gripper visual calls pass zero origins. The vendor macro declares the world/eef nodes and attaches the gripper to link_eef. Root confirmed this is the required R1-02 correction, not a new canonical model. The synthetic selector XI13050520BB00 remains unchanged and is never a hardware identity.

| Added upstream snapshot (relative to vendor-source; exact pinned link) | SHA-256 | Git blob SHA-1 |
| --- | --- | --- |
'''
for f in lock['files']:
 if f['path'] not in oldpaths:text+=f"| [{f['path']}]({f['url']}) | `{f['contentSha256']}` | `{f['gitBlobSha']}` |\n"
text+=f"\nThe final native target has {len(target['joints'])} joints and {len(set(n for j in target['joints'] for n in [j['parent'],j['child']]))} links. All twenty retained native source snapshots match the pinned Git tree; all original twenty-one canonical description source identities, R2a component/vendor files and both unresolved engineering environment locks are unchanged.\n"
text+='''
## TDD chronology, scopes and own-exit receipts

All new evidence is under `evidence-L03/fix1/`; no original receipt, export, cache or report bytes were rewritten. Each check below has separate `.log` and `.receipt.json` files with its own numeric exit, exact argv/cwd/toolchain/env and before/after Source/Lab byte identities. The receipt helper uses Node24.22.2, pnpm10.32.1, portable Python3.11, PYTHONDONTWRITEBYTECODE=1 and no pytest cache; no rclpy/native interpreter was installed. Filtered/deselected tests are not_run for that invocation, not passes.

1. `red-mapping-ts` failed on accepted 1000× scale; `red-mapping-python` had seven expected-rejection failures: scale, displaced visual, already-missing TCP, orphan, cycle, unknown Gazebo plugin and empty control. The pre-correction fixture already lacked TCP; that RED intentionally retains the malformed original bytes. Empty-control mutation likewise preserves the existing deficient control. TS stops at its first assertion, so it is not claimed to demonstrate all seven in that output.
2. `red-cli`: lost ACK, actual action rejection and startup error incorrectly became not_run; three failures, one legitimate preflight pass. The fixes then reached `green-mapping-python` 35 passes and `green-ts` 18 passes at their recorded intermediate bytes.
3. Added mode/default/resealed interface/mimic/graph and lifecycle-durability coverage. `final-ts` passed 123 tests (66 security handoff,37 unit handoff,15 xArm contract,5 CLI); `final-python` passed37. Source types/contracts and changed-file lint passed. These are the first fix's pre-numeric-lexical final checks, not a claim of checking later bytes. No routing behavior changed; no unaffected broad suite was repeated.
4. First clean fix tuple Source97af81b / Lab4a32dc9 was exported and pinned, with two actual public preflight refusals. Self-review then found Number('') coercion of an empty plugin offset, and Python float('0_0') accepting non-URDF underscore notation. `red-numeric-ts` failed on accepted emptyOffset; `red-numeric-python` failed on accepted underscore offset. Neither is fabricated duplicate-send or native behavior evidence.
5. The second fix closes scalar/vector numeric lexing in both readers: only finite decimal/scientific values, with legitimate signed/fractional/exponent notation retained. Reject empty/whitespace, hex and underscore forms before conversion. `selfreview-ts` passed15 xArm contracts; `selfreview-python` passed12 selected mapping/readback/mode/numeric tests,26 deselected. This is **not a 38-test full-suite claim**. Types and changed-file lint passed again. Final-byte audit selects these later receipts for the four changed files and the earlier covering receipts for unchanged files. Counts overlap and must not be added. Original implementation's 136/92,20/27,13/28 and earlier milestones remain historical at their own bytes, untouched by this appendix.

| Check (relative log/receipt basename) | Own exit | Exact argv (cwd is Source unless name starts lab-) |
| --- | --- | --- |
'''
receipts=sorted(e.glob('*.receipt.json'),key=lambda p:json.loads(p.read_text())['startedAt'])
for p in receipts:
 r=json.loads(p.read_text());name=p.name.removesuffix('.receipt.json');text+=f"| [{name}.log](evidence-L03/fix1/{name}.log) / [receipt](evidence-L03/fix1/{name}.receipt.json) | {r['exitCode']} | `{shlex.join(r['argv'])}` |\n"
text+='''
The recorded final-byte attribution in `identities-final.json` covers every one of the 22 changed Source files from FIX_BASE. There were no post-check product edits beyond committing those checked bytes. Source contracts are unchanged by the numeric-only follow-up, so the passing earlier contracts check was retained. Changed-file ESLint is not full-repository lint: the original B10-owned historical failures remain unresolved, and no full CI pass is claimed.

## Clean tuples, exports and preservation

Source commits: `97af81ba9e4d4c6e6633384dad23d0f201a06817` (four findings) followed by `7b5b3a17e501f125efac18749ad5b8123940ce7c` (numeric self-review). Lab commits: `4a32dc9dad587bba9db32babf3797a5166eb93e1` then `58d082a9d57ea9216fa123ebb5d676ae1421b550`. The fix review spans both commits from2a7ec9c/020b818. No amend/rebase/squash hid the intermediate tuple or attempts.

| Identity | Final value |
| --- | --- |
'''
for k in ['sourceCommit','sourceTree','labCommit','labTree','export','runtimeArtifactSha256','schemaHash','nativeToolsDigest','nativeToolsFiles','portableToolsDigest','portableToolsFiles','manifestSha256','cacheManifestSha256','labPinSha256']:text+=f"| {k} | `{identity[k]}` |\n"
text+='''
Both worktrees are clean. Clean export→Lab import→generated sync→check:source/typecheck→pin checks passed for each tuple. The exported and cached manifest JSON objects are identical; importer formatting gives different byte hashes, recorded explicitly. Runtime bytes and closure-member hashes were checked against the Source tree. This is a local byte/receipt consistency audit, **not effective Git-graph attestation or host authentication**. Native closure has213 files; portable closure remains237 with unchanged digest; schema hash remains unchanged.

`fix1/identities.json` preserves the first fix tuple, `/tmp/l03-fix1-runtime-97af81b-20261115`, artifact b8b6096d994e7028e7f0ac87f142673db64d8de12e16c5773146574d6809e1fa and its two attempts. `identities-final.json` describes the final tuple and verifies the intermediate export/cache/case hashes. Original2a7ec9c export/cache and all140 original L03 evidence files,86 L02 and63 L02-r1 files remain byte-identical according to their root indexes. The original report is preserved as a prefix. No prior numeric test count is relabeled as final.

## Actual executions, native not_run and self-review limits

Four real public CLI invocations in this fix round were **preflight-only**: X1/X2 engineering-arm64 nominal for each clean tuple. Each returned numeric exit2; no launch.log, native process, native-started.json or raw-bag was produced. The six original actual preflight refusals are untouched. Repeating cancel/restart and amd64 refusal matrices was unnecessary for this parser/phase fix; their original receipts remain historical, not attributed to the new commits. Native actual movement/external stop/controller-restart remain not_run.

Final manifests under `fix1/native-not-run-final/` bind the final clean Source commit, target profile and environment request. source-lifecycle.json records `{phase:preflight_refused,startup:preflight_refused,command:not_attempted,shutdownErrors:[]}`. Reasons retain missing native OS/platform, apt/package/plugin/runtime inventory and vendor overlay; requested evidenceKind is ros2_fake_system or gazebo_actual, explicitly **not an observation that those modes ran**. Motion and contact are not_run/blocked_external, accepted:false, dynamics:not_calibrated and contact0/10. Final manifest hashes:
'''
for case,r in identity['cases'].items():text+=f"- `{case}`: `{r['manifestSha256']}`\n"
text+='''
Self-review checked both producer and independent consumer, pinned graph/control sources, defaults, alias equivalence, coherent resealing and immutable-role separation; caught and corrected the numeric coercion after preserving the first tuple. Unknown/no-resend paths remain covered. Exact native expansion, ROS API compatibility on the host, controller timing, generated YAML contents, installed provenance, mimic/contact physics, collision configuration and independent native bag replay remain unverified. R1-05 is an unmet requirement, not a spec pass or an observed unsupported verdict. L03 prepared-code review may proceed separately under R88; human acceptance and DEP-XARM-01/02/SEC-01/03 remain closed. No runtime/UI hardware capability was enabled.
'''
with report.open('ab') as f:f.write(text.encode())
print('APPENDED',len(text.encode()),'bytes; report',len(report.read_bytes()),hashlib.sha256(report.read_bytes()).hexdigest())
