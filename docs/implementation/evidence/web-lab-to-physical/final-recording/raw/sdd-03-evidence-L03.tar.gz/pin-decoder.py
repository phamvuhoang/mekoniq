import urllib.request,json,hashlib
from pathlib import Path
root=Path('robotics/manipulation');lock=json.loads((root/'native-vendor.lock.json').read_text());path='xarm_description/urdf/common/common.link.xacro'
url=f"https://raw.githubusercontent.com/xArm-Developer/xarm_ros2/{lock['commit']}/{path}"
raw=urllib.request.urlopen(url,timeout=20).read()
tree=json.load(urllib.request.urlopen(f"https://api.github.com/repos/xArm-Developer/xarm_ros2/git/trees/{lock['tree']}?recursive=1",timeout=20))
expected=next(f['sha'] for f in tree['tree'] if f['path']==path);actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();assert expected==actual
f=root/'vendor-source'/path;f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes(raw)
ref={'path':path,'contentSha256':hashlib.sha256(raw).hexdigest(),'gitBlobSha':actual,'url':url};lock['files'].append(ref);(root/'native-vendor.lock.json').write_text(json.dumps(lock,indent=2)+'\n');print(json.dumps(ref))
