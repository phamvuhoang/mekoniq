import json,hashlib,subprocess
from pathlib import Path
root=Path.cwd();lab=root.parent/'lab';e=root/'.superpowers/sdd/03-r3-linux-readiness/evidence-L03';export=Path('/tmp/l03-runtime-2a7ec9c-20261115')
def git(path,*args):return subprocess.check_output(['git',*args],cwd=path,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
source=git(root,'rev-parse','HEAD');lab_commit=git(lab,'rev-parse','HEAD');assert not git(root,'status','--porcelain');assert not git(lab,'status','--porcelain')
m=json.loads((export/'manifest.json').read_text());pin=json.loads((lab/'config/source-runtime.lock.json').read_text());cache=lab/'.runtime'/m['artifactSha256']
assert m['dirty'] is False and pin['dirty'] is False and m['sourceCommit']==source==pin['sourceCommit']
assert (cache/'manifest.json').read_bytes()==(export/'manifest.json').read_bytes()
assert sha((export/'runtime.mjs').read_bytes())==sha((cache/'runtime.mjs').read_bytes())==pin['artifactSha256']==m['artifactSha256']
assert pin['portableToolsDigest']==m['portableSimulationTools']['closure']['digest'] and pin['schemaHash']==m['schemaHash']
for closure in [m['nativeTools'],m['portableSimulationTools']['closure']]:
 for f in closure['files']:
  b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
checked={}
for name in ['selfreview-ts','selfreview-python','selfreview-typecheck','selfreview-lint']:
 receipt=json.loads((e/(name+'.receipt.json')).read_text());assert receipt['exitCode']==0
 for f,want in receipt['after']['changedFiles'].items():
  now=(root/f).read_bytes()
  if sha(now)!=want:
   assert f=='packages/lab-runtime/src/v2/sil/xarm-mapping.ts' and sha(now+b'\n')==want,(name,f)
   checked[f]='one trailing blank line removed after final behavioral/type/lint checks'
  else:checked[f]='matches tested bytes'
cases={}
for path in sorted((e/'native-not-run').glob('*/run-manifest.json')):
 r=json.loads(path.read_text());assert r['sourceCommit']==source and r['dirty'] is False and r['accepted'] is False
 assert r['motion']['status']=='not_run' and r['motion']['result']=='blocked_external' and r['contact']['status']=='not_run'
 assert not (path.parent/'launch.log').exists() and not (path.parent/'raw-bag').exists()
 for f in r['artifacts']:assert sha((path.parent/f['path']).read_bytes())==f['sha256']
 cases[path.parent.name]={'manifestSha256':sha(path.read_bytes()),'status':r['motion']['status'],'result':r['motion']['result']}
report={'sourceBase':'00d41e7f25ec1294b9bc8e8c81de3d8e1a869316','labBase':'82b5f92005673c99ba0d1f434ae4c512800fa75e','sourceCommit':source,'sourceTree':git(root,'rev-parse','HEAD^{tree}'),'labCommit':lab_commit,'labTree':git(lab,'rev-parse','HEAD^{tree}'),'sourceClean':True,'labClean':True,'export':str(export),'manifestSha256':sha((export/'manifest.json').read_bytes()),'runtimeArtifactSha256':m['artifactSha256'],'schemaHash':m['schemaHash'],'nativeToolsDigest':m['nativeTools']['digest'],'portableToolsDigest':pin['portableToolsDigest'],'labPinSha256':sha((lab/'config/source-runtime.lock.json').read_bytes()),'checkedFiles':checked,'cases':cases,'checkerScope':'local byte/receipt consistency audit, not an effective Git graph attestation','accepted':False}
(e/'identities.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='checkedFiles'},indent=2))
