from pathlib import Path
import subprocess,json,hashlib
base='00d41e7f25ec1294b9bc8e8c81de3d8e1a869316'
files=['robotics/manipulation/vendor.lock.json','robotics/simulation-mujoco/fixtures/xarm6-g2-v1/component.json','robotics/simulation-mujoco/fixtures/xarm6-g2-v1/vendor-manifest.json','robotics/simulation/profiles/engineering-amd64.lock.json','robotics/simulation/profiles/engineering-arm64.lock.json']
for file in files:
 current=Path(file).read_bytes();original=subprocess.check_output(['git','show',base+':'+file]);assert current==original;print(hashlib.sha256(current).hexdigest(),file)
root=Path('robotics/manipulation')
assert not list(root.rglob('*.pyc')) and not list(root.rglob('__pycache__'))
lock=json.loads((root/'native-vendor.lock.json').read_text())
for f in lock['files']:
 b=(root/'vendor-source'/f['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['contentSha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['gitBlobSha']
for f in lock['descriptionParity']['files']:
 b=Path('robotics/catalog/documents',f['sha256']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['jazzyGitBlobSha']
print('Preserved R2a and unresolved native locks; verified upstream bytes and all 21 candidate description identities; no Python cache.')
