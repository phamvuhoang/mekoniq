import subprocess,os,sys,json,hashlib,pathlib,time
root=pathlib.Path(__file__).resolve().parents[4]
out=pathlib.Path(__file__).resolve().parent
name,cwd,*argv=sys.argv[1:]
log=out/(name+'.log');receipt=out/(name+'.receipt.json')
if log.exists() or receipt.exists():raise SystemExit('receipt exists')
env={**os.environ,'PATH':'/Users/hoangpham/.nvm/versions/node/v24.22.2/bin:'+os.environ['PATH'],'PYTHONDONTWRITEBYTECODE':'1','PYTEST_ADDOPTS':'-p no:cacheprovider'}
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
files=git('ls-files','-m','-o','--exclude-standard','-z').split(b'\0')
identity={'sourceCommit':git('rev-parse','HEAD').decode().strip(),'sourceTree':git('rev-parse','HEAD^{tree}').decode().strip(),'status':git('status','--short').decode(),'changedBytes':{p.decode():hashlib.sha256((root/p.decode()).read_bytes()).hexdigest() for p in files if p and (root/p.decode()).is_file()}}
start=time.time()
with log.open('wb') as f:r=subprocess.run(argv,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
record={**identity,'cwd':cwd,'argv':argv,'exit':r.returncode,'elapsedSeconds':time.time()-start,'outputSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'outputBytes':log.stat().st_size}
receipt.write_text(json.dumps(record,indent=2)+'\n')
print(log.read_text());print(json.dumps({'receipt':str(receipt),'exit':r.returncode}));sys.exit(r.returncode)
