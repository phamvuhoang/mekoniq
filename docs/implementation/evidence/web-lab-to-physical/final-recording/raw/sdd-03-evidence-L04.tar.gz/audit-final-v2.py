import json,hashlib,subprocess
from pathlib import Path
here=Path(__file__).resolve().parent
source=here.parents[3];lab=source.parent/'lab';export=Path('/tmp/l04-runtime-3edb432-20261115')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args]).decode().strip()
manifest=json.loads((export/'manifest.json').read_text());pin=json.loads((lab/'config/source-runtime.lock.json').read_text())
cache=lab/'.runtime'/manifest['artifactSha256']
assert manifest['dirty'] is False and pin['dirty'] is False
assert manifest['sourceCommit']==git(source,'rev-parse','HEAD')==pin['sourceCommit']
assert manifest['artifactSha256']==pin['artifactSha256']==sha(export/'runtime.mjs')==sha(cache/'runtime.mjs')
assert json.loads((cache/'manifest.json').read_text())==manifest
assert git(source,'status','--porcelain')==git(lab,'status','--porcelain')==''
changed=git(source,'diff','--name-only','7b5b3a17e501f125efac18749ad5b8123940ce7c','HEAD').splitlines()
verified={**json.loads((here/'source-final-diff.receipt.json').read_text())['changedBytes'],**json.loads((here/'guard-final-bytes.receipt.json').read_text())['changedBytes']}
for path in changed:assert sha(source/path)==verified[path],path
for closure in (manifest['nativeTools'],manifest['portableSimulationTools']['closure']):
    for f in closure['files']:
        assert sha(source/f['path'])==f['sha256'] and (source/f['path']).stat().st_size==f['bytes'],f['path']
        committed=subprocess.check_output(['git','-C',str(source),'show','HEAD:'+f['path']])
        assert hashlib.sha256(committed).hexdigest()==f['sha256'],f['path']
native_paths=[f['path'] for f in manifest['nativeTools']['files']]
assert 'integrations/arm-controller/scripts/smoke_driver.py' in native_paths
assert 'integrations/arm-controller/packaging/dependencies.lock.json' in native_paths
assert not any('actual-joint-trace.json' in p for p in native_paths)
checks=[]
for p in sorted(here.glob('*.receipt.json')):
    r=json.loads(p.read_text());log=p.with_name(p.name.replace('.receipt.json','.log'))
    assert sha(log)==r['outputSha256'] and log.stat().st_size==r['outputBytes'],p.name
    checks.append({'name':p.stem,'exit':r['exit'],'sourceCommit':r['sourceCommit'],'dirty':bool(r['status']),'outputSha256':r['outputSha256']})
preflights={}
for mode in ('terminal','gui'):
    folder=here/'native-not-run-final'/mode;r=json.loads((folder/'smoke-sim.json').read_text())
    assert r['status']=='blocked_external' and r['result']=='not_run' and r['accepted'] is False
    assert r['actualJointTrace'] is None and r['subjectSourceCommit']==manifest['sourceCommit']
    assert r['runtimeInventory']['platform']=='Darwin' and r['runtimeInventory']['python']['version'].startswith('3.11.')
    assert not (folder/'actual-joint-trace.json').exists() and not (folder/'linuxcnc.log').exists()
    preflights[mode]={p.name:sha(p) for p in folder.iterdir() if p.is_file()}
old_export=Path('/tmp/l03-fix1-final-runtime-20261115')
old_runtime='108e6233183a0646cc09ddb4e376a6a5fda3262cc964d7be242e991b3c08863a'
assert sha(old_export/'manifest.json')=='3ae99664dfb2ce993a12f433ae9a7bda5361407fd06742c05566da554d71bc1e'
assert sha(lab/'.runtime'/old_runtime/'manifest.json')=='a6942acac622d10808702b4a84f1097c2710ab37a0abb19f006fa0235de2be71'
assert sha(lab/'.runtime'/old_runtime/'runtime.mjs')==old_runtime
first=json.loads((here/'identities-final.json').read_text())
first_export=Path(first['export']);first_cache=lab/'.runtime'/first['artifactSha256']
assert sha(first_export/'manifest.json')==first['manifestSha256']
assert sha(first_cache/'manifest.json')==first['cacheManifestSha256']
assert sha(first_export/'runtime.mjs')==sha(first_cache/'runtime.mjs')==first['artifactSha256']
for mode,files in first['preflights'].items():
    for name,digest in files.items():assert sha(here/'native-not-run'/mode/name)==digest
identity={'sourceCommit':git(source,'rev-parse','HEAD'),'sourceTree':git(source,'rev-parse','HEAD^{tree}'),'labCommit':git(lab,'rev-parse','HEAD'),'labTree':git(lab,'rev-parse','HEAD^{tree}'),
'export':str(export),'artifactSha256':manifest['artifactSha256'],'manifestSha256':sha(export/'manifest.json'),'cacheManifestSha256':sha(cache/'manifest.json'),'labPinSha256':sha(lab/'config/source-runtime.lock.json'),'schemaHash':manifest['schemaHash'],
'nativeToolsDigest':manifest['nativeTools']['digest'],'nativeToolsFiles':len(native_paths),'portableToolsDigest':pin['portableToolsDigest'],'portableToolsFiles':len(manifest['portableSimulationTools']['closure']['files']),
'finalChangedSourceFiles':{p:sha(source/p) for p in changed},'preflights':preflights,'checks':checks,'historicalL03FinalExportAndCacheUnchanged':True,'firstL04TuplePreserved':True,'claims':'local byte/receipt consistency only; no effective Git-graph attestation or host authentication'}
(here/'identities-final-v2.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({k:v for k,v in identity.items() if k not in ('checks','finalChangedSourceFiles','preflights')},indent=2))
print(f'Verified {len(checks)} receipts, {len(changed)} final changed Source byte identities, both clean worktrees, export/cache/pin and native closure membership.')
