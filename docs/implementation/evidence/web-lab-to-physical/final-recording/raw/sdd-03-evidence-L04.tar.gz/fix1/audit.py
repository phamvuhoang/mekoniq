import json,hashlib,subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent;history=here.parent;source=here.parents[4];lab=source.parent/'lab'
export=Path('/tmp/l04-fix1-runtime-7d8bede-20261115')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(repo,*argv):return subprocess.check_output(['git','-C',str(repo),*argv]).decode().strip()
assert git(source,'status','--porcelain')==git(lab,'status','--porcelain')==''
manifest=json.loads((export/'manifest.json').read_text());pin=json.loads((lab/'config/source-runtime.lock.json').read_text())
cache=lab/'.runtime'/manifest['artifactSha256']
assert not manifest['dirty'] and not pin['dirty']
assert manifest['sourceCommit']==git(source,'rev-parse','HEAD')==pin['sourceCommit']
assert manifest['artifactSha256']==pin['artifactSha256']==sha(export/'runtime.mjs')==sha(cache/'runtime.mjs')
assert json.loads((cache/'manifest.json').read_text())==manifest
checked=json.loads((here/'green-staging.receipt.json').read_text())['changedBytes']
changed=git(source,'diff','--name-only','3edb4320d7146343a4b9df977c65d846472c473b','HEAD').splitlines()
assert len(changed)==3
for name in changed:assert sha(source/name)==checked[name]
for f in manifest['nativeTools']['files']:
    assert sha(source/f['path'])==f['sha256'] and (source/f['path']).stat().st_size==f['bytes'],f['path']
    assert hashlib.sha256(subprocess.check_output(['git','-C',str(source),'show','HEAD:'+f['path']])).hexdigest()==f['sha256']
assert not git(source,'diff','--name-only','3edb4320d7146343a4b9df977c65d846472c473b','HEAD','--','integrations/arm-controller/configs','integrations/arm-controller/models','packages/contracts')
report=history.parent/'task-L04-report.md';prefix=(here/'pre-fix1-report.md').read_bytes()
assert len(prefix)==32387 and hashlib.sha256(prefix).hexdigest()=='642e137959397ea426347af99995df76657cd404269b53ce2c91dbd8815df199'
assert report.read_bytes().startswith(prefix)
index=json.loads((history.parent/'root-L04-evidence-file-index.json').read_text())
assert len(index['files'])==114
for f in index['files']:
    path=history/f['path'];assert path.stat().st_size==f['bytes'] and sha(path)==f['sha256'],str(path)
for identity_name in ('identities-final.json','identities-final-v2.json'):
    prior=json.loads((history/identity_name).read_text());prior_export=Path(prior['export']);prior_cache=lab/'.runtime'/prior['artifactSha256']
    assert sha(prior_export/'manifest.json')==prior['manifestSha256'] and sha(prior_cache/'manifest.json')==prior['cacheManifestSha256']
    assert sha(prior_export/'runtime.mjs')==sha(prior_cache/'runtime.mjs')==prior['artifactSha256']
    assert manifest['schemaHash']==prior['schemaHash'] and pin['portableToolsDigest']==prior['portableToolsDigest']
receipts=[]
for p in here.glob('*.receipt.json'):
    rec=json.loads(p.read_text());log=p.with_name(p.name.replace('.receipt.json','.log'))
    assert sha(log)==rec['outputSha256'] and log.stat().st_size==rec['outputBytes']
    receipts.append({'name':p.name,'exit':rec['exit'],'sha256':sha(p)})
out={'sourceCommit':git(source,'rev-parse','HEAD'),'sourceTree':git(source,'rev-parse','HEAD^{tree}'),'labCommit':git(lab,'rev-parse','HEAD'),'labTree':git(lab,'rev-parse','HEAD^{tree}'),
'export':str(export),'artifactSha256':manifest['artifactSha256'],'manifestSha256':sha(export/'manifest.json'),'cacheManifestSha256':sha(cache/'manifest.json'),'labPinSha256':sha(lab/'config/source-runtime.lock.json'),
'schemaHash':manifest['schemaHash'],'nativeToolsDigest':manifest['nativeTools']['digest'],'nativeToolsFiles':len(manifest['nativeTools']['files']),'portableToolsDigest':pin['portableToolsDigest'],'portableToolsFiles':len(manifest['portableSimulationTools']['closure']['files']),
'checkedSourceBytes':{name:sha(source/name) for name in changed},'reportPrefixBytes':len(prefix),'reportSha256':sha(report),'historicalFilesPreserved':114,'oldTuplesPreserved':True,'receipts':receipts,
'claims':'local bytes and preservation only; no host authenticity or effective Git-graph attestation'}
with (here/(sys.argv[1] if len(sys.argv)>1 else 'identities.json')).open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('receipts','checkedSourceBytes')},indent=2))
print(f'Verified {len(receipts)} prior fix receipts; 3 checked Source paths; 114 historical files, original report prefix, two old tuples, and clean current Source/Lab export/pin.')
