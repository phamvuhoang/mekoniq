from pathlib import Path
import json,shlex
here=Path(__file__).resolve().parent;report=here.parent.parent/'task-L04-report.md'
prefix=(here/'pre-fix1-report.md').read_bytes();assert report.read_bytes()==prefix
identity=json.loads((here/'identities.json').read_text())
text='''

# L04 fix round 1 — Important L04-R1

Status: **DONE_WITH_CONCERNS — L04-R1 corrected and ready for scoped root review; native qualification remains incomplete.** Fix bases: Source `3edb4320d7146343a4b9df977c65d846472c473b` / Lab `e8ed78b98399947a26e525b8f9902e3463aef36a`. The original task base range and report above remain unchanged. Minor L04-R2 is deferred in the central index as instructed and was not modified in this round.

## Finding disposition and implementation

L04-R1 was confirmed locally: validating six files and then copying the caller directory admitted a sibling `sim.var` that the canonical INI consumes. It also reread checked files while copying. This fix changes only three Source files:

- `integrations/arm-controller/scripts/prepare_smoke.py`: captures the requested INI once, parses those captured bytes and verifies them against canonical bytes; captures and verifies the other five allowlisted files; creates a new mode0700 directory; stages only captured snapshots with exclusive writes. The staged INI is serialized from that checked snapshot with the existing approved path/display substitutions. No caller-directory copy or second unbound caller-content read remains. An existing destination, including one containing prior parameters, is refused. GUI assets still come from the package HMI directory, with existing terminal/program/model/GUI paths preserved.
- `integrations/arm-controller/tests/test_actual_trace.py`: five additional test cases cover extra `sim.var`/other siblings in terminal and GUI staging, later mutation of checked HAL and INI inputs, and refusal to overwrite existing destination state. Caller files are left untouched by production staging. The deterministic mutation fixture changes only its temporary caller inputs after capture; it is not native evidence.
- `docs/operations/linuxcnc-native-sim-handoff.md`: states the allowlist/snapshot rule and absence of caller `sim.var` at startup. Any parameters LinuxCNC subsequently creates are per-run temporary state, not immutable source inputs or inputs reused for another run.

Canonical configuration/model bytes, bridge/controller logic, oracle admission, schemas and portable tooling remain unchanged. No HMI redesign, persistent-parameter import, native run or broad full-task redo occurred. This removes the identified caller-input gap; it does not certify controller startup on an unassigned host or make the trusted package immutable against an actor modifying the package itself.

## Behavioral RED, scoped GREEN and failures

`red-staging.log` / receipt recorded own exit1: **3 failed, 2 passed, 10 deselected**. Both terminal and GUI cases showed that caller work offsets were staged; the HAL mutation case showed staged bytes differed from the already-checked snapshot. The existing-destination refusal and supplementary INI snapshot case already passed before the correction; they are baseline guards, not falsely reported as new RED. Deselected cases were not_run in that targeted selection.

`green-staging.log` / receipt recorded own exit0: **34 passed, 3 subtests passed** across `tests/test_actual_trace.py tests/test_smoke_launch.py tests/test_linuxcnc_sim.py`. This covers the changed staging and launcher compatibility; no covering-suite repeat was performed merely to obtain a new timestamp. Python3.11 and its wrapper subprocess PATH are pinned through `fix1/check.py`, with PYTHONDONTWRITEBYTECODE=1 and PYTEST_ADDOPTS=-p no:cacheprovider. Node24.22.2/pnpm10.32.1 were used for export and Lab checks. One bare-python report-helper invocation failed with exit127 at pyenv before the helper started; no report/product bytes changed. Its observed argv/output are retained in `fix1/append-helper-failure.json` and `.log`; the helper was rerun through the receipt runner with Python3.11. No test dependency/import failure occurred in this fix round.

Own-exit receipts retain full cwd/argv, Source commit/tree/status, changed-file SHA256s and output byte count/SHA256. The exact commands below are linked to complete outputs; `SOURCE`/`LAB` abbreviate only path prefixes in this rendered table, not in the receipts.

| Log / receipt | Exit | argv |
| --- | --- | --- |
'''
source=here.parents[4];lab=source.parent/'lab'
for p in sorted(here.glob('*.receipt.json'),key=lambda p:p.stat().st_mtime):
 r=json.loads(p.read_text());stem=p.name.removesuffix('.receipt.json');command=shlex.join(r['argv']).replace(str(source),'SOURCE').replace(str(lab),'LAB')
 text+=f'| [{stem}.log](evidence-L04/fix1/{stem}.log) / [receipt](evidence-L04/fix1/{p.name}) | {r["exit"]} | `{command}` |\n'
text+='''
The scoped green was run on dirty FIX_BASE with the exact final three Source file byte identities. The audit compares those captured green bytes directly with the committed files; no product edit followed that check. Source TypeScript/typecheck/contracts/full CI were not rerun because this correction changes only Python staging, its Python tests and the runbook; the earlier full-task check results above keep their original attribution. Lab check:source/typecheck and clean export/import/sync were run for the new tuple as required.

## Clean tuple and byte attribution

Source commit `7d8bededd7b0ca57984d6f0d000eaa74ddea839d` fixes L04-R1. The Lab commit below pins that exact clean Source export; the two generated contract files change only their Source-commit header. No allow-dirty export was used.

| Identity | Value |
| --- | --- |
'''
for k in ('sourceCommit','sourceTree','labCommit','labTree','export','artifactSha256','manifestSha256','cacheManifestSha256','labPinSha256','schemaHash','nativeToolsDigest','nativeToolsFiles','portableToolsDigest','portableToolsFiles'):
 text+=f'| {k} | `{identity[k]}` |\n'
text+='\nFinal Source byte identities from the passing scoped check:\n\n| Source path | SHA256 |\n| --- | --- |\n'
for path,digest in identity['checkedSourceBytes'].items():text+=f'| `{path}` | `{digest}` |\n'
text+='''
`fix1/identity.log` and its own exit0 receipt verified nine prior fix receipts, all three checked Source paths, both clean worktrees, export/cache/pin consistency, all225 native closure members against working and committed bytes, unchanged schema/portable digests, both older L04 exports/caches, all114 original evidence files and the original report prefix. `fix1/identities.json` contains the full identities. NativeTools retains the same225 members and changes its digest because prepare_smoke.py changed; the portable closure remains237 files. Manifest export/cache JSON objects are equal; their formatting gives different byte digests.

The original report remains the exact32387-byte prefix SHA256 `642e137959397ea426347af99995df76657cd404269b53ce2c91dbd8815df199`, with root's saved copy untouched. All114 files in `root-L04-evidence-file-index.json`, both old L04 exports/cache manifests/runtime artifacts and all old preflight evidence remain byte-identical. New fix files live only under `evidence-L04/fix1`. No old commit, artifact or checker identity was relabeled. The append operation has its own `fix1/report-append.log` / `.receipt.json`. After this appendix, `fix1/post-report.log` / `.receipt.json` and `post-report-identities.json` record the same preservation audit including this appended report; these are separate files, not replacements for the pre-append audit.

## Scope limits and self-review

Self-review checked the extra-consumed-file case, same-snapshot parse/stage guarantee, fresh-directory refusal, exclusive writes, correct GUI and terminal paths, canonical-source preservation and no additional caller read during staging. Startup `sim.var` is excluded rather than silently imported. Generated parameter retention was not added; the existing per-run temporary staging lifecycle remains, and native startup compatibility still needs its assigned host.

No LinuxCNC/native/GUI process, real host package/trust resolution, hardware endpoint or new Mac preflight was run in this round. Existing native/GUI/package/timing/authenticity/atomic-fencing and human-acceptance gates remain not_run/incomplete. No existing preflight record is attributed to the new Source commit. Full CI remains unclaimed. R76 Docker restriction is unchanged. L04-R2 remains explicitly deferred. Root owns the new scoped fix review; this appendix does not grant whole-task or native approval.
'''
for a,b in [('all225','all 225'),('all114','all 114'),('same225','same 225'),('remains237','remains 237'),('exact32387','exact 32387')]:text=text.replace(a,b)
with report.open('ab') as f:f.write(text.encode())
assert report.read_bytes()[:len(prefix)]==prefix
print(f'Appended {len(text.encode())} bytes; preserved {len(prefix)} original bytes.')
