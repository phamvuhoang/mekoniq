from pathlib import Path
import json,shlex
here=Path(__file__).resolve().parent
identity=json.loads((here/'identities-final-v2.json').read_text())
first=json.loads((here/'identities-final.json').read_text())
source=here.parents[3];lab=source.parent/'lab'
intro='''# L04 — PUMA/LinuxCNC actual-joint trace and scoped ALG04

Status: **DONE_WITH_CONCERNS — portable preparation complete; native L04 qualification remains incomplete.** No assigned Debian LinuxCNC host was available. DEP-CNC-01/02/03, full ALG04, SEC-01, GUI, physical motion and calibrated dynamics have not been qualified. All actual native/GUI requests in this task were Mac preflight refusals, not controller runs. Root owns independent review.

## Scope, bases and decisions

Only the isolated `source` and `lab` worktrees under `/Users/hoangpham/source/prv/robot/.worktrees/web-lab-to-physical/` changed, on `codex/web-lab-to-physical`. Original task range: Source `7b5b3a17e501f125efac18749ad5b8123940ce7c` → final Source below; Lab `58d082a9d57ea9216fa123ebb5d676ae1421b550` → final Lab below. No amend/rebase/squash concealed the first tuple. No helpers/reviewers, Docker retry, cloud/provisioning, push/merge/deploy, original-main mutation or physical connection occurred. No SQLite was opened or retained. No R2a engine/model/lock or historical qualification record was edited.

Read task brief/dispatch first, relevant L00 PUMA/native_apt and L03 final-interface report sections, native model conventions and bridge units. Applied test-driven development and verification-before-completion skills. Root confirmed receive brackets without invented controller time. One concrete closure conflict was raised: nativeTools previously omitted controller scripts/packaging. Root recorded **R89** authorizing both immutable directories in nativeTools; generated traces/run inventory remain evidence outside the closure. The existing native_apt admission rules and public clean-checker/full-Git-graph gate are unchanged.

## APIs and changed files

| Source path | Behavior |
| --- | --- |
| `integrations/arm-controller/scripts/smoke_driver.py` | New `sample_actual_joints`, `controller_epoch`, `trace_record`, `LinuxcncController.assert_epoch`; additive optional `run_sequence(..., before_action=...)`, wired by native `main`. Actual/desired joint arrays, raw degrees and radians, independent IDs, kernel-boot/PID/start-time epoch, host receive bracket. Missing vectors stay null; unavailable controller time/synchrony stay explicit. Guards before actions and across polls refuse observed restarts. Interrupted terminal actions retain preceding steps and failed action; output files use exclusive creation. |
| `integrations/arm-controller/scripts/prepare_smoke.py` | The SIM backend label alone no longer admits caller-edited INI/HAL. Stages byte-matching reviewed INI, virtual HAL/DH HAL, profile, tool and cup geometry only. |
| `integrations/arm-controller/scripts/smoke-sim.sh` | Refuses every nonempty evidence directory; binds actual trace path/size/SHA when present, keeps supplied subject commit, accepted:false and native timing not_run. Existing terminal-versus-GUI separation remains. |
| `integrations/arm-controller/scripts/runtime-inventory.py` | Adds source package/version and unchanged binary ISA/version mapping, dpkg argv/exit/stdout/stderr/hash, OS-release and apt source-file identities. Does not pretend these are resolved retained archive/source/trust proofs; no native_apt installation claim on Mac. |
| `integrations/arm-controller/packaging/dependencies.lock.json` | Preserves existing candidate pins, adds explicit unresolved nativeQualification fields. No Debian package was resolved or installed; no ARM64↔amd64 relabeling. |
| `packages/lab-runtime/src/v2/algorithm/linuxcnc-trace.ts` | New `validateLinuxcncTrace(unknown)` and `runLinuxcncAlg04(checker, input)`. Pinned native PUMA manifest/DH/frames/tool/profile, units/raw-SI conversion, nonempty independent samples, joint limits, clock/sequence/receive brackets and unique IDs are checked before RTB. Epoch coverage splits; no interpolation or continuous-trajectory pass. RTB takes supplied actual joints only. |
| `scripts/lab-algorithm.mjs` | Additive `linuxcnc --trace FILE --out DIR [--python PATH]`; old `run` behavior preserved. Retains input byte SHA, separate supplied subject commit and actual local checker checkout identity, profile/lock digests and structured ALG04 result. Output must be new. |
| `scripts/native-sim/tool-identity.mjs` | R89 adds immutable arm-controller/scripts and packaging directories; existing sort, cache/metadata exclusions and symlink refusal remain. Native closure rises from213 to225 files. |
| `tests/integration/linuxcnc-alg04-evidence.test.ts` | Sixteen tests: negative admission boundaries, epochs, real RTB numeric subset over explicit protocol-double inputs, exact actual-input assertion, public CLI byte/identity output and numerical fail winning over not_run. |
| `integrations/arm-controller/tests/test_actual_trace.py` | Ten protocol tests: raw/converted fields, no synthetic clock/Cartesian substitution, missing samples, unsafe HAL refusal, native package/source ISA parser, restart during poll, failed-step retention, truthful init failure, pre-action guard and main wiring. |
| `integrations/arm-controller/tests/test_smoke_launch.py` | Existing status double now supplies the epoch dependency; no test-only sampler fallback in production. |
| `tests/unit/native-tool-identity.test.ts` | Recorder/package-lock membership and byte-mutation coverage, existing metadata/worker regression; fixture roots now include prior manipulation/navigation/native-fixture closure members. |
| `docs/operations/linuxcnc-native-sim-handoff.md` | Exact native commands, independent roles, model/clock/metric semantics, trust/package/GUI obligations, R89 and remaining native limitations. |

Lab changes are only `config/source-runtime.lock.json` and regenerated Source-commit headers in `src/shared/{engineering,navigation2d}.ts`. Contract/schema contents, canonical PUMA model/DH/frames, bridge routes, runtime authority and hardware capabilities are unchanged.

## Evidence semantics and remaining limits

The source model is the native controller PUMA table, never the illustrative mock or xArm. It keeps inch lengths, degree joints, radian alpha, JOINT_0–5/J1–6 signs/offsets/limits, exact modified DH and arm_base→tcp/tool-0-notool. Inertia/physical placement remain unknown/not_calibrated. `actual_position` is not six joint angles. No velocity default or zero-motion proof was added.

The sampler reads `joint_actual_position` and `joint_position` independently. Its one host monotonic bracket covers polling/field reads, not controller sample time or field synchrony. `controllerTime:null`, clock unavailable and synchrony unavailable remain explicit; neither cycle_time nor echo_serial becomes a synthetic clock. Native host API/epoch compatibility has not run. Process lookup is deliberately refused if ambiguous/missing. The before-action guard and before/after-poll identity checks are observations, **not atomic controller-side fences**: restart after the guard and before an NML write remains unqualified. A hard kill before final flush can leave no trace; absent/partial trace cannot qualify anything. No resend, respawn or automatic continuation was added.

ALG04 separates:
- Within-poll `maxObservedCommandActualDeltaRad`, explicitly not synchronized following-error qualification.
- `maxFkTranslationResidualM` / `maxFkRotationResidualRad`: RTB versus TypeScript FK on the independently supplied actual angles, with exact native DH; this is numerical consistency, not native controller accuracy.
- Controller Cartesian-versus-DH/TCP residual: not_run, `CONTROLLER_CARTESIAN_DH_TCP_ENDPOINT_NOT_ESTABLISHED`; no invented comparable work/tool-offset endpoint.

`numericVerdict` may pass for the numerical subset. Overall ALG04 remains not_run due to unavailable native clock/synchrony, execution authenticity and continuous motion coverage. A numeric failure remains fail. Explicit protocol_double test data cannot qualify a host. An input JSON native_capture label or supplied subject commit is not authentication. The new CLI records local checker identity but does not replace the native-handoff public clean-checker/full-Git-graph verifier. No actual native trace or production ALG04 candidate was created in this task; test CLI outputs were temporary protocol-double fixtures. Existing public-checker tests use isolated test repositories, not a qualification claim for this task.

## RED → GREEN and failed attempts

Every failed attempt remains in `evidence-L04/`, with own command, Source commit/tree/status, changed file SHA256s, numeric exit, full output, byte count and output SHA256. Receipt runner is `evidence-L04/check.py`; output is captured directly from the one subprocess, not inferred from a trailing cat/diff. Older successful checks are not relabeled as running on a later clean commit.

- `red-python`: tooling failure, stock Python3.11 had no pytest; **not behavioral RED**. Existing `.venv-algorithm` Python3.11 enabled `red-python-02`: four real failures (sampler absent and modified HAL admitted).
- `red-ts`: fourteen expected missing-consumer assertion failures. `green-ts-01`:14/14, including real RTB on test input.
- `red-cli`: absent report raised ENOENT; retained as first test-shape attempt. `red-cli-02` corrected the assertion and failed explicitly on missing retained trace report. `red-inventory` failed missing source-package parser. `green-wiring`:15/15.
- `typecheck-01`: checkerId incorrectly used robotics-toolbox; corrected to existing `rtb_kinematics`. `typecheck-02` and final typecheck passed.
- `red-epoch-failure`: terminal exception exposed lost step history; epoch test also had an incomplete double (missing lc). `red-epoch-02` fixed the double and explicitly failed because no restart was refused across a poll.
- `green-python-02`: collection failed because `.venv-algorithm` lacked rfc8785/jsonschema; **not behavioral RED**. Existing `.venv-irsim` Python3.11 supplies those dependencies; combined controller tests then passed.
- `red-init-reason` exposed misleading missing-module labeling for ambiguous native process identity; corrected reason is controller initialization failure.
- `red-closure` failed because recorder/package files were absent from nativeTools; R89 expansion passed combined closure tests.
- Initial complete tuple had138 TS tests and69 Python tests +8 subtests passing. Final initial Python run `combined-python-final-02` pins PATH to Python3.11 for wrapper subprocesses too. Earlier wrapper subprocesses inherited the Mac default Python3.15.2, though their pytest worker was Python3.11; they are retained, not presented as final interpreter proof.
- Late self-review after the first clean tuple found the next-action restart window. `red-pre-action-guard` explicitly failed on absent guard and `red-pre-action-wiring` showed four controller actions sent before failed epoch admission. Follow-up `guard-python-final` passed71 tests +8 subtests, including native-main wiring, with Python3.11 throughout. The follow-up touched only smoke_driver, its new tests and the runbook. Unchanged TS/type/contracts/lint checks remain attributed to the first implementation bytes; the final audit maps all13 final Source paths to those checked bytes plus the guard follow-up.

No package install/network repair or portable dependency lock mutation was used to fix test tooling. Node24.22.2/pnpm10.32.1 were used through the receipt runner, and Python tests use PYTHONDONTWRITEBYTECODE=1/PYTEST_ADDOPTS=-p no:cacheprovider. Test subprocess groups/resources are managed by existing deadline/fixture cleanup. No unrelated process cleanup occurred.

## Actual checks and receipts

The table lists every retained check receipt. `SOURCE` and `LAB` abbreviate the exact isolated paths above in rendered argv only; each linked receipt keeps the unabridged argv/cwd and byte identities. Empty output is accepted only with that check's own exit0. Targeted selections' skipped/deselected tests are not counted as passes. Discovery reads and edits are not verification receipts.

| Receipt/log stem | Exit | Exact argv (path prefixes abbreviated) |
| --- | --- | --- |
'''
rows=[]
for p in sorted(here.glob('*.receipt.json'), key=lambda p:p.stat().st_mtime):
 r=json.loads(p.read_text());name=p.name.removesuffix('.receipt.json');cmd=shlex.join(r['argv']).replace(str(source),'SOURCE').replace(str(lab),'LAB').replace('SOURCE/../lab','LAB')
 rows.append(f"| [{name}.log](evidence-L04/{name}.log) / [receipt](evidence-L04/{p.name}) | {r['exit']} | `{cmd}` |")
mid='''

## Executed versus not_run

| Requirement | Actual scope |
| --- | --- |
| Trace admission/model/units/clock/epochs | Portable tests executed; independent recorded native input absent. |
| Numerical ALG04 consumption | Real RTB checker exercised against explicitly protocol-double raw joint inputs; native ALG04 not_run. |
| SIM-only config; arbitrary MDI/HAL/launch boundaries | Byte-exact staging and existing arbiter/security/tunnel tests executed; real native endpoint conformance not_run. |
| Debian version/package/source/ISA resolution | Not_run: no assigned host; candidate values remain unverified and resolvedHost/packages/source artifacts null. |
| Terminal start/home/run/pause/resume/stop/fault/no-auto-resume | Native not_run. Mac wrapper preflight only, two separate attempts per tuple, each exit2. |
| Controller restart/tunnel loss/deadline/arbiter | Portable protocol/security tests executed; native controller/tunnel behavior not_run. |
| Package install/verify/rollback and trust | Existing portable release trust/security tests executed; actual package install/rollback/trust on target not_run. |
| GUI/HMI acceptance | Not_run. --gui requests refused at Mac preflight; no GUI launch, screenshot-based pass or human checklist. |
| Commit → clean export → import/sync/check/type/pin | Executed successfully for both retained tuples; no allow-dirty export. |

The four actual preflight calls produced fresh directories `native-not-run/{terminal,gui}` for the first tuple and `native-not-run-final/{terminal,gui}` for the final tuple. Every `smoke-sim.json` says blocked_external/not_run, accepted:false; reasons are HOST_NOT_LINUX, LINUXCNC_MISSING and LINUXCNC_PYTHON_MODULE_MISSING. `actualJointTrace` is null and no `linuxcnc.log`, driver trace or native process was produced. Runtime inventory identifies Darwin/arm64 and Python3.11 honestly; it is not Debian/amd64 evidence. No Docker invocation occurred (R76 remains deferred to B10).

## Commits, export and identities

First tuple (preserved): Source `962e925a9b5f1adadbc5c881be43f7f170034264`, Lab `7564d489722d81e5ff5f31bea5d61439b91ea7cf`, export `/tmp/l04-runtime-962e925-20261115`, artifact `0abee6f3bb8e04535149a885bb69c2e4593bf93bd794fae455017614a733315f`. Its Source tree is82cb9600bb4f70acb3419197848d13d28f5d16aa; nativeTools e16987678e2622ecb762baa1d1aabe4921f6bf136bbf0a07424ef8df8100d481. First identity record remains `evidence-L04/identities-final.json`; all first receipt/export/cache/preflight bytes remain unchanged.

Follow-up Source `3edb4320d7146343a4b9df977c65d846472c473b` contains the pre-action guard. Final pin and checked identities:

| Field | Final value |
| --- | --- |
'''
fields=['sourceCommit','sourceTree','labCommit','labTree','export','artifactSha256','manifestSha256','cacheManifestSha256','labPinSha256','schemaHash','nativeToolsDigest','nativeToolsFiles','portableToolsDigest','portableToolsFiles']
identity_rows=[f'| {key} | `{identity[key]}` |' for key in fields]
end='''

Source identity is the committed producer/tool checkout. Subject Source for each actual preflight is supplied explicitly and matches that tuple. There is no native subject execution or native trace producer identity to certify. Numerical checker integration tests ran against changed checkout bytes recorded by their receipts; they are protocol-fixture checks, not native candidate checker attestations. Lab commits are publication/pin identities and are never substituted for the subject or checker.

`identity-final-v2.log` and its own exit0 receipt verify49 previous receipts, all13 final changed Source file SHA256s against checked snapshots, both clean worktrees, runtime export/cache/pin equality,225 native and237 portable source/committed-byte closure members, first L04 tuple preservation and unchanged prior L03 final export/cache. The final audit itself adds the50th check receipt. Its `identities-final-v2.json` contains every file's exact SHA and the final preflight-file hashes. Exported and cached manifest JSON objects are equal; importer formatting accounts for distinct byte SHA values. NativeTools changed intentionally; portable closure and schema digests are unchanged. This is local byte/receipt consistency, not effective Git-graph attestation or host authentication.

Historical evidence was not rewritten. The prior L03 final export manifest remains3ae99664dfb2ce993a12f433ae9a7bda5361407fd06742c05566da554d71bc1e; its cached manifest remains a6942acac622d10808702b4a84f1097c2710ab37a0abb19f006fa0235de2be71 and its runtime retains108e6233183a0646cc09ddb4e376a6a5fda3262cc964d7be242e991b3c08863a. No old artifacts were relabeled with a new checker/source identity. The whole task review range includes both Source commits and both Lab pins from the original bases.

## Self-review and handoff

Self-review covered actual-versus-commanded independence, exact native model and units, missing-data handling, epoch segmentation, no fabricated controller clock/heartbeat, no interpolation, fail-over-not_run, truthful producer/checker/subject roles, SIM closure and evidence immutability. It caught the erroneous checkerId, misleading initialization reason, test-only fallback, wrapper-interpreter ambiguity and late pre-action restart window; failed attempts and the first tuple are preserved. Existing bridge recovery/trust/native-handoff/tunnel tests pass in their stated portable scope. No implementation bridge change was needed.

The remaining concerns are required native work, not portable test failures: assign the actual Debian/ISA host, resolve and retain binary/source/trust provenance, validate installed LinuxCNC API/process identity and native endpoints, collect independent actual motion samples, establish documented controller timing/field synchrony or keep those gates incomplete, establish comparable Cartesian/DH/TCP endpoints, run actual restart/tunnel/security/package cases, complete the separate GUI checklist and obtain human acceptance. Dynamics remain not_calibrated. Full native qualification remains incomplete even though this preparation is ready for root's independent review.
'''
report=here.parent/'task-L04-report.md';report.write_text(intro+'\n'.join(rows)+mid+'\n'.join(identity_rows)+end)
print(str(report));print(f'{len(rows)} check receipts; {len(report.read_bytes())} report bytes')
