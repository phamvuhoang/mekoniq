# L01 implementation report

Status: **DONE_WITH_CONCERNS — prepared tooling complete; native execution not_run / blocked_external.**

`accepted:false`; dynamics `not_calibrated`. Root owns independent review. No helper agents, Docker calls, cloud/provisioning/deployment, hardware routes or commissioning actions were used. Only the two authorized feature worktrees were edited. The original cached R2a runtime was read as data and copied after hash verification; nothing executed through or wrote to the original cache/main checkouts.

## Bases, commits and separate identities

| Identity | Value |
| --- | --- |
| Original Source base | `298db9bdbc207b14bdbef78ec8d70adf4e901c71` |
| Original Lab base | `7698aa628fc9a60598d1337b292bdcec2fe91fdc` |
| Final Source tooling commit | `2f4837d10d746a7c8c5e5ca5675ec57db4111c28` — `feat: prepare exact R2a MuJoCo native compatibility probe` |
| Final Lab pin commit | `69032d509cc94b178102c386ddf82280996cf74e` — `chore: pin source runtime 2f4837d` |
| Current clean runtime export | SHA256 `7941fee45b37560d2d38b22bc54f870ec47401c6203d2414ccbea36bea6ce54d` |
| Current schema | `07e01e8efb146fb50b8c68eebfa27d989ee07d4e80bcdb796639e3c2aaa42068` |
| Current portable closure | `4ba424081c04ba0f532c069047bf244a99385edd09ca9df347cfb45fe6d22e6e` |
| Historical subject Source | `4f893ac6fb75dff414a3ee42a726defb7935c734` |
| Historical subject Lab | `a6ec316fb3ac2f71afff25e6fa77e931f4439e00` |
| Historical runtime | `55dd3585fb386953512554ca52d54c9463e7028286a64a66425a4f5dbe8e6270` |
| Historical schema | `9e6ebfffc4aef0f3df686316881b672d96ac892d7df023701b38c398d979bff4` |
| Historical portable closure | `3d9c0b5f3e60e89327362c0c59bba8ceca4af55b0f08c44da0fbd23f3070bb1d` |
| Historical observer-authored profile SHA256 | `148afd50b392d9ab05845018a35cc5cc2c02e45d77e76bca0a64612670400263` |
| Independent L00 checker | Source `2f4837d…`; short tool SHA256 `c90b022a4b56d7b584d5aff3e3d705db85e47fe651f03662736048c799db437b` |

The full checker Git/byte binding is distinct from that short digest. The historical subject remains the old tuple even though the observer and newly pinned Lab build are current. The handoff image is **null**. The recorded registry digest `sha256:fbdf4bb5c1af4ffd15c01550b4508b6df0ad3b4d69e444e5469cfe2b52e4b009` and historical local config ID `f650a257…` are not conflated; platform manifest/config bytes and installed engine artifact remain unresolved.

`evidence-L01/final-identities.json` is the machine-readable final identity record. Both worktrees were clean at final checks; the Lab pin equals final Source HEAD. Node `v24.22.2`, pnpm `10.32.1`; portable syntax validation used Python `3.11.15` with `-I -B` and no engine import.

## API and implementation

- `packages/lab-runtime/src/v2/sil/native-handoff-r2a.ts`: precise `mujoco_r2a_arm_v1` static adapter. Checks the exact historical tuple, original fixture/engine/ref hashes, frozen typed schemas, full ArmCellScene/project/component equality, SI/frame/joint mapping and manifest/blob refs. It neither borrows current B05/B06 data nor broadens existing kinds.
- `native-handoff-documents.ts`: routes that one additive kind. `scripts/native-handoff.mjs`: exports its existing full clean checker identity routine for reuse, guards CLI entry, and adds the new fixed reference files to its short checker digest. Existing OCI/native_apt, whole closure, typed current models, frame/unit/ref and checkout gates stay enforced.
- `scripts/native-sim/r2a-arm-baseline.json`: frozen Git-derived hashes/mapping/static scene and M00 extraction provenance. Before deriving the scene, I compared the current arm scene builder, model, frame and related scene source bytes against frozen Git; they were identical. The reference schema hashes are from frozen Git, not the new handoff schema set.
- `robotics/simulation-mujoco/profiles/linux-amd64.json`: new observer-authored SIM compatibility profile. Debian 12, amd64, exact MuJoCo 3.17.0; installed libmujoco digest intentionally null. `derived/observer/…` refs and preparation receipt distinguish authoring from historical subject binding.
- `prepare-mujoco-r2a.mjs --runtime-cache DIR --lab REPO --out NEW_DIR`: reads frozen Git objects and verified runtime bytes, independently checks every original portable closure entry, writes a new handoff, and assesses it. No old checkout rebuild/reset or execution.
- `mujoco-probe.mjs --handoff DIR --out NEW_DIR`: clean-checker, static-handoff and assigned-host orchestration. The Mac guard precedes every Docker command. On an assigned host it requires local Unix-socket Docker, exact installed image/config/revision/digest, native host provenance, measured engine artifact and image worker/schema/toolchain consistency. It pulls/builds nothing. Containers are nonroot/read-only/network-none/cap-drop with bounded resources and only task-owned input/output mounts. Cleanup checks this invocation's unique label.
- `mujoco-probe-container.mjs`: executes unchanged old runtime bytes through loopback HTTP; captures health/report/raw traces and post-close byte-verified copies of runtime files/journals. Fault and timeout artifacts remain. The original live journals are only inside the disposable container's private `/tmp`.
- `mujoco-probe-engine.py`: imports the verbatim frozen M00 recipe under the real pinned image engine, or the actual historical WorkerSession/engine for explicit qvel-NaN bad-state injection. Retains request/response bytes, MJCF, raw before/injected/after NPZ state, warnings and timings. It is observer instrumentation, not a historical image file.
- `mujoco-probe-observer.mjs`: R84 passive spawn/wire observation with exact forwarding of original spawn arguments/options/child object and write arguments/return value. It changes no command or ACK, records no environment/secrets, and never pauses subject streams. Bounded async trace plus exit seal; trace loss, missing lifecycle or invalid wire data refuses qualification. Archive closes the subject worker before final readback. Measurement overhead is explicit.
- `mujoco-probe-process.mjs`: finite owned process groups, incremental separate stdout/stderr, timeout/abort/nonzero receipts and retained incomplete output. No resend/resume path.
- `mujoco-probe-evidence.mjs` and `mujoco-probe.mjs --verify DIR`: require all named scopes, actual raw contact/pose data, genuine engine warning/failure observations, Source unknown/no-false-serve/no-respawn behavior and complete observed worker traffic. Verify artifact bytes, supplied handoff/provenance, measured image/engine, exact observer recipe/code, report Source/schema/trace bindings, copied journals and timing summaries. Unit logs cannot substitute for cases.
- `scripts/record-sim-extension.mjs --mujoco-probe DIR`: optional independently identified, copied/reverified supplement. No existing release or hardware gate table is upgraded by the attachment. Claimed passes that fail readback are rejected.
- `docs/operations/mujoco-native-probe.md`: full prepared-host/profile/identity/run/readback/failure runbook; `native-simulation-handoff.md` now points to the additive old-shape support.
- Lab changes: runtime lock and the two generated contract headers from the normal sync command. Contract content hashes did not change.

Matrix: ten M00 seeds 1–10; full MJ-BV01 seeds 7/42/99; one instrumented historical WorkerSession real-engine bad-state case; one unchanged-subject-bytes full-runtime worker-loss case; one 180,000-tick / 1,800,000-substep engine long-run check. Sixteen qualification cases, plus image/engine inventory prerequisite. Tick, IPC and HTTP timing scopes are separate and retain raw samples with nearest-rank p50/p95/max. Python peak RSS and sampled process-namespace RSS are labeled separately in the runbook.

## R81–R84 boundary decisions

R81: exact historical arm-only static support belongs to this task, with actual cached runtime and frozen files. Completed without weakening L00's current adapters.

R82: bad-state is a separately identified original WorkerSession + real MuJoCo component subcase; it must produce a real warning/failure and no successful post-fault step. It makes no Source serving/custody claim. The separate full-runtime worker-loss case checks Source stop/unknown/zero served, no resend/overlap, no successful post-loss ACK and no respawn.

R83: executable **current R2b** payload/cell native adapter belongs to B10 tooling and is required there before final tooling review. L01 records it as `not_run/image_unbuilt` and does not substitute the historical R2a image.

R84: passive observer hash and timing cost remain separate from unchanged subject bytes. No uninstrumented-execution claim is made. Incomplete observation fails rather than inferring no resend from HTTP outcomes.

## RED/GREEN and checks

All listed logs are under `.superpowers/sdd/03-r3-linux-readiness/evidence-L01/`.

| Check / command | Actual result / retained output |
| --- | --- |
| `perl -e 'alarm 180; exec @ARGV' pnpm exec vitest run tests/unit/mujoco-native-probe.test.ts` — adapter first | RED 6/6 (`DOCUMENT_PROFILE_UNSUPPORTED`), then GREEN 6/6: `L01-red-adapter.log`, `L01-green-adapter.log` |
| Added bounded process/admission/matrix/bad-state tests | RED 5 new failures, GREEN 11 total: `red-probe.log`, `green-probe.log` |
| Wire overlap/resend/respawn and transparent observer tests | `red-wire.log`, `red-observer.log`, `green-observer.log` (13 total GREEN) |
| Orchestration/readback negatives | `red-orchestration.log`, `green-orchestration.log` (15 total GREEN) |
| Actual Node ESM preload byte-stream and recorder supplement | `red-supplement-preload.log`, `green-supplement-preload.log` (17 total GREEN) |
| Timing p50/p95/max, incomplete lifecycle, raw contact assertions | `red-timing.log`/`green-timing.log`, `red-observer-tail.log`/`green-observer-tail.log`, `red-grasp-raw.log`/`green-grasp-raw.log` (20 total GREEN) |
| Combined Vitest: L01, L00 unit, L00 security, clean checker security, existing sim-extension qualification | **153 passed, 0 skipped**, 5 files, ~20 s: `combined-tests.log` |
| Scoped ESLint, bounded 180 s, all changed TS/MJS/declarations/recorder/tests | pass: `lint.log` |
| `perl -e 'alarm 180; exec @ARGV' pnpm typecheck` | pass, route generation + tsc: `typecheck.log` |
| `perl -e 'alarm 180; exec @ARGV' pnpm contracts:check` | pass: `contracts-check.log` |
| Python 3.11 `ast.parse` under `PYTHONDONTWRITEBYTECODE=1`, `-I -B` | pass, **no MuJoCo import/execution**: `python-syntax.log` |
| `node --check` probe driver/orchestrator/recorder; `git diff --check` | pass, no output |
| Clean Source commit → `node scripts/export-lab-runtime.mjs NEW_DIR` under 180 s | pass, `dirty:false`: `clean-export.log` |
| Lab `import-runtime`, `sync-engineering-contracts`, `pnpm check:source`, `pnpm typecheck`, all bounded | pass: `lab-import.log`, `lab-sync-contracts.log`, `lab-check-source.log`, `lab-typecheck.log` |
| Post-Lab-commit source pin check | pass: `lab-final-check-source.log` |

Combined command:

```sh
perl -e 'alarm 180; exec @ARGV' pnpm exec vitest run \
  tests/unit/mujoco-native-probe.test.ts tests/unit/native-handoff.test.ts \
  tests/security/native-handoff.test.ts tests/security/native-handoff-checker.test.ts \
  tests/unit/sim-extension-qualification.test.ts
```

Tests use real local Node subprocesses for retention and preload forwarding, plus explicit synthetic protocol/inventory data for validator negatives. These tests are not native evidence. No worker-engine integration, Docker, native campaign or physical test was run. The scope of validation is portable implementation, static full-subject preparation and pin integrity; future assigned-host execution remains a material validation gap.

## Concrete prepared artifacts and actual execution

1. Clean tooling commit `2f4837d…` was made before preparation recording.
2. Actual handoff: `/tmp/mekoniq-L01-preparation-g53avI/handoff` (`/private/tmp/...` on macOS). **184 refs**, including the complete **179-entry** original portable closure. Runtime came from the exact archived `55dd3585…` cache; tracked closure/schema/Lab bytes came from frozen Git objects. `preparation.log` records exit 0.
3. Independent `native-handoff.mjs verify --input …/handoff`: exit 0, **prepared:true / nativeReady:false**. Exact remaining prerequisite codes: `PACKAGE_LOCK_UNRESOLVED`, `SUBJECT_IMAGE_UNRESOLVED`, `HOST_INVENTORY_MISSING`. See `handoff-independent-verify.json` and empty `.stderr`.
4. Prepared CLI exercise: `/tmp/mekoniq-L01-preparation-g53avI/native-not-run`. Static refs copied/verified, then native host guard stopped it before Docker. Exit 2, **16/16 cases not_run**, `DEP_MJ_01:not_run`, issue `NATIVE_AMD64_HOST_UNASSIGNED`. See `native-not-run-cli.json`/`.stderr` and its retained manifest.
5. Readback of that non-executed record: exit 1 / passed:false, correctly refuses qualification (`NATIVE_CAMPAIGN_NOT_PASSED`; absent observer execution directory). `native-not-run-readback.json`/`.stderr`. No incomplete record became a native pass.
6. Clean current export: `/tmp/mekoniq-L01-export-lpLtBF/runtime`. `dirty:false`, pinned in final Lab commit `69032d5…`. This current export is **not** the historical subject image/runtime.

Path pointers are also retained in `preparation-root.txt` and `export-root.txt`; the complete identity and artifact manifest hashes are in `final-identities.json`. Native image manifest/config, engine binary digest, assigned host provenance, native timings/contact results and all actual campaign outcomes remain uncollected. No native evidence directory was fabricated or historical evidence rewritten.

## Failed attempts and self-review

- Intentional RED runs are preserved as listed. Development adapter iterations exposed AJV schema-key registration, date-time format registration and the frozen arm-scene schema dependency; these were corrected without a schema bypass. Those transient diagnostics are in the tool transcript; the initial development `green-adapter` filename was reused before the dedicated evidence directory was created, so do not treat it as a complete raw log of those intermediate attempts.
- One admission test initially mutated a shared synthetic image object, changing its expected identity too; the test now clones the image before mutation. This was test setup, never a host record.
- The first actual preload test sent its payload via `stdin.end(chunk)` rather than the historical subject's `stdin.write`; it correctly lacked an observed request. The test now exercises the actual historical write API and explicitly verifies exact forwarding. Subject traffic uses `write`; unrecognized/missing observation still fails.
- Initial scoped lint found one unused import and a Python-file warning from a broad glob. The unused import was removed; final ESLint targets TS/MJS/declarations and Python is parsed separately with 3.11. `lint-first.log` retains that output.
- Self-review added rejection of missing worker exit/tail records, an exit completion seal, independent raw grasp/contact checks, separate measured engine/package/toolchain checks, and timing-summary recomputation. It also retained timeout/abort logs incrementally and made artifact-collection failure leave an incomplete manifest rather than claim success.
- Existing current shared-world/cell/PUMA/ROS mappings and OCI/native_apt admission retain their original behavior; the 153-test combined run covers those gates and old qualification readers. No runtime authority, one-ACK, lost-ACK unknown/no-resend or Lab hardware API was changed.
- Native readiness is deliberately blocked by exact unresolved prerequisites. The passive observer and full Docker/engine campaign have **not** been exercised on an assigned native host, and their native behavior is not inferred from portable tests. The record reader preserves this distinction.
- Host origin includes an operator attestation plus measured local checks; it is not cryptographic host authentication. A historical registry index, if discovered, needs explicit platform resolution support/review rather than relabeling a config/tag. Current R2b native adapter remains required B10 work under R83.

Final state: tooling/tests/runbook and clean Source→Lab pin complete; historical preparation independently verified; native qualification, native arm, hardware and acceptance remain open. `accepted:false`, `not_calibrated`.
