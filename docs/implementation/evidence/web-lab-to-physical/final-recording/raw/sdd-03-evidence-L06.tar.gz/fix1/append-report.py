from pathlib import Path
import json,hashlib
root=Path('.superpowers/sdd/03-r3-linux-readiness')
base=root/'evidence-L06/fix1'
a=json.loads((base/'final-byte-attribution.json').read_text())
p=root/'task-L06-report.md'
old=p.read_bytes()
assert len(old)==17523 and hashlib.sha256(old).hexdigest()=='ed6d841eb0fddf80ba9010d7e59e82c02bcc2d9f9b33f15bbaeea0da94598165'
checks=[]
for path in sorted((base/'checks').glob('*.receipt.json')):
 r=json.loads(path.read_text());log=path.with_name(path.name.replace('.receipt.json','.log')).read_bytes()
 assert hashlib.sha256(log).hexdigest()==r['logSha256']
 checks.append((path.name.removesuffix('.receipt.json'),r))
assert len(checks)==15
text='''

## Fix round 1/5 handoff — I1–I3 corrected; scoped review pending

**DONE_WITH_CONCERNS — TOOLING ONLY.** The three Important supported-observation findings are corrected and locally verified. Fresh independent scoped review and all final execution/recording remain pending. Minor M1 is centrally deferred in `.superpowers/sdd/deferred-findings.md`; this fix does not change its per-case disposition. The original 17,523-byte report above is preserved verbatim; this appended section supplies the new tuple and supersedes its pending full-review status only for this correction handoff.

Only the existing isolated Source/Lab worktrees on `codex/web-lab-to-physical` were used. No helper/reviewer delegation, installed Docker probe/build/container, ROS/Gazebo/controller/native campaign, external/cloud/physical action, browser campaign, final candidate recording, push/merge/deploy or original-main mutation occurred. The historical recorder unit suite uses its existing owned fake Docker executable only. No producer protocol or collector was changed; no retained original SQLite database was opened. Tests created their own temporary synthetic bags; the reader opens only verified byte copies.

### Bases, final commits and complete scoped packages

Original task bases remain Source `ac9b44dc1bf01bce2406b6f91ac3e141c043c739` / Lab `47343f930b712dd6ac64ed7cd874de3c0aca2188`. The fresh scoped review begins at FIX_BASE Source `6bf54aa5cab5bc63bc32c1fae471606d71061a78` / Lab `c41f715bca9c224328879b44e3cbf5a296b59e06`.

'''
for t in a['trees']:
 text+=f"- Final {t['name'].title()} `{t['head']}`, clean status. Full scoped package `evidence-L06/fix1/{t['name']}-fix-base.patch`: {t['patchBytes']:,} bytes, SHA256 `{t['patchSha256']}`.\n"
text+='''
Source changed only the reader, its regression fixtures/tests and directly related recipient instructions. Lab changed only its pin and two generated Source-commit headers. Committed final file attribution:

| Repo/path | Bytes | SHA256 |
| --- | ---: | --- |
'''
for t in a['trees']:
 for f in t['files']:text+=f"| `{t['name']}/{f['path']}` | {f['bytes']} | `{f['sha256']}` |\n"
text+='''
### Finding disposition and producer comparison

- **I1 corrected.** `native_xarm/ros.py` sets X1 `use_sim_time:false` and emits Python integer `stampNs`/`clockNs` as unquoted JSON tokens. The reader now uses Node 24 `JSON.parse` reviver source context to convert only canonical nonnegative integer tokens directly to BigInt. It never reconstructs nanoseconds from the rounded Number argument or changes retained bytes. Comparisons retain one-nanosecond differences near `1789999999123456789`; the existing finite sample/sequence/epoch validation stays in place. The portable X1 fixture derives the pinned X1 plugin/mesh form from the existing protocol URDF and passes the existing mapping validator. It is producer-shaped protocol evidence, not native expansion/execution. Adjacent increasing epoch samples pass; equal/decreasing stamps, decreasing clocks and clock-before-stamp samples fail at the proper sample boundary. The positive also verifies original observation bytes are unchanged.
- **I2 corrected.** `engineering_worker.py:ClockMapping` initializes from its first provider timestamp; `engineering_session.py:_health` emits a mapping on every health call, including duplicate timestamps during readiness. Source attaches after backend readiness and its separate `EngineeringClock` retains changed timestamps from its own first observation. Readback now validates raw worker origin/20 ms ticks, nondecreasing provider times and local monotonic receipts, allowing repeated health rows. The existing engineering assessor validates Source's independent origin/20 ms mapping and its own receipts. Correlation uses provider nanoseconds only, never equal relative ticks or cross-process receive times. Tests retain worker startup/duplicate rows before and after Source subscription, and refuse absent provider observations, incorrect worker/source ticks/origins, raw provider resets and independent receipt resets. TF payloads, action UUID correlation and complete replay/isolation semantics remain unverified and required cases remain not_run.
- **I3 corrected.** `native_xarm/worker.py` writes `native-inventory.json` from `inspect_profile(environment_profile)` before launch. The adapter now requires that artifact reference, checks its existing declared byte hash and uses the shared `validNativeProfileReport` with the manifest's selected engineering environment, plus explicit `available===true`. Existing manifest and mapping checks bind that environment to the requested architecture. The shared reader validates actual Linux/ISA/Ubuntu 24.04/Jazzy facts and supplied package/runtime/provenance structure. Coherently missing, unbound, unavailable, wrong-ISA, wrong-OS and wrong-environment inventories are refused after a valid X2 baseline; a mismatched artifact hash remains refused. Supplied reports/hashes do not authenticate the installed host, vendor source or execution. No new inventory collector was added.

The runbook now names the required xArm run inventory and explains exact nanosecond preservation, separate clock origins and the limits of supplied inventory consistency. Closed case matrices, caller-label refusal, `accepted:false`, `not_calibrated`, sidecar scope and native/physical boundaries remain unchanged.

### Genuine RED/GREEN and scoped validation

All logs/receipts are new under `evidence-L06/fix1/checks/`, using a copied immutable `fix1/check.mjs` own-exit wrapper. Each receipt records argv/cwd, relevant environment, start/end, own exit/signal, before/after commit/status/diff and changed-file hashes, plus log SHA256. Counts below are per invocation and overlap; they are not summed.

| Receipt | Result and demonstrated scope |
| --- | --- |
| `producer-red` | 37 tests: 18 failed / 19 passed on the original reader. All 16 previous native-reader tests passed. The valid epoch X1 fixture reached `R3_XARM_SAMPLE_INVALID`; the independent-origin engineering positive reached `R3_RAW_CLOCK_MAPPING_MISSING`. Six coherently resealed xArm inventory negatives resolved with supported observation fields while qualification stayed not_run. Three I1 ordering negatives and seven I2 mapping negatives failed expected-boundary assertions because the old blanket rejection fired earlier; those are not demonstrated admission bypasses. The clock-before-stamp, missing-provider and wrong-inventory-hash negatives already rejected. |
| `producer-green` | All 37 native-readback tests passed on the fixed reader/test bytes. |
| `combined` | Six files / 141 tests passed on final committed code/test bytes, covering the public R3 directory/CLI/sidecar path, historical qualification compatibility, native handoff, native adapters and affected engineering/xArm/B10 boundaries. |

Combined exact argv: `perl -e 'alarm 240; exec @ARGV' pnpm exec vitest run tests/unit/sim-extension-qualification.test.ts tests/unit/r3-native-readback.test.ts tests/unit/native-handoff.test.ts tests/integration/engineering-native-evidence.test.ts tests/integration/xarm-native-contract.test.ts tests/unit/r2b-readback.test.ts`.

`source-type` ran full Source `pnpm typecheck`; `contracts` ran `pnpm contracts:check`; `source-lint` ran exactly `pnpm exec eslint scripts/r3-native-readback.mjs tests/unit/r3-native-readback.test.ts`; `diff-check` ran `git diff --check`. All exited 0. This is scoped authored-code lint, not a claim of unqualified whole-tree lint or full CI. Source code/tests were not changed after these checks. Node 24.22.2 / pnpm 10.32.1 and the existing portable Python 3.11 environment were used, with `PYTHONDONTWRITEBYTECODE=1` and `PYTEST_ADDOPTS=-p no:cacheprovider`. The combined invocation records both retained-input selectors. The fixture compiler is portable; ROS was never loaded/executed.

Source was committed before fresh ordinary clean export; no dirty or checker bypass was used. Lab import/sync, `pnpm check:source` and `pnpm typecheck` passed before its pin commit. No Lab standalone script changed, so no standalone script typing gate was needed. Full build/test/browser/final recording remains deferred.

Complete receipt inventory (15; `check-index.json` includes the first 14 and the final audit's own receipt follows that index):

'''
for name,r in checks:text+=f"- `{name}`: own exit `{r['exitCode']}`, signal `{r['signal']}`, log SHA256 `{r['logSha256']}`.\n"
text+='''
### Export, checker and retention identity

Fresh export `evidence-L06/fix1/export-final/` is clean and matches the installed Lab manifest/runtime and new pin. The previous cache/rollback tuple and every old export were retained. Exact identities:

| Identity | Value |
| --- | --- |
'''
for label,value in [('Runtime artifact SHA256',a['runtimeSha256']),('Export manifest raw SHA256',a['exportManifestSha256']),('Schema hash / count',a['schemaHash']+' / '+str(a['schemaCount'])),('Native closure / count',a['nativeClosure']['digest']+' / '+str(a['nativeClosure']['files'])),('Portable closure / count',a['portableClosure']['digest']+' / '+str(a['portableClosure']['files'])),('Audited checker graph at final Source',a['checker']['toolSha256'])]:text+=f'| {label} | `{value}` |\n'
text+='''
`final-byte-attribution.json` verifies both clean committed heads, full scoped patch/file hashes, export/install/pin/runtime/schema equality, and every native/portable closure source byte. Native/portable closure objects remain unchanged from B10; 58 schema bytes remain unchanged. The checker graph belongs only to the new clean Source commit; old producer/checker identities and strict historical reproduction requirements are unchanged.

The same audit verified all **136 original L06 evidence files** and **469 B10 tooling + 254 B10 fix1 + 83 historical smoke files** against their retained root indexes, plus the original report's exact 17,523-byte prefix (SHA256 `ed6d841eb0fddf80ba9010d7e59e82c02bcc2d9f9b33f15bbaeea0da94598165`). New fix evidence has a complete `fix1/retention-index.json` (excluding that self-referential index only), with the final appended report recorded separately. No prior index/log/receipt/export/package was overwritten. Hashing retained SQLite bytes is not opening a database.

Self-review covered both complete scoped diffs and the named actual producer/shared-reader boundaries. One exploratory ignored-file `rg` returned no paths, then the explicit hidden/no-ignore search found the existing indexes; it is not check evidence. The test-edit helper emitted a Python escape warning while successfully writing the intended TypeScript regex; the passing mapped X1 fixture, typecheck and lint cover the resulting file. No failed check was erased or relabelled.

**Remaining limitations:** no actual Linux host/image/install/native run, browser/WEB05 run, physical action or final prepared/native candidate has been observed here. TF deserialization/UUID/replay, xArm controller-restart/collision-planning/G2/action-payload, LinuxCNC timing/synchrony/Cartesian/fencing/terminal/install/trust, complete DEP-SEC-01 and arm64 MuJoCo collector/reader gaps remain. Assigning a host alone does not close them. M1 remains centrally deferred. PHYS-PREP-01/R3.2 and L05's separate reviewed preparation tuple are unchanged. This correction is ready for fresh scoped review; parent L06/B10 and release acceptance are not complete.
'''
with p.open('ab') as f:f.write(text.encode())
print(json.dumps({'reportBytes':p.stat().st_size,'reportSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'appendBytes':len(text.encode()),'receipts':len(checks)},indent=2))
